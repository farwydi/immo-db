CREATE MATERIALIZED VIEW default.journal
            (
             `record_date` Date,
             `service_link` UInt32,
             `msisdn` UInt64,
             `file_guid` String,
             `download` UInt64
                )
            ENGINE = SummingMergeTree
                PARTITION BY toYYYYMM(record_date)
                ORDER BY (record_date, service_link, msisdn, file_guid)
                SETTINGS index_granularity = 8192
AS
SELECT record_date,
       service_link,
       msisdn,
       file_guid,
       count() AS download
FROM default.storage_stats_t
WHERE msisdn > 1
GROUP BY record_date,
         service_link,
         msisdn,
         file_guid;

