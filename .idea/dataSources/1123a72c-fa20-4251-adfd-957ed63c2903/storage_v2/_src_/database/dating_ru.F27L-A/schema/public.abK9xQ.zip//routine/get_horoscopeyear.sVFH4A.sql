CREATE FUNCTION get_horoscopeyear(birthday date) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
 birthyear integer := extract(year from birthday);
 name_id integer;
begin  
  select nameid from into name_id
  (select year, nameid from
 horoscope_years where year = birthyear and birthday >= fullyear
 union 
 select year, nameid from
 horoscope_years where year = birthyear-1
 order by year desc
 limit 1
 ) as t; 
 return name_id;
end;
$$;

ALTER FUNCTION get_horoscopeyear(DATE) OWNER TO postgres;

