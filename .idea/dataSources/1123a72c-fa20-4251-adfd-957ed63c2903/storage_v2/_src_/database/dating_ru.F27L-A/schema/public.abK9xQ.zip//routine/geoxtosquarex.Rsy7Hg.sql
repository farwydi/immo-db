CREATE FUNCTION geoxtosquarex(geo_x integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
BEGIN
					RETURN 	ceil( distance_in_km(600000, geo_x, 600000, 950000)::float / 3 ) 
						* (CASE WHEN geo_x < 950000 THEN -1 ELSE 1 END)
						;
					END;

$$;

ALTER FUNCTION geoxtosquarex(INTEGER) OWNER TO postgres;

