CREATE VIEW city
			(id, name, translit, code, geo_loc_x, geo_loc_y, geo_radius, geo_update_time, fullname, only_sim,
			 yandexname) AS
SELECT city_all.id,
	   city_all.name,
	   city_all.translit,
	   city_all.code,
	   city_all.geo_loc_x,
	   city_all.geo_loc_y,
	   city_all.geo_radius,
	   city_all.geo_update_time,
	   city_all.fullname,
	   city_all.only_sim,
	   city_all.yandexname
FROM city_all
WHERE city_all.only_sim = 1;

ALTER TABLE city
	OWNER TO postgres;

