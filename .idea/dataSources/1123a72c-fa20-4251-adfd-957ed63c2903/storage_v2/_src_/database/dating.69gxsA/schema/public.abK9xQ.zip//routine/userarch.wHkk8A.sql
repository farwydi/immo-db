CREATE FUNCTION userarch() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
INSERT INTO user_arch VALUES (old.*); 
RETURN NULL;
END;
$$;

ALTER FUNCTION userarch() OWNER TO postgres;

