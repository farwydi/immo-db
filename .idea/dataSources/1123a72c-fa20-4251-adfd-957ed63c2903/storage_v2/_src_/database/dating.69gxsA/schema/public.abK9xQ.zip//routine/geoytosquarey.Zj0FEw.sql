CREATE FUNCTION geoytosquarey(geo_y integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
BEGIN
					RETURN 	ceil( distance_in_km( geo_y,  950000, 600000, 950000)::float / 3 )
						* (CASE WHEN geo_y < 600000 THEN -1 ELSE 1 END)
						;
					END;

$$;

ALTER FUNCTION geoytosquarey(INTEGER) OWNER TO postgres;

