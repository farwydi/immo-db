CREATE FUNCTION heaver_sin(double precision) RETURNS double precision
	LANGUAGE sql
AS
$$
SELECT power(sin($1/2.0), 2);

$$;

ALTER FUNCTION heaver_sin(DOUBLE PRECISION) OWNER TO postgres;

