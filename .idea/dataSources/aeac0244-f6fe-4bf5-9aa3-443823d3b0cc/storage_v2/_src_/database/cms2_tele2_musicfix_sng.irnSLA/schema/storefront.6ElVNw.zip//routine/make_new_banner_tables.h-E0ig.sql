CREATE FUNCTION make_new_banner_tables() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
BEGIN
  

  DROP TABLE IF EXISTS banner_resolution_new;DROP TABLE IF EXISTS banner_file_new;DROP TABLE IF EXISTS banner_block_relation_new;DROP TABLE IF EXISTS banner_new;DROP TABLE IF EXISTS banner_block_new;DROP TABLE IF EXISTS banner_type_new;CREATE TABLE banner_type_new
  (
    banner_type_id integer NOT NULL,
    name character varying(50) NOT NULL  
  ) 
  WITHOUT OIDS;ALTER TABLE banner_type_new OWNER TO postgres;GRANT ALL ON TABLE banner_type_new  TO postgres;GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE banner_type_new TO inform;CREATE TABLE banner_block_new
  (
    banner_block_id serial NOT NULL,
    name character varying(255) NOT NULL,
    description text
  ) 
  WITHOUT OIDS;ALTER TABLE banner_block_new OWNER TO postgres;GRANT ALL ON TABLE banner_block_new  TO postgres;GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE banner_block_new TO inform;CREATE TABLE banner_new
  (
    banner_id serial NOT NULL,
    banner_type_id integer NOT NULL,
    name character varying(255) NOT NULL,
    text text,
    text_color character varying(50),
    background_color character varying(50),
    url character varying(255),
    week_day smallint
  ) 
  WITHOUT OIDS;ALTER TABLE banner_new OWNER TO postgres;GRANT ALL ON TABLE banner_new  TO postgres;GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE banner_new TO inform;CREATE TABLE banner_block_relation_new
  (
    banner_block_id integer NOT NULL,
    banner_id integer NOT NULL,
    rating smallint,
    start_date timestamp without time zone,
    end_date timestamp without time zone
  ) 
  WITHOUT OIDS;ALTER TABLE banner_block_relation_new OWNER TO postgres;GRANT ALL ON TABLE banner_block_relation_new TO postgres;GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE banner_block_relation_new TO inform;CREATE TABLE banner_file_new
  (
    banner_file_id serial NOT NULL,
    banner_id integer NOT NULL,
    fat_name character varying(50) NOT NULL
  ) 
  WITHOUT OIDS;ALTER TABLE banner_file_new OWNER TO postgres;GRANT ALL ON TABLE banner_file_new TO postgres;GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE banner_file_new TO inform;CREATE TABLE banner_resolution_new
  (
    banner_resolution_id serial NOT NULL,
    banner_file_id integer NOT NULL,
    height smallint NOT NULL,
    width smallint NOT NULL
  ) 
  WITHOUT OIDS;ALTER TABLE banner_resolution_new OWNER TO postgres;GRANT ALL ON TABLE banner_resolution_new TO postgres;GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE banner_resolution_new TO inform;END;
$$;

ALTER FUNCTION make_new_banner_tables() OWNER TO postgres;

