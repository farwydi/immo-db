CREATE FUNCTION "overlaps"(timestamp without time zone, interval, timestamp without time zone, interval) RETURNS boolean
	IMMUTABLE
	COST 1
	LANGUAGE sql
AS
$$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;

COMMENT ON FUNCTION "overlaps"(TIMESTAMP, INTERVAL, TIMESTAMP, INTERVAL) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIMESTAMP, INTERVAL, TIMESTAMP, INTERVAL) OWNER TO postgres;

