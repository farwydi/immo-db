CREATE FUNCTION stat_data_per_date() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
            table_name char(30);
            BEGIN
              table_name = to_char(NEW.request_time, 'YYYY_MM_DD');
              EXECUTE 'insert into stat_data_' || table_name || ' select $1.*'
              using NEW;
              RETURN NULL;
            END;
$$;

ALTER FUNCTION stat_data_per_date() OWNER TO postgres;

