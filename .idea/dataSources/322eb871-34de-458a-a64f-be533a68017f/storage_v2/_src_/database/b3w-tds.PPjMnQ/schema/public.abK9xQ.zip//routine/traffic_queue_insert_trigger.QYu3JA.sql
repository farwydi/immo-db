CREATE FUNCTION traffic_queue_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
                                IF (NEW.go_id % 4 = 1) THEN
                                EXECUTE 'insert into traffic_queue_1 select $1.*' using NEW;
                                ELSIF (NEW.go_id % 4 = 2) THEN
                                EXECUTE 'insert into traffic_queue_2 select $1.*' using NEW;
                                ELSIF (NEW.go_id % 4 = 3) THEN
                                EXECUTE 'insert into traffic_queue_3 select $1.*' using NEW;
                                ELSE
                                EXECUTE 'insert into traffic_queue_4 select $1.*' using NEW;
                                END IF;
                            RETURN NULL;
                            END;
$$;

ALTER FUNCTION traffic_queue_insert_trigger() OWNER TO postgres;

