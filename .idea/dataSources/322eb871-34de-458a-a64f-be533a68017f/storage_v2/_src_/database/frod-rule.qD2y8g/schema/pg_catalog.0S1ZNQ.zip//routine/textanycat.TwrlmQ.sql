CREATE FUNCTION textanycat(text, anynonarray) RETURNS text
	STABLE
	STRICT
	COST 1
	LANGUAGE sql
AS
$$
select $1 || $2::pg_catalog.text
$$;

COMMENT ON FUNCTION textanycat(TEXT, ANYNONARRAY) IS 'implementation of || operator';

ALTER FUNCTION textanycat(TEXT, ANYNONARRAY) OWNER TO postgres;

