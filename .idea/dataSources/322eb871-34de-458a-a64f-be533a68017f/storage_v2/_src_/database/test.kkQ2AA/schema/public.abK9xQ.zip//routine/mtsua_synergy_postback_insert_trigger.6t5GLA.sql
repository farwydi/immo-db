CREATE FUNCTION mtsua_synergy_postback_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    if (extract(month from NEW.create_datetime) = 1) THEN INSERT INTO public.mtsua_synergy_postback_1 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 2) THEN INSERT INTO public.mtsua_synergy_postback_2 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 3) THEN INSERT INTO public.mtsua_synergy_postback_3 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 4) THEN INSERT INTO public.mtsua_synergy_postback_4 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 5) THEN INSERT INTO public.mtsua_synergy_postback_5 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 6) THEN INSERT INTO public.mtsua_synergy_postback_6 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 7) THEN INSERT INTO public.mtsua_synergy_postback_7 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 8) THEN INSERT INTO public.mtsua_synergy_postback_8 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 9) THEN INSERT INTO public.mtsua_synergy_postback_9 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 10) THEN INSERT INTO public.mtsua_synergy_postback_10 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 11) THEN INSERT INTO public.mtsua_synergy_postback_11 VALUES (NEW.*);
    elseif (extract(month from NEW.create_datetime) = 12) THEN INSERT INTO public.mtsua_synergy_postback_12 VALUES (NEW.*);
    end if;
    RETURN null;
END;
$$;

ALTER FUNCTION mtsua_synergy_postback_insert_trigger() OWNER TO postgres;

