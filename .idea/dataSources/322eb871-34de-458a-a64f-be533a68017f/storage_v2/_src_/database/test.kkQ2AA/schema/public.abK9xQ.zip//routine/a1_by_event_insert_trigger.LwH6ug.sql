CREATE FUNCTION a1_by_event_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    if NEW.event_datetime is null then    INSERT INTO public.a1_by_event_other VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 1) THEN INSERT INTO public.a1_by_event_1 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 2) THEN INSERT INTO public.a1_by_event_2 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 3) THEN INSERT INTO public.a1_by_event_3 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 4) THEN INSERT INTO public.a1_by_event_4 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 5) THEN INSERT INTO public.a1_by_event_5 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 6) THEN INSERT INTO public.a1_by_event_6 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 7) THEN INSERT INTO public.a1_by_event_7 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 8) THEN INSERT INTO public.a1_by_event_8 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 9) THEN INSERT INTO public.a1_by_event_9 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 10) THEN INSERT INTO public.a1_by_event_10 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 11) THEN INSERT INTO public.a1_by_event_11 VALUES (NEW.*);
    elseif (extract(month from NEW.event_datetime) = 12) THEN INSERT INTO public.a1_by_event_12 VALUES (NEW.*);
    end if;
    RETURN null;
END;
$$;

ALTER FUNCTION a1_by_event_insert_trigger() OWNER TO inform;

