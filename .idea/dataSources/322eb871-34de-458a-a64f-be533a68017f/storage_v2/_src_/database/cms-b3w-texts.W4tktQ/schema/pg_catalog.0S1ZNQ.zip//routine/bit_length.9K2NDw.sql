CREATE FUNCTION bit_length(bit) RETURNS integer
	IMMUTABLE
	STRICT
	COST 1
	LANGUAGE sql
AS
$$
select pg_catalog.length($1)
$$;

COMMENT ON FUNCTION bit_length(BIT) IS 'length in bits';

ALTER FUNCTION bit_length(BIT) OWNER TO postgres;

