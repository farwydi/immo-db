CREATE FUNCTION to_timestamp(double precision) RETURNS timestamp with time zone
	IMMUTABLE
	STRICT
	COST 1
	LANGUAGE sql
AS
$$
select ('epoch'::pg_catalog.timestamptz + $1 * '1 second'::pg_catalog.interval)
$$;

COMMENT ON FUNCTION to_timestamp(DOUBLE PRECISION) IS 'convert UNIX epoch to timestamptz';

ALTER FUNCTION to_timestamp(DOUBLE PRECISION) OWNER TO postgres;

