CREATE FUNCTION date_part(text, reltime) RETURNS double precision
	STABLE
	STRICT
	COST 1
	LANGUAGE sql
AS
$$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$$;

COMMENT ON FUNCTION date_part(TEXT, RELTIME) IS 'extract field from reltime';

ALTER FUNCTION date_part(TEXT, RELTIME) OWNER TO postgres;

