CREATE FUNCTION testingbilling() RETURNS boolean
	LANGUAGE plpgsql
AS
$$
DECLARE
        month_num int;
        cnt int;
    BEGIN
        for month_num in 1..12 loop
            execute 'insert into billing (msisdn, real_datetime, create_datetime, status, param, cpa_log, fault_code, service_id)
values (123, ''2019-'||month_num||'-19 00:00:00'', now()::timestamp(0), 0, 1, false, 111, 100);';
            if (select count(1) from billing where id = (select currval('billing_id_seq'))) != 1 then
                return false;
            end if;
            if (select count(1) from only billing where id = (select currval('billing_id_seq'))) != 0 then
                return false;
            end if;
            execute 'select count(1) from billing_'||month_num::varchar||' where id = (select currval(''billing_id_seq''))' using cnt;
            if cnt != 1 then
                return false;
            end if;
        end loop;
        return true;
    END
$$;

ALTER FUNCTION testingbilling() OWNER TO postgres;

