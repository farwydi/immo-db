CREATE FUNCTION testingbillinghistorylife() RETURNS boolean
	LANGUAGE plpgsql
AS
$$
DECLARE
        month_num int;
        cnt int;
    BEGIN
        for month_num in 1..12 loop
            execute 'insert into billing_history_life (status, msisdn, spare_field1, spare_field2, create_date, param, cpa_log)
values (0, 123, 0, '''', ''2019-'||month_num||'-19 00:00:00'', 0, false);';
            if (select count(1) from billing_history_life where id = (select currval('billing_history_life_id_seq'))) != 1 then
                return false;
            end if;
            if (select count(1) from only billing_history_life where id = (select currval('billing_history_life_id_seq'))) != 0 then
                return false;
            end if;
            execute 'select count(1) from billing_history_life_'||month_num::varchar||' where id = (select currval(''billing_history_life_id_seq''))' using cnt;
            if cnt != 1 then
                return false;
            end if;
        end loop;
        return true;
    END
$$;

ALTER FUNCTION testingbillinghistorylife() OWNER TO postgres;

