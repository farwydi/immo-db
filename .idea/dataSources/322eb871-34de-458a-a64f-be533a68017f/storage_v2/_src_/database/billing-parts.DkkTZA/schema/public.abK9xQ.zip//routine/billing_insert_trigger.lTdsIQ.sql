CREATE FUNCTION billing_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
        tb_name varchar;
        month_num varchar;
    BEGIN
        
        month_num := extract(month from NEW.real_datetime)::varchar;
        tb_name := TG_TABLE_NAME || '_' || month_num;
        execute 'insert into '||tb_name||' values ($1.*)' using (NEW);
        RETURN null;
    END;
$$;

ALTER FUNCTION billing_insert_trigger() OWNER TO inform;

