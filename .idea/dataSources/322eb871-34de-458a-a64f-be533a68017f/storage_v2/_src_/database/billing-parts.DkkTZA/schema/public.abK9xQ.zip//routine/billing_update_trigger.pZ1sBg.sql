CREATE FUNCTION billing_update_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        RAISE NOTICE 'Произошло событие: update create_date';
        --NEW.spare_field1 := old.spare_field1 + 1;
        RETURN null;
    END;
$$;

ALTER FUNCTION billing_update_trigger() OWNER TO postgres;

