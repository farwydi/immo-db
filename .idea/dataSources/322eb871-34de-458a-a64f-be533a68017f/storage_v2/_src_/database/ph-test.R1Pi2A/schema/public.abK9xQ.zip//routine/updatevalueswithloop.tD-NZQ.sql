CREATE FUNCTION updatevalueswithloop() RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
    r UUID;
BEGIN
	FOR r IN SELECT id FROM content LOOP
		UPDATE content
		SET
			data_add=(select NOW() + (random() * (NOW()+'90 days' - NOW())) + '30 days'),
			views=(select random() * 1000 + 100),
			likes=(select random() * 1000 + 100)
		WHERE id = r;
	END LOOP;
RETURN;
END;
$$;

ALTER FUNCTION updatevalueswithloop() OWNER TO postgres;

