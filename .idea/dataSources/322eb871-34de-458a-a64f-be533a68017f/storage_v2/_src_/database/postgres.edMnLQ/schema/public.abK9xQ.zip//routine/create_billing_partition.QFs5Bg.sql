CREATE FUNCTION create_billing_partition(month_num character varying, base_table character varying) RETURNS text
	LANGUAGE plpgsql
AS
$$
DECLARE
        table_n varchar;
        _query varchar;
        date_field varchar;
    BEGIN
        table_n := base_table || '_' || month_num;
        if base_table = 'billing_history_life' then date_field := 'create_date'::varchar;
        else date_field := 'real_datetime'::varchar;
        end if;
        return 'CREATE TABLE if not exists '||table_n||' (LIKE '||base_table||' INCLUDING DEFAULTS INCLUDING CONSTRAINTS)';
        execute 'ALTER TABLE '||table_n||' ADD CONSTRAINT '||table_n||'_pkey PRIMARY KEY (id)';
        _query := format(
            'ALTER TABLE '||table_n||' ADD CONSTRAINT '||table_n||'_date_check CHECK (date_part(''month'', '||date_field||') = %s)',
            month_num
        );
        execute  _query;
        execute 'GRANT ALL ON TABLE '||table_n||' TO postgres, inform';
        return table_n;
    END
$$;

ALTER FUNCTION create_billing_partition(VARCHAR, VARCHAR) OWNER TO postgres;

