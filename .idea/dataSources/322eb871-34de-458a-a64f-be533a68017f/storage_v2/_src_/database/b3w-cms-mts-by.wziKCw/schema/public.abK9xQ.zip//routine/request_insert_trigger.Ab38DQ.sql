CREATE FUNCTION request_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    if
        NEW.create_date is null then INSERT INTO public.request_other VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 1) THEN INSERT INTO public.request_d_1 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 2) THEN INSERT INTO public.request_d_2 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 3) THEN INSERT INTO public.request_d_3 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 4) THEN INSERT INTO public.request_d_4 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 5) THEN INSERT INTO public.request_d_5 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 6) THEN INSERT INTO public.request_d_6 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 7) THEN INSERT INTO public.request_d_7 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 8) THEN INSERT INTO public.request_d_8 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 9) THEN INSERT INTO public.request_d_9 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 10) THEN INSERT INTO public.request_d_10 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 11) THEN INSERT INTO public.request_d_11 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 12) THEN INSERT INTO public.request_d_12 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 13) THEN INSERT INTO public.request_d_13 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 14) THEN INSERT INTO public.request_d_14 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 15) THEN INSERT INTO public.request_d_15 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 16) THEN INSERT INTO public.request_d_16 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 17) THEN INSERT INTO public.request_d_17 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 18) THEN INSERT INTO public.request_d_18 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 19) THEN INSERT INTO public.request_d_19 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 20) THEN INSERT INTO public.request_d_20 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 21) THEN INSERT INTO public.request_d_21 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 22) THEN INSERT INTO public.request_d_22 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 23) THEN INSERT INTO public.request_d_23 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 24) THEN INSERT INTO public.request_d_24 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 25) THEN INSERT INTO public.request_d_25 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 26) THEN INSERT INTO public.request_d_26 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 27) THEN INSERT INTO public.request_d_27 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 28) THEN INSERT INTO public.request_d_28 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 29) THEN INSERT INTO public.request_d_29 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 30) THEN INSERT INTO public.request_d_30 VALUES (NEW.*);
        elseif (extract(day from NEW.create_date) = 31) THEN INSERT INTO public.request_d_31 VALUES (NEW.*);
    end if;
    RETURN null;
END;
$$;

ALTER FUNCTION request_insert_trigger() OWNER TO inform;

