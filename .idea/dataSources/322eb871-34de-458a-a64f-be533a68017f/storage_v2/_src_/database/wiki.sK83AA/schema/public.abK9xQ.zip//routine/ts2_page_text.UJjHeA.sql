CREATE FUNCTION ts2_page_text() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
 IF TG_OP = 'INSERT' THEN
 NEW.textvector = to_tsvector(NEW.old_text);
 ELSIF NEW.old_text != OLD.old_text THEN
 NEW.textvector := to_tsvector(NEW.old_text);
 END IF;
 RETURN NEW;
 END;
$$;

ALTER FUNCTION ts2_page_text() OWNER TO inform;

