CREATE FUNCTION add_interwiki(text, integer, smallint) RETURNS integer
	LANGUAGE sql
AS
$$
INSERT INTO interwiki (iw_prefix, iw_url, iw_local) VALUES ($1,$2,$3);
 SELECT 1;
$$;

ALTER FUNCTION add_interwiki(TEXT, INTEGER, SMALLINT) OWNER TO inform;

