CREATE FUNCTION userdetarch() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        INSERT INTO user_details_arch VALUES (old.*);        
        
    RETURN NULL;
END;
$$;

ALTER FUNCTION userdetarch() OWNER TO postgres;

