CREATE FUNCTION comparebit(personbit bit, partnerbit bit) RETURNS integer
	COST 1
	LANGUAGE plpgsql
AS
$$
declare
 comp bit(25) := personbit & partnerbit;
 --ident integer;
 --result integer;
begin
 return (select count(*) from (select regexp_matches(comp::varchar,'1','ig')) t);
/*
 ident := bit_length(comp);
 if comp = null then 
  return 0;
 end if;
 result := 0;
 while (ident > 0) loop
  ident := ident - 1;
  result := result + cast(substring(comp,ident,1) as integer);
 end loop;
 return result;
*/
end;
$$;

ALTER FUNCTION comparebit(BIT, BIT) OWNER TO postgres;

