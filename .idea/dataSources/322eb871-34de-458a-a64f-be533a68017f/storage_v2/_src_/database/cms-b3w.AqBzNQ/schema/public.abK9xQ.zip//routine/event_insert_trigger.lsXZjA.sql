CREATE FUNCTION event_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
      partition_date TEXT;
      partition TEXT;
    BEGIN
      partition_date := to_char(NEW.event_datetime,'YYYY_MM_DD');
      partition := TG_RELNAME || '_' || partition_date;
      IF NOT EXISTS(SELECT relname FROM pg_class WHERE relname=partition) THEN
        RAISE NOTICE 'A partition has been created %',partition;
				EXECUTE 'CREATE TABLE ' || partition || ' ( like ' || TG_RELNAME || ' including all );';
				EXECUTE 'ALTER TABLE ' || partition || ' inherit ' || TG_RELNAME || ';';
      END IF;
      EXECUTE 'INSERT INTO ' || partition || ' SELECT(' || TG_RELNAME || ' ' || quote_literal(NEW) || ').* RETURNING id;';
      RETURN NULL;
    END;
$$;

ALTER FUNCTION event_insert_trigger() OWNER TO postgres;

