CREATE FUNCTION testingbillingvelcom() RETURNS boolean
	LANGUAGE plpgsql
AS
$$
DECLARE
        month_num int;
        cnt int;
    BEGIN
        for month_num in 1..12 loop
            execute 'insert into billing_velcom (msisdn, real_datetime, create_datetime, status, param, cpa_log, fault_code, service_id)
            values (123, ''2019-'||month_num||'-02 00:00:00'', now()::timestamp(0), 0, 1, false, 111, 100)';
            if (select count(1) from billing_velcom where id = (select currval('billing_velcom_id_seq'))) != 1 then
                return false;
            end if;
            if (select count(1) from only billing_velcom where id = (select currval('billing_velcom_id_seq'))) != 0 then
                return false;
            end if;
            execute 'select count(1) from billing_velcom_'||month_num::varchar||' where id = (select currval(''billing_velcom_id_seq''))' using cnt;
            if cnt != 1 then
                return false;
            end if;
        end loop;
        return true;
    END
$$;

ALTER FUNCTION testingbillingvelcom() OWNER TO postgres;

