CREATE FUNCTION create_billing_partition(month_num character varying, base_table character varying) RETURNS text
	LANGUAGE plpgsql
AS
$$
DECLARE
        table_n varchar;
        _query varchar;
    BEGIN
        table_n := base_table || '_' || month_num;
        _query := format('CREATE TABLE if not exists '||table_n||' (
    CONSTRAINT '||table_n||'_pkey PRIMARY KEY (id),
    CONSTRAINT '||table_n||'_date_check CHECK (date_part(''month'', real_datetime) = %s)
) INHERITS ('||base_table||') WITH (OIDS=FALSE);
GRANT ALL ON TABLE '||table_n||' TO postgres, inform;', month_num);
        return _query;
        execute  _query;
        execute 'GRANT ALL ON TABLE '||table_n||' TO postgres, inform;';
        return table_n;
    END
$$;

ALTER FUNCTION create_billing_partition(VARCHAR, VARCHAR) OWNER TO postgres;

