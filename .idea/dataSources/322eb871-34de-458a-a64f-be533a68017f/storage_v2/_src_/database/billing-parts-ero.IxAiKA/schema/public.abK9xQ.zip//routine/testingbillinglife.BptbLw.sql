CREATE FUNCTION testingbillinglife() RETURNS boolean
	LANGUAGE plpgsql
AS
$$
DECLARE
        month_num int;
        cnt int;
    BEGIN
        for month_num in 1..12 loop
            execute 'insert into billing_life (msisdn, real_datetime, create_datetime, status, param, cpa_log, fault_code, imported,service_id, sent_count, additional_info, rule_id, context, date_create)
values (123, ''2019-'||month_num||'-19 00:00:00'', now()::timestamp(0), 0, 1, false, 111, true,100,0,'''',0,'''', now()::timestamp(0))';
            if (select count(1) from billing_life where id = (select currval('billing_life_id_seq'))) != 1 then
                return false;
            end if;
            if (select count(1) from only billing_life where id = (select currval('billing_life_id_seq'))) != 0 then
                return false;
            end if;
            execute 'select count(1) from billing_life_'||month_num||' where id = (select currval(''billing_life_id_seq''))' using cnt;
            if cnt != 1 then
                return false;
            end if;
        end loop;
        return true;
    END
$$;

ALTER FUNCTION testingbillinglife() OWNER TO postgres;

