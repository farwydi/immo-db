CREATE VIEW constraint_column_usage
			(table_catalog, table_schema, table_name, column_name, constraint_catalog, constraint_schema,
			 constraint_name) AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS table_catalog,
	   x.tblschema::information_schema.SQL_IDENTIFIER        AS table_schema,
	   x.tblname::information_schema.SQL_IDENTIFIER          AS table_name,
	   x.colname::information_schema.SQL_IDENTIFIER          AS column_name,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
	   x.cstrschema::information_schema.SQL_IDENTIFIER       AS constraint_schema,
	   x.cstrname::information_schema.SQL_IDENTIFIER         AS constraint_name
FROM (SELECT DISTINCT nr.nspname,
					  r.relname,
					  r.relowner,
					  a.attname,
					  nc.nspname,
					  c.conname
	  FROM pg_namespace nr,
		   pg_class r,
		   pg_attribute a,
		   pg_depend d,
		   pg_namespace nc,
		   pg_constraint c
	  WHERE nr.oid = r.relnamespace
		AND r.oid = a.attrelid
		AND d.refclassid = 'pg_class'::REGCLASS::OID
		AND d.refobjid = r.oid
		AND d.refobjsubid = a.attnum
		AND d.classid = 'pg_constraint'::REGCLASS::OID
		AND d.objid = c.oid
		AND c.connamespace = nc.oid
		AND c.contype = 'c'::"char"
		AND r.relkind = 'r'::"char"
		AND NOT a.attisdropped
	  UNION ALL
	  SELECT nr.nspname,
			 r.relname,
			 r.relowner,
			 a.attname,
			 nc.nspname,
			 c.conname
	  FROM pg_namespace nr,
		   pg_class r,
		   pg_attribute a,
		   pg_namespace nc,
		   pg_constraint c
	  WHERE nr.oid = r.relnamespace
		AND r.oid = a.attrelid
		AND nc.oid = c.connamespace
		AND CASE
				WHEN c.contype = 'f'::"char" THEN r.oid = c.confrelid AND (a.attnum = ANY (c.confkey))
				ELSE r.oid = c.conrelid AND (a.attnum = ANY (c.conkey))
		  END
		AND NOT a.attisdropped
		AND (c.contype = ANY (ARRAY ['p'::"char", 'u'::"char", 'f'::"char"]))
		AND r.relkind = 'r'::"char") x(tblschema, tblname, tblowner, colname, cstrschema, cstrname)
WHERE PG_HAS_ROLE(x.tblowner, 'USAGE'::TEXT);

ALTER TABLE constraint_column_usage
	OWNER TO postgres;

