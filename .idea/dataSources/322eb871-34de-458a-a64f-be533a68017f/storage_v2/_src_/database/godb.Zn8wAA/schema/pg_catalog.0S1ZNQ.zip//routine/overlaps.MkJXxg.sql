CREATE FUNCTION "overlaps"(timestamp without time zone, timestamp without time zone, timestamp without time zone, interval) RETURNS boolean
	IMMUTABLE
	COST 1
	LANGUAGE sql
AS
$$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;

COMMENT ON FUNCTION "overlaps"(TIMESTAMP, TIMESTAMP, TIMESTAMP, INTERVAL) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIMESTAMP, TIMESTAMP, TIMESTAMP, INTERVAL) OWNER TO postgres;

