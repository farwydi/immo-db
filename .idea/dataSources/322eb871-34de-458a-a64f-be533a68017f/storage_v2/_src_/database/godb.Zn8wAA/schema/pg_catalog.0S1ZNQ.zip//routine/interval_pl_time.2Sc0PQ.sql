CREATE FUNCTION interval_pl_time(interval, time without time zone) RETURNS time without time zone
	IMMUTABLE
	STRICT
	COST 1
	LANGUAGE sql
AS
$$
select $2 + $1
$$;

COMMENT ON FUNCTION interval_pl_time(INTERVAL, TIME) IS 'implementation of + operator';

ALTER FUNCTION interval_pl_time(INTERVAL, TIME) OWNER TO postgres;

