CREATE FUNCTION cpa_subs_stat_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
	tableExists int;
	tableName text;
BEGIN
	IF (NEW.serviceid > 0) THEN
		tableName = 'cpa_subs_stat_'  || NEW.serviceid;
		execute 'select count(*) from pg_class where relname=''' || tableName || ''' and relkind=''r'' ' INTO tableExists;
		IF tableExists > 0 THEN 
			RAISE NOTICE 'Table exists';
		ELSE
			RAISE NOTICE 'Table not exists';
			execute 'CREATE TABLE ' || tableName || ' (LIKE cpa_subs_stat INCLUDING ALL)';
			execute 'ALTER TABLE ' || tableName || ' ADD CHECK (serviceid = ' || NEW.serviceid || ' )';			
			execute 'ALTER TABLE ' || tableName || ' ADD CONSTRAINT '|| tableName ||'_pkey PRIMARY KEY(id)';
			execute 'ALTER TABLE ' || tableName || ' INHERIT cpa_subs_stat';			
		END IF;
	END IF;

    IF (NEW.serviceid = 1) THEN
        INSERT INTO public.cpa_subs_stat_1 VALUES (NEW.*);
    ELSE 
        EXECUTE 'insert into cpa_subs_stat_'|| NEW.serviceid || ' select $1.*' using NEW;
    END IF;
    RETURN NULL;
END;
$$;

ALTER FUNCTION cpa_subs_stat_insert_trigger() OWNER TO inform;

