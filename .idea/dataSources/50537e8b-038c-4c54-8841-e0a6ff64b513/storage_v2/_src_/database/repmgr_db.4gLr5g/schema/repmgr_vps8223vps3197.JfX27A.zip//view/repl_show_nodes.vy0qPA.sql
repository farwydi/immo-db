CREATE VIEW repl_show_nodes (id, conninfo, type, name, cluster, priority, active, upstream_node_name) AS
SELECT rn.id,
	   rn.conninfo,
	   rn.type,
	   rn.name,
	   rn.cluster,
	   rn.priority,
	   rn.active,
	   sq.name AS upstream_node_name
FROM repmgr_vps8223vps3197.repl_nodes rn
		 LEFT JOIN repmgr_vps8223vps3197.repl_nodes sq ON sq.id = rn.upstream_node_id;

ALTER TABLE repl_show_nodes
	OWNER TO postgres;

