CREATE VIEW repl_status
			(primary_node, standby_node, standby_name, node_type, active, last_monitor_time, last_wal_primary_location,
			 last_wal_standby_location, replication_lag, replication_time_lag, apply_lag, communication_time_lag)
AS
SELECT m.primary_node,
	   m.standby_node,
	   n.name       AS standby_name,
	   n.type       AS node_type,
	   n.active,
	   m.last_monitor_time,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN m.last_wal_primary_location
		   ELSE NULL::TEXT
		   END      AS last_wal_primary_location,
	   m.last_wal_standby_location,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN PG_SIZE_PRETTY(m.replication_lag)
		   ELSE NULL::TEXT
		   END      AS replication_lag,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN AGE(NOW(), m.last_apply_time)
		   ELSE NULL::INTERVAL
		   END      AS replication_time_lag,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN PG_SIZE_PRETTY(m.apply_lag)
		   ELSE NULL::TEXT
		   END      AS apply_lag,
	   AGE(NOW(),
		   CASE
			   WHEN PG_IS_IN_RECOVERY() THEN repmgr_vps8223vps3197.repmgr_get_last_updated()
			   ELSE m.last_monitor_time
			   END) AS communication_time_lag
FROM repmgr_vps8223vps3197.repl_monitor m
		 JOIN repmgr_vps8223vps3197.repl_nodes n ON m.standby_node = n.id
WHERE ((m.standby_node, m.last_monitor_time) IN (SELECT m1.standby_node,
														MAX(m1.last_monitor_time) AS max
												 FROM repmgr_vps8223vps3197.repl_monitor m1
												 GROUP BY m1.standby_node));

ALTER TABLE repl_status
	OWNER TO postgres;

