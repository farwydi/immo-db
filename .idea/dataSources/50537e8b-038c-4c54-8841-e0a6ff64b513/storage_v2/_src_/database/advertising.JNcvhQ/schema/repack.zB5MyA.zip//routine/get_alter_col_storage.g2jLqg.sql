CREATE FUNCTION get_alter_col_storage(oid) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT 'ALTER TABLE repack.table_' || $1 || array_to_string(column_storage, ',')
 FROM (
       SELECT
         repack.array_accum(' ALTER ' || quote_ident(attname) ||
          CASE attstorage
               WHEN 'p' THEN ' SET STORAGE PLAIN'
               WHEN 'm' THEN ' SET STORAGE MAIN'
               WHEN 'e' THEN ' SET STORAGE EXTERNAL'
               WHEN 'x' THEN ' SET STORAGE EXTENDED'
          END) AS column_storage
       FROM (
            SELECT *
            FROM pg_attribute a
                 JOIN pg_type t on t.oid = atttypid
                 JOIN pg_class r on r.oid = a.attrelid
                 JOIN pg_namespace s on s.oid = r.relnamespace
            WHERE typstorage <> attstorage
                 AND attrelid = $1
                 AND attnum > 0
                 AND NOT attisdropped
           ORDER BY attnum
	   ) T
      ) T
WHERE array_upper(column_storage , 1) > 0
$$;

ALTER FUNCTION get_alter_col_storage(OID) OWNER TO postgres;

