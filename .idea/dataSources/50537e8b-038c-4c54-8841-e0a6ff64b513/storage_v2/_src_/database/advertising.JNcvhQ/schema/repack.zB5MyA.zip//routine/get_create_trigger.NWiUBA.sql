CREATE FUNCTION get_create_trigger(relid oid, pkid oid) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT 'CREATE TRIGGER repack_trigger' ||
         ' AFTER INSERT OR DELETE OR UPDATE ON ' || repack.oid2text($1) ||
         ' FOR EACH ROW EXECUTE PROCEDURE repack.repack_trigger(' ||
         '''INSERT INTO repack.log_' || $1 || '(pk, row) VALUES(' ||
         ' CASE WHEN $1 IS NULL THEN NULL ELSE (ROW($1.' ||
         repack.get_index_columns($2, ', $1.') || ')::repack.pk_' ||
         $1 || ') END, $2)'')';
$$;

ALTER FUNCTION get_create_trigger(OID, OID) OWNER TO postgres;

