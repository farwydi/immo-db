CREATE VIEW tables
			(relname, relid, reltoastrelid, reltoastidxid, schemaname, pkid, ckid, create_pktype, create_log,
			 create_trigger, enable_trigger, create_table_1, tablespace_orig, create_table_2, copy_data,
			 alter_col_storage, drop_columns, delete_log, lock_table, ckey, sql_peek, sql_insert, sql_delete,
			 sql_update, sql_pop)
AS
SELECT r.oid::REGCLASS                                                                              AS relname,
	   r.oid                                                                                        AS relid,
	   r.reltoastrelid,
	   CASE
		   WHEN r.reltoastrelid = 0::OID THEN 0::OID
		   ELSE (SELECT pg_index.indexrelid
				 FROM pg_index
				 WHERE pg_index.indrelid = r.reltoastrelid
				   AND pg_index.indisvalid)
		   END                                                                                      AS reltoastidxid,
	   n.nspname                                                                                    AS schemaname,
	   pk.indexrelid                                                                                AS pkid,
	   ck.indexrelid                                                                                AS ckid,
	   repack.get_create_index_type(pk.indexrelid, ('repack.pk_'::TEXT || r.oid)::NAME)             AS create_pktype,
	   ((((('CREATE TABLE repack.log_'::TEXT || r.oid) || ' (id bigserial PRIMARY KEY, pk repack.pk_'::TEXT) ||
		  r.oid) || ', row '::TEXT) || repack.oid2text(r.oid)) || ')'::TEXT                         AS create_log,
	   repack.get_create_trigger(r.oid, pk.indexrelid)                                              AS create_trigger,
	   repack.get_enable_trigger(r.oid)                                                             AS enable_trigger,
	   ((('CREATE TABLE repack.table_'::TEXT || r.oid) || ' WITH ('::TEXT) || repack.get_storage_param(r.oid)) ||
	   ') TABLESPACE '::TEXT                                                                        AS create_table_1,
	   COALESCE(QUOTE_IDENT(s.spcname::TEXT), 'pg_default'::TEXT)                                   AS tablespace_orig,
	   ((' AS SELECT '::TEXT || repack.get_columns_for_create_as(r.oid)) || ' FROM ONLY '::TEXT) ||
	   repack.oid2text(r.oid)                                                                       AS create_table_2,
	   (((('INSERT INTO repack.table_'::TEXT || r.oid) || ' SELECT '::TEXT) ||
		 repack.get_columns_for_create_as(r.oid)) || ' FROM ONLY '::TEXT) || repack.oid2text(r.oid) AS copy_data,
	   repack.get_alter_col_storage(r.oid)                                                          AS alter_col_storage,
	   repack.get_drop_columns(r.oid, 'repack.table_'::TEXT || r.oid)                               AS drop_columns,
	   'DELETE FROM repack.log_'::TEXT || r.oid                                                     AS delete_log,
	   ('LOCK TABLE '::TEXT || repack.oid2text(r.oid)) || ' IN ACCESS EXCLUSIVE MODE'::TEXT         AS lock_table,
	   repack.get_order_by(ck.indexrelid, r.oid)                                                    AS ckey,
	   ('SELECT * FROM repack.log_'::TEXT || r.oid) || ' ORDER BY id LIMIT $1'::TEXT                AS sql_peek,
	   ('INSERT INTO repack.table_'::TEXT || r.oid) || ' VALUES ($1.*)'::TEXT                       AS sql_insert,
	   (('DELETE FROM repack.table_'::TEXT || r.oid) || ' WHERE '::TEXT) ||
	   repack.get_compare_pkey(pk.indexrelid, '$1'::TEXT)                                           AS sql_delete,
	   (((('UPDATE repack.table_'::TEXT || r.oid) || ' SET '::TEXT) || repack.get_assign(r.oid, '$2'::TEXT)) ||
		' WHERE '::TEXT) || repack.get_compare_pkey(pk.indexrelid, '$1'::TEXT)                      AS sql_update,
	   ('DELETE FROM repack.log_'::TEXT || r.oid) || ' WHERE id IN ('::TEXT                         AS sql_pop
FROM pg_class r
		 LEFT JOIN pg_class t ON r.reltoastrelid = t.oid
		 LEFT JOIN repack.primary_keys pk ON r.oid = pk.indrelid
		 LEFT JOIN (SELECT cki.indexrelid,
						   cki.indrelid,
						   cki.indnatts,
						   cki.indisunique,
						   cki.indisprimary,
						   cki.indisexclusion,
						   cki.indimmediate,
						   cki.indisclustered,
						   cki.indisvalid,
						   cki.indcheckxmin,
						   cki.indisready,
						   cki.indislive,
						   cki.indisreplident,
						   cki.indkey,
						   cki.indcollation,
						   cki.indclass,
						   cki.indoption,
						   cki.indexprs,
						   cki.indpred
					FROM pg_index cki,
						 pg_class ckt
					WHERE cki.indisvalid
					  AND cki.indexrelid = ckt.oid
					  AND cki.indisclustered
					  AND ckt.relam = 403::OID) ck ON r.oid = ck.indrelid
		 LEFT JOIN pg_namespace n ON n.oid = r.relnamespace
		 LEFT JOIN pg_tablespace s ON s.oid = r.reltablespace
WHERE r.relkind = 'r'::"char"
  AND r.relpersistence = 'p'::"char"
  AND (n.nspname <> ALL (ARRAY ['pg_catalog'::NAME, 'information_schema'::NAME]))
  AND n.nspname !~~ 'pg\_temp\_%'::TEXT;

ALTER TABLE tables
	OWNER TO postgres;

