CREATE FUNCTION monthly_partition_check(basename text, date date) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	tableExists int;
	tableName text;
	limitLower text;
	limitUpper text;
BEGIN
	tableName = basename || '_part_'  || extract('year' from date) || '_' || extract('month' from date);
	execute 'select count(*) from pg_class where relname=''' || tableName || ''' and relkind=''r'' ' INTO tableExists;
	--RAISE NOTICE 'Table exists result: %s, comparison: %s', tableExists, (tableExists>0);
	IF tableExists > 0
	THEN 
		RAISE NOTICE 'Table exists';
	ELSE
		RAISE NOTICE 'Table not exists';
		execute 'CREATE TABLE ' || tableName || ' (LIKE ' || basename || '_part_proto INCLUDING ALL)';
		limitLower = date_trunc('month', date);
		execute 'SELECT ''' || limitLower || '''::date + interval ''1 month'' ' into limitUpper;
		execute 'ALTER TABLE ' || tableName || ' ADD CHECK (time >= ''' || limitLower || '''::date and time < ''' || limitUpper || '''::date )';
		execute 'ALTER TABLE ' || tableName || ' INHERIT ' || basename || '_master';
	END IF;
END;
$$;

ALTER FUNCTION monthly_partition_check(TEXT, DATE) OWNER TO inform;

