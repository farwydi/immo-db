CREATE FUNCTION version_sql() RETURNS text
	IMMUTABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT 'pg_repack 1.4.2'::text
$$;

ALTER FUNCTION version_sql() OWNER TO postgres;

