CREATE FUNCTION cpa_subs_stat_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    IF (NEW.serviceid = 1) THEN
        INSERT INTO public.cpa_subs_stat_1 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 2) THEN
        INSERT INTO public.cpa_subs_stat_2 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 3) THEN
        INSERT INTO public.cpa_subs_stat_3 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 4) THEN
        INSERT INTO public.cpa_subs_stat_4 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 5) THEN
        INSERT INTO public.cpa_subs_stat_5 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 6) THEN
        INSERT INTO public.cpa_subs_stat_6 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 7) THEN
        INSERT INTO public.cpa_subs_stat_7 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 8) THEN
        INSERT INTO public.cpa_subs_stat_8 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 9) THEN
        INSERT INTO public.cpa_subs_stat_9 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 10) THEN
        INSERT INTO public.cpa_subs_stat_10 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 11) THEN
        INSERT INTO public.cpa_subs_stat_11 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 12) THEN
        INSERT INTO public.cpa_subs_stat_12 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 13) THEN
        INSERT INTO public.cpa_subs_stat_13 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 14) THEN
        INSERT INTO public.cpa_subs_stat_14 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 15) THEN
        INSERT INTO public.cpa_subs_stat_15 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 16) THEN
        INSERT INTO public.cpa_subs_stat_16 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 17) THEN 
        INSERT INTO public.cpa_subs_stat_17 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 18) THEN 
        INSERT INTO public.cpa_subs_stat_18 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 19) THEN 
        INSERT INTO public.cpa_subs_stat_19 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 20) THEN 
        INSERT INTO public.cpa_subs_stat_20 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 21) THEN 
        INSERT INTO public.cpa_subs_stat_21 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 22) THEN 
        INSERT INTO public.cpa_subs_stat_22 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 23) THEN 
        INSERT INTO public.cpa_subs_stat_23 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 24) THEN 
        INSERT INTO public.cpa_subs_stat_24 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 25) THEN 
        INSERT INTO public.cpa_subs_stat_25 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 26) THEN 
        INSERT INTO public.cpa_subs_stat_26 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 27) THEN 
        INSERT INTO public.cpa_subs_stat_27 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 28) THEN 
        INSERT INTO public.cpa_subs_stat_28 VALUES (NEW.*);
    ELSIF (NEW.serviceid = 29) THEN 
        INSERT INTO public.cpa_subs_stat_29 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 30) THEN 
        INSERT INTO public.cpa_subs_stat_30 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 31) THEN 
        INSERT INTO public.cpa_subs_stat_31 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 32) THEN 
        INSERT INTO public.cpa_subs_stat_32 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 33) THEN 
        INSERT INTO public.cpa_subs_stat_33 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 34) THEN 
        INSERT INTO public.cpa_subs_stat_34 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 35) THEN 
        INSERT INTO public.cpa_subs_stat_35 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 36) THEN 
        INSERT INTO public.cpa_subs_stat_36 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 37) THEN 
        INSERT INTO public.cpa_subs_stat_37 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 38) THEN 
        INSERT INTO public.cpa_subs_stat_38 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 39) THEN 
        INSERT INTO public.cpa_subs_stat_39 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 40) THEN 
        INSERT INTO public.cpa_subs_stat_40 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 41) THEN 
        INSERT INTO public.cpa_subs_stat_41 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 42) THEN 
        INSERT INTO public.cpa_subs_stat_42 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 43) THEN 
        INSERT INTO public.cpa_subs_stat_43 VALUES (NEW.*);   
    ELSIF (NEW.serviceid = 44) THEN 
        INSERT INTO public.cpa_subs_stat_44 VALUES (NEW.*); 
    ELSIF (NEW.serviceid = 45) THEN 
        INSERT INTO public.cpa_subs_stat_45 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 46) THEN 
        INSERT INTO public.cpa_subs_stat_46 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 47) THEN 
        INSERT INTO public.cpa_subs_stat_47 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 48) THEN 
        INSERT INTO public.cpa_subs_stat_48 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 49) THEN 
        INSERT INTO public.cpa_subs_stat_49 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 50) THEN 
        INSERT INTO public.cpa_subs_stat_50 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 51) THEN 
        INSERT INTO public.cpa_subs_stat_51 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 52) THEN 
        INSERT INTO public.cpa_subs_stat_52 VALUES (NEW.*);        
    ELSIF (NEW.serviceid = 53) THEN 
        INSERT INTO public.cpa_subs_stat_53 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 54) THEN 
        INSERT INTO public.cpa_subs_stat_54 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 55) THEN 
        INSERT INTO public.cpa_subs_stat_55 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 56) THEN 
        INSERT INTO public.cpa_subs_stat_56 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 57) THEN 
        INSERT INTO public.cpa_subs_stat_57 VALUES (NEW.*);    
    ELSIF (NEW.serviceid = 58) THEN 
        INSERT INTO public.cpa_subs_stat_58 VALUES (NEW.*);         
    ELSIF (NEW.serviceid = 59) THEN 
        INSERT INTO public.cpa_subs_stat_59 VALUES (NEW.*);         
    ELSIF (NEW.serviceid = 60) THEN 
        INSERT INTO public.cpa_subs_stat_60 VALUES (NEW.*);         
    ELSE
        EXECUTE 'insert into cpa_subs_stat_'|| NEW.serviceid || ' select $1.*' using NEW;
    END IF;
    RETURN NULL;
END;
$$;

ALTER FUNCTION cpa_subs_stat_insert_trigger() OWNER TO inform;

