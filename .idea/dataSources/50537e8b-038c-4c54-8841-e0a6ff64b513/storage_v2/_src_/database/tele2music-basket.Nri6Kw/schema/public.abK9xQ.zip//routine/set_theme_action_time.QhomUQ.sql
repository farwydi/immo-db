CREATE FUNCTION set_theme_action_time() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

IF NEW.root_message_id IS NOT NULL THEN
update
forum_messages set
action_time = CURRENT_TIMESTAMP,
"count" = (select count(message_id)+1 from forum_messages where root_message_id = NEW.root_message_id)
where message_id = NEW.root_message_id;
END IF;

IF
NEW.root_message_id IS NULL
and
NEW.parent_message_id IS NULL
and
NEW.forum_id IS NOT NULL
and
NEW.action_time IS NULL
THEN
NEW.action_time = CURRENT_TIMESTAMP;
END IF;


RETURN NEW;

END;
$$;

ALTER FUNCTION set_theme_action_time() OWNER TO postgres;

