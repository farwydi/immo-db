CREATE VIEW pg_seclabels (objoid, classoid, objsubid, objtype, objnamespace, objname, provider, label) AS
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   CASE
		   WHEN rel.relkind = 'r'::"char" THEN 'table'::TEXT
		   WHEN rel.relkind = 'v'::"char" THEN 'view'::TEXT
		   WHEN rel.relkind = 'm'::"char" THEN 'materialized view'::TEXT
		   WHEN rel.relkind = 'S'::"char" THEN 'sequence'::TEXT
		   WHEN rel.relkind = 'f'::"char" THEN 'foreign table'::TEXT
		   ELSE NULL::TEXT
		   END          AS objtype,
	   rel.relnamespace AS objnamespace,
	   CASE
		   WHEN PG_TABLE_IS_VISIBLE(rel.oid) THEN QUOTE_IDENT(rel.relname::TEXT)
		   ELSE (QUOTE_IDENT(nsp.nspname::TEXT) || '.'::TEXT) || QUOTE_IDENT(rel.relname::TEXT)
		   END          AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_class rel ON l.classoid = rel.tableoid AND l.objoid = rel.oid
		 JOIN pg_namespace nsp ON rel.relnamespace = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   'column'::TEXT                                     AS objtype,
	   rel.relnamespace                                   AS objnamespace,
	   (
			   CASE
				   WHEN PG_TABLE_IS_VISIBLE(rel.oid) THEN QUOTE_IDENT(rel.relname::TEXT)
				   ELSE (QUOTE_IDENT(nsp.nspname::TEXT) || '.'::TEXT) || QUOTE_IDENT(rel.relname::TEXT)
				   END || '.'::TEXT) || att.attname::TEXT AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_class rel ON l.classoid = rel.tableoid AND l.objoid = rel.oid
		 JOIN pg_attribute att ON rel.oid = att.attrelid AND l.objsubid = att.attnum
		 JOIN pg_namespace nsp ON rel.relnamespace = nsp.oid
WHERE l.objsubid <> 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   CASE
		   WHEN pro.proisagg = TRUE THEN 'aggregate'::TEXT
		   WHEN pro.proisagg = FALSE THEN 'function'::TEXT
		   ELSE NULL::TEXT
		   END                                                                            AS objtype,
	   pro.pronamespace                                                                   AS objnamespace,
	   ((
				CASE
					WHEN PG_FUNCTION_IS_VISIBLE(pro.oid) THEN QUOTE_IDENT(pro.proname::TEXT)
					ELSE (QUOTE_IDENT(nsp.nspname::TEXT) || '.'::TEXT) || QUOTE_IDENT(pro.proname::TEXT)
					END || '('::TEXT) || PG_GET_FUNCTION_ARGUMENTS(pro.oid)) || ')'::TEXT AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_proc pro ON l.classoid = pro.tableoid AND l.objoid = pro.oid
		 JOIN pg_namespace nsp ON pro.pronamespace = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   CASE
		   WHEN typ.typtype = 'd'::"char" THEN 'domain'::TEXT
		   ELSE 'type'::TEXT
		   END          AS objtype,
	   typ.typnamespace AS objnamespace,
	   CASE
		   WHEN PG_TYPE_IS_VISIBLE(typ.oid) THEN QUOTE_IDENT(typ.typname::TEXT)
		   ELSE (QUOTE_IDENT(nsp.nspname::TEXT) || '.'::TEXT) || QUOTE_IDENT(typ.typname::TEXT)
		   END          AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_type typ ON l.classoid = typ.tableoid AND l.objoid = typ.oid
		 JOIN pg_namespace nsp ON typ.typnamespace = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   'large object'::TEXT AS objtype,
	   NULL::OID            AS objnamespace,
	   l.objoid::TEXT       AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_largeobject_metadata lom ON l.objoid = lom.oid
WHERE l.classoid = 'pg_largeobject'::REGCLASS::OID
  AND l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   'language'::TEXT               AS objtype,
	   NULL::OID                      AS objnamespace,
	   QUOTE_IDENT(lan.lanname::TEXT) AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_language lan ON l.classoid = lan.tableoid AND l.objoid = lan.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   'schema'::TEXT                 AS objtype,
	   nsp.oid                        AS objnamespace,
	   QUOTE_IDENT(nsp.nspname::TEXT) AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_namespace nsp ON l.classoid = nsp.tableoid AND l.objoid = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   l.objsubid,
	   'event trigger'::TEXT          AS objtype,
	   NULL::OID                      AS objnamespace,
	   QUOTE_IDENT(evt.evtname::TEXT) AS objname,
	   l.provider,
	   l.label
FROM pg_seclabel l
		 JOIN pg_event_trigger evt ON l.classoid = evt.tableoid AND l.objoid = evt.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   0                              AS objsubid,
	   'database'::TEXT               AS objtype,
	   NULL::OID                      AS objnamespace,
	   QUOTE_IDENT(dat.datname::TEXT) AS objname,
	   l.provider,
	   l.label
FROM pg_shseclabel l
		 JOIN pg_database dat ON l.classoid = dat.tableoid AND l.objoid = dat.oid
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   0                              AS objsubid,
	   'tablespace'::TEXT             AS objtype,
	   NULL::OID                      AS objnamespace,
	   QUOTE_IDENT(spc.spcname::TEXT) AS objname,
	   l.provider,
	   l.label
FROM pg_shseclabel l
		 JOIN pg_tablespace spc ON l.classoid = spc.tableoid AND l.objoid = spc.oid
UNION ALL
SELECT l.objoid,
	   l.classoid,
	   0                              AS objsubid,
	   'role'::TEXT                   AS objtype,
	   NULL::OID                      AS objnamespace,
	   QUOTE_IDENT(rol.rolname::TEXT) AS objname,
	   l.provider,
	   l.label
FROM pg_shseclabel l
		 JOIN pg_authid rol ON l.classoid = rol.tableoid AND l.objoid = rol.oid;

ALTER TABLE pg_seclabels
	OWNER TO postgres;

