CREATE MATERIALIZED VIEW compact_contents AS
SELECT cc.id,
	   cc.category_id,
	   s.id                                                                    AS service_id,
	   cc.type,
	   cc.name,
	   cc.file,
	   cc.description,
	   COALESCE(ocp.enable, cc.enable)                                         AS enable,
	   COALESCE(ocp.priority, cc.priority::INTEGER)                            AS priority,
	   COALESCE(ocp.protected, cc.protected)                                   AS protected,
	   TO_HEX(hash_array(ARRAY [cc.id, cc.category_id]))::CHARACTER VARYING(8) AS uidx,
	   cc.sys_1,
	   cc.sys_2
FROM ((
		  SELECT c.id,
				 c.type,
				 c.name,
				 c.file,
				 c.description,
				 c.enable,
				 ct_1.id AS category_id,
				 c.priority,
				 c.protected,
				 c.uidx,
				 c.sys_1,
				 c.sys_2
		  FROM contents c
				   JOIN content_group_links cgl ON c.id = cgl.content_id
				   JOIN group_category_links gcl ON cgl.group_id = gcl.group_id
				   JOIN categories ct_1 ON gcl.category_id = ct_1.id
		  UNION
		  SELECT c.id,
				 c.type,
				 c.name,
				 c.file,
				 c.description,
				 c.enable,
				 ct_1.id AS category_id,
				 c.priority,
				 c.protected,
				 c.uidx,
				 c.sys_1,
				 c.sys_2
		  FROM contents c
				   JOIN content_includes ci ON c.id = ci.content_id
				   JOIN content_group_links cgl ON c.id = cgl.content_id
				   JOIN group_category_links gcl ON cgl.group_id = gcl.group_id
				   JOIN categories ct_1 ON gcl.category_id = ct_1.id
	  )
	  EXCEPT
	  SELECT c.id,
			 c.type,
			 c.name,
			 c.file,
			 c.description,
			 c.enable,
			 ct_1.id AS category_id,
			 c.priority,
			 c.protected,
			 c.uidx,
			 c.sys_1,
			 c.sys_2
	  FROM content_excludes cx
			   JOIN contents c ON cx.content_id = c.id
			   JOIN content_group_links cgl ON c.id = cgl.content_id
			   JOIN group_category_links gcl ON cgl.group_id = gcl.group_id
			   JOIN categories ct_1 ON gcl.category_id = ct_1.id) cc
		 LEFT JOIN override_content_params ocp ON ocp.content_id = cc.id
		 JOIN categories ct ON ct.id = cc.category_id
		 JOIN services s ON s.id = ct.service;

ALTER MATERIALIZED VIEW compact_contents OWNER TO postgres;

CREATE INDEX compact_contents_category_id_index
	ON compact_contents (category_id);

CREATE INDEX compact_contents_service_id_index
	ON compact_contents (service_id);

CREATE UNIQUE INDEX compact_contents_uidx_uindex
	ON compact_contents (uidx);

