CREATE FUNCTION date_part(text, date) RETURNS double precision
	IMMUTABLE
	STRICT
	COST 1
	LANGUAGE sql
AS
$$
select pg_catalog.date_part($1, cast($2 as timestamp without time zone))
$$;

COMMENT ON FUNCTION date_part(TEXT, DATE) IS 'extract field from date';

ALTER FUNCTION date_part(TEXT, DATE) OWNER TO postgres;

