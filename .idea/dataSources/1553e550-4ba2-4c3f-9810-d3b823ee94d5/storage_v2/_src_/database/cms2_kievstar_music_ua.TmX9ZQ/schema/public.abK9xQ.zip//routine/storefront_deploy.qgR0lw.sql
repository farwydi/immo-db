CREATE FUNCTION storefront_deploy(mode character varying) RETURNS boolean
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
DECLARE

_c int;
BEGIN

IF (mode = 'release')
THEN
SELECT INTO _c count(*) FROM pg_namespace where nspname in ('storefront_new', 'storefront');
IF (_c = 2)
THEN
SELECT INTO _c count(*) FROM pg_namespace where nspname = 'storefront_old';
IF (_c = 1)
THEN
DROP SCHEMA storefront_old CASCADE;

END IF;
ALTER SCHEMA storefront RENAME TO storefront_old;
ALTER SCHEMA storefront_new RENAME TO storefront;

RETURN true;

END IF;

ELSE

IF (mode = 'revert') THEN
SELECT INTO _c count(*) FROM pg_namespace where nspname in ('storefront_old', 'storefront');
IF (_c = 2)
THEN
SELECT INTO _c count(*) FROM pg_namespace where nspname = 'storefront_new';
IF (_c = 1)
THEN
DROP SCHEMA storefront_new CASCADE;

END IF;
ALTER SCHEMA storefront RENAME TO storefront_new;
ALTER SCHEMA storefront_old RENAME TO storefront;

RETURN true;

END IF;

END IF;

END IF;

RETURN false;
END;
$$;

ALTER FUNCTION storefront_deploy(VARCHAR) OWNER TO postgres;

