CREATE MATERIALIZED VIEW msisdn_profile_relations AS
SELECT t1.msisdn,
	   t1.profile_id
FROM DBLINK('host=vps6201.mtu.immo dbname=runiverse_rambler user=inform password=l!j@cneg'::TEXT,
			'SELECT "user".msisdn,subscription.profile_id FROM subscription inner join "user" on subscription.user_id = "user".user_id WHERE subscription.profile_id IN (558,754,851)'::TEXT) t1(msisdn BIGINT, profile_id INTEGER);

ALTER MATERIALIZED VIEW msisdn_profile_relations OWNER TO inform;

CREATE INDEX msisdn_profile_relations_msisdn_idx
	ON msisdn_profile_relations (msisdn);

