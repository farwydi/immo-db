CREATE FUNCTION heaver_sine(double precision) RETURNS double precision
	LANGUAGE sql
AS
$$
SELECT power(sin($1/2.0), 2);
$$;

ALTER FUNCTION heaver_sine(DOUBLE PRECISION) OWNER TO postgres;

