CREATE FUNCTION insert_hash_dialog() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	IF NEW.dialogue_hash IS NULL THEN
		NEW.dialogue_hash := hash_array(sort(ARRAY [NEW.user_from, NEW.user_to]));
	END IF;
	RETURN new;
END;
$$;

ALTER FUNCTION insert_hash_dialog() OWNER TO inform;

