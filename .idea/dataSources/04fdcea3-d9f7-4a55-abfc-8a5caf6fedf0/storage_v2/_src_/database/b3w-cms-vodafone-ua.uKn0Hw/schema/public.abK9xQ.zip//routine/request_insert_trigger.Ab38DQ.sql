CREATE FUNCTION request_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    if NEW.create_date is null then    INSERT INTO public.request_other VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 1) THEN INSERT INTO public.request_1 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 2) THEN INSERT INTO public.request_2 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 3) THEN INSERT INTO public.request_3 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 4) THEN INSERT INTO public.request_4 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 5) THEN INSERT INTO public.request_5 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 6) THEN INSERT INTO public.request_6 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 7) THEN INSERT INTO public.request_7 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 8) THEN INSERT INTO public.request_8 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 9) THEN INSERT INTO public.request_9 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 10) THEN INSERT INTO public.request_10 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 11) THEN INSERT INTO public.request_11 VALUES (NEW.*);
    elseif (extract(month from NEW.create_date) = 12) THEN INSERT INTO public.request_12 VALUES (NEW.*);
    end if;
    RETURN null;
END;
$$;

ALTER FUNCTION request_insert_trigger() OWNER TO inform;

