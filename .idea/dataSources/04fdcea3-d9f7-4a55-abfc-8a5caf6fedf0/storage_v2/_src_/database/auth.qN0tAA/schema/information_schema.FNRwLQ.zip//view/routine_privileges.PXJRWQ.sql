CREATE VIEW routine_privileges
			(grantor, grantee, specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema,
			 routine_name, privilege_type, is_grantable)
AS
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER                               AS grantor,
	   grantee.rolname::information_schema.SQL_IDENTIFIER                                 AS grantee,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                              AS specific_catalog,
	   n.nspname::information_schema.SQL_IDENTIFIER                                       AS specific_schema,
	   ((p.proname::TEXT || '_'::TEXT) || p.oid::TEXT)::information_schema.SQL_IDENTIFIER AS specific_name,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                              AS routine_catalog,
	   n.nspname::information_schema.SQL_IDENTIFIER                                       AS routine_schema,
	   p.proname::information_schema.SQL_IDENTIFIER                                       AS routine_name,
	   'EXECUTE'::CHARACTER VARYING::information_schema.CHARACTER_DATA                    AS privilege_type,
	   CASE
		   WHEN PG_HAS_ROLE(grantee.oid, p.proowner, 'USAGE'::TEXT) OR p.grantable THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                                              AS is_grantable
FROM (SELECT pg_proc.oid,
			 pg_proc.proname,
			 pg_proc.proowner,
			 pg_proc.pronamespace,
			 (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).grantor        AS grantor,
			 (aclexplode(COALESCE(pg_proc.proacl,
								  acldefault('f'::"char", pg_proc.proowner)))).grantee                        AS grantee,
			 (aclexplode(COALESCE(pg_proc.proacl,
								  acldefault('f'::"char", pg_proc.proowner)))).privilege_type                 AS privilege_type,
			 (aclexplode(COALESCE(pg_proc.proacl,
								  acldefault('f'::"char", pg_proc.proowner)))).is_grantable                   AS is_grantable
	  FROM pg_proc) p(oid, proname, proowner, pronamespace, grantor, grantee, prtype, grantable),
	 pg_namespace n,
	 pg_authid u_grantor,
	 (SELECT pg_authid.oid, pg_authid.rolname
	  FROM pg_authid
	  UNION ALL
	  SELECT 0::OID AS oid, 'PUBLIC'::NAME) grantee(oid, rolname)
WHERE p.pronamespace = n.oid
  AND grantee.oid = p.grantee
  AND u_grantor.oid = p.grantor
  AND p.prtype = 'EXECUTE'::TEXT
  AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
	   grantee.rolname = 'PUBLIC'::NAME);

ALTER TABLE routine_privileges
	OWNER TO postgres;

