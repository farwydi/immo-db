CREATE FUNCTION geodistance(alat double precision, alng double precision, blat double precision, blng double precision) RETURNS double precision
	IMMUTABLE
	LANGUAGE sql
AS
$$
SELECT asin(
  sqrt(
    sin(radians($3-$1)/2)^2 +
    sin(radians($4-$2)/2)^2 *
    cos(radians($1)) *
    cos(radians($3))
  )
) * 12755.660544 AS distance;
$$;

ALTER FUNCTION geodistance(DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

