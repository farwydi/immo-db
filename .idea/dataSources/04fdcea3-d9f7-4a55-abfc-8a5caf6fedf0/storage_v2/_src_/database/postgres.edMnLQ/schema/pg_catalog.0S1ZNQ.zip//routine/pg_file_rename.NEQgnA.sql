CREATE FUNCTION pg_file_rename(text, text) RETURNS boolean
	STRICT
	LANGUAGE sql
AS
$$
SELECT pg_catalog.pg_file_rename($1, $2, NULL::pg_catalog.text);
$$;

ALTER FUNCTION pg_file_rename(TEXT, TEXT) OWNER TO postgres;

