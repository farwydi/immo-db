CREATE FUNCTION pg_file_length(text) RETURNS bigint
	STRICT
	LANGUAGE sql
AS
$$
SELECT size FROM pg_catalog.pg_stat_file($1)
$$;

ALTER FUNCTION pg_file_length(TEXT) OWNER TO postgres;

