CREATE FUNCTION update_code_singers_name_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
      --если новый исполнитель
IF (TG_OP = 'INSERT') THEN
        update content_code cc
        set singer = left(name,500), billing_modification_date = null
        from
        (select content_code_id, array_to_string(array_agg(distinct name),'; ') as name
        from
        (select fcc.content_code_id, eas.name
        from file_content_code fcc 
        join card_file cf on fcc.file_id = cf.file_id and cf.card_id = new.card_id
        join melody_card_artist mca on mca.card_id = cf.card_id 
        JOIN extra.artist_search eas on mca.artist_id = eas.melody_artist_id) ss 
        group by content_code_id) ss 
        where ss.content_code_id = cc.content_code_id;

elsIF (TG_OP = 'DELETE') THEN
        update content_code cc
        set singer = left(name,500), billing_modification_date = null
        from
        (select content_code_id, array_to_string(array_agg(distinct name),'; ') as name
        from
        (
        select fcc.content_code_id, eas.name
        from card_file cf
        join file_content_code fcc on fcc.file_id = cf.file_id and cf.card_id = old.card_id
        left join melody_card_artist mca on mca.card_id = cf.card_id 
        left JOIN extra.artist_search eas on mca.artist_id = eas.melody_artist_id
        ) ss 
        group by content_code_id) ss 
        where ss.content_code_id = cc.content_code_id;
    END IF;
        RETURN NEW;
END;
$$;

ALTER FUNCTION update_code_singers_name_trigger() OWNER TO postgres;

