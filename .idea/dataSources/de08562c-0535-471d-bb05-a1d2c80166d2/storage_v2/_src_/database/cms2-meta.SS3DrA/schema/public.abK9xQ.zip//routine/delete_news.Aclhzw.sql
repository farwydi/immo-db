CREATE FUNCTION delete_news(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM news WHERE news_id = id;
	DELETE FROM news_album WHERE news_id = id;
	DELETE FROM news_artist WHERE news_id = id;
END;
$$;

ALTER FUNCTION delete_news(UUID) OWNER TO postgres;

