CREATE FUNCTION prepare_name(arg character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
    RETURN upper(translate (arg,$H$ !@#$%^&*()_+=\"№?{}:;|/.,''`~<>«»]+-[$H$||chr(10)||chr(13),'')); 
END
$$;

ALTER FUNCTION prepare_name(VARCHAR) OWNER TO postgres;

