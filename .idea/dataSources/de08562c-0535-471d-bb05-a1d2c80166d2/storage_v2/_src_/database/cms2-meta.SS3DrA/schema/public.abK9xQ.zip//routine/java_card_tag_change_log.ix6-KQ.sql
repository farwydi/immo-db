CREATE FUNCTION java_card_tag_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('java_card_tag', OLD.java_card_id, 'D', 'java_card_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.java_card_id =  OLD.java_card_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('java_card_tag', NEW.java_card_id, 'U', 'java_card_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('java_card_tag', NEW.java_card_id, 'I', 'java_card_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('java_card_tag', OLD.java_card_id, 'D', 'java_card_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('java_card_tag', NEW.java_card_id, 'I', 'java_card_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION java_card_tag_change_log() OWNER TO postgres;

