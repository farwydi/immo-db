CREATE FUNCTION swap_all(mode character varying) RETURNS boolean
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
DECLARE
   _c int;
   _result boolean;
   _old_postfix character varying;
   _current_old_postfix character varying;
BEGIN

_old_postfix := 'none';


select into _old_postfix replace(tablename,'agreement2content_','') from pg_tables where schemaname = 'billing_archive' and tablename like 'agreement2content%' order by replace(tablename,'agreement2content_','') desc limit 1;
if(mode = 'revert' and _old_postfix='none')
THEN
return false;
END IF;


	IF (mode = 'release')
	THEN								
		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'agreement2content_new';
		if (_c = 0) THEN return false; END IF;
		SELECT INTO _c count(*) from agreement2content_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'agreement_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from agreement_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'region_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from region_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'contragent_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from contragent_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'agreement2region_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from agreement2region_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'tariff2agreement_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from tariff2agreement_new;		
		if (_c = 0) THEN return false; END IF;
	ELSE
		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'billing_archive' and tablename = 'agreement2content'||_old_postfix;
		if (_c = 0) THEN return false; END IF;
		execute 'SELECT  count(*) from billing_archive.agreement2content'||_old_postfix INTO _c;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'billing_archive' and tablename = 'agreement'||_old_postfix;
		if (_c = 0) THEN return false; END IF;		
		execute 'SELECT  count(*) from billing_archive.agreement'||_old_postfix INTO _c;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'billing_archive' and tablename = 'region'||_old_postfix;
		if (_c = 0) THEN return false; END IF;		
		execute 'SELECT  count(*) from billing_archive.region'||_old_postfix INTO _c;
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'billing_archive' and tablename = 'contragent'||_old_postfix;
		if (_c = 0) THEN return false; END IF;		
		execute 'SELECT  count(*) from billing_archive.contragent'||_old_postfix INTO _c;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'billing_archive' and tablename = 'agreement2region'||_old_postfix;
		if (_c = 0) THEN return false; END IF;		
		execute 'SELECT  count(*) from billing_archive.agreement2region'||_old_postfix INTO _c;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'billing_archive' and tablename = 'tariff2agreement'||_old_postfix;
		if (_c = 0) THEN return false; END IF;		
		execute 'SELECT  count(*) from billing_archive.tariff2agreement'||_old_postfix INTO _c;		
		if (_c = 0) THEN return false; END IF;
	END IF;
select into _current_old_postfix '_'||nextval('billing_archive.table_seq');

	if (swap_sync_by_table('agreement2content'::text,'agreement2content'||_current_old_postfix, mode) = false) then return false; end if;
	if (swap_sync_by_table('agreement'::text,'agreement'||_current_old_postfix, mode) = false) then return false; end if;
	if (swap_sync_by_table('region'::text,'region'||_current_old_postfix, mode) = false) then return false; end if;
	if (swap_sync_by_table('contragent'::text,'contragent'||_current_old_postfix, mode) = false) then return false; end if;
	if (swap_sync_by_table('agreement2region'::text,'agreement2region'||_current_old_postfix, mode) = false) then return false; end if;
	if (swap_sync_by_table('tariff2agreement'::text,'tariff2agreement'||_current_old_postfix, mode) = false) then return false; end if;
	
	ALTER TABLE agreement
		ADD CONSTRAINT pk_agreement PRIMARY KEY(agreement);
	CREATE INDEX ix_agreement_contragent
	  ON agreement
	  USING btree
	  (contragent);
	  
	ALTER TABLE agreement2content
	  ADD CONSTRAINT pk_agreement2content PRIMARY KEY(agreement2content);

	CREATE INDEX ix_agreement2content_agreement
	  ON agreement2content
	  USING btree
	  (agreement);

	CREATE INDEX ix_agreement2content_content
	  ON agreement2content
	  USING btree
	  (content);

	ALTER TABLE agreement2region
	  ADD CONSTRAINT pk_agreement2region PRIMARY KEY(agreement2region);

	CREATE INDEX ix_agreement2region_agreement
	  ON agreement2region
	  USING btree
	  (agreement);

	CREATE INDEX ix_agreement2region_region
	  ON agreement2region
	  USING btree
	  (region);
	  
	ALTER TABLE contragent
	  ADD CONSTRAINT pk_contragent PRIMARY KEY(contragent);		
	  
	ALTER TABLE tariff2agreement
	  ADD CONSTRAINT pk_tariff2agreement PRIMARY KEY(content_sale2point);		  
		
	return true;
END;
$$;

ALTER FUNCTION swap_all(VARCHAR) OWNER TO postgres;

