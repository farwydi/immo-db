CREATE FUNCTION _temp_join_artists(main_artist uuid, artist uuid) RETURNS SETOF boolean
	LANGUAGE plpgsql
AS
$$
declare
	_res record;
	_count integer;
BEGIN
/*artists*/	
  SELECT
		melody_artist.melody_artist_id,
		COALESCE(melody_artist.last_name,melody_artist1.last_name) as last_name,
		COALESCE(melody_artist.first_name,melody_artist1.first_name) as first_name,
		COALESCE(melody_artist.middle_name,melody_artist1.middle_name) as middle_name,
		COALESCE(melody_artist.group,melody_artist1.group) as group,
		COALESCE(melody_artist.description_short,melody_artist1.description_short) as description_short,
		COALESCE(melody_artist.description_detailed,melody_artist1.description_detailed) as description_detailed,
		COALESCE(melody_artist.birthday,melody_artist1.birthday) as birthday,
		COALESCE(melody_artist.tag,melody_artist1.tag) as tag,
		COALESCE(melody_artist.is_checked,melody_artist1.is_checked) as is_checked into _res
	from 
		melody_artist ,
		melody_artist melody_artist1 
	where 
		melody_artist.melody_artist_id=main_artist
	and 
		melody_artist1.melody_artist_id=artist;
    
   
	UPDATE  melody_artist SET
		last_name = _res.last_name,
		first_name = _res.first_name,
		middle_name = _res.middle_name,
		"group" = _res.group,
		description_short = _res.description_short,
		description_detailed = _res.description_detailed,
		birthday = _res.birthday,
		tag = _res.tag,
		is_checked = _res.is_checked
	WHERE
		melody_artist_id = main_artist;


	/*equivalent*/
	for _res in select * from melody_artist_equivalent where melody_artist_id=artist loop
		select count(*) into _count from melody_artist_equivalent where melody_artist_id=main_artist and "name"=_res.name;

		if _count>0 then
			delete from melody_artist_equivalent where melody_artist_id=artist and "name"=_res.name;
		else
			update melody_artist_equivalent SET melody_artist_id = main_artist
				where melody_artist_id=artist and "name"=_res.name;
		end if; 
		
	end loop;
	
	
	/*genre*/
	for _res in select * from melody_artist_genre where artist_id=artist loop
		select count(*) into _count from melody_artist_genre where artist_id=main_artist and genre_id=_res.genre_id;

		if _count>0 then
			delete from melody_artist_genre where artist_id=artist and genre_id=_res.genre_id;
		else
			update melody_artist_genre SET artist_id = main_artist
				where artist_id=artist and genre_id=_res.genre_id; 
		end if;
	end loop;
	

	/*relation artist*/ 
	for _res in select * from melody_artist_relation where artist_id=artist loop
		select count(*) into _count from melody_artist_relation where artist_id=main_artist and parent_artist_id=_res.parent_artist_id;

		if _count>0 then
			delete from melody_artist_relation where artist_id=artist and parent_artist_id=_res.parent_artist_id;
		else
			update melody_artist_relation SET artist_id = main_artist
				where artist_id=artist and parent_artist_id=_res.parent_artist_id;
		end if;
	end loop;


	/*relation parent_artist*/
	for _res in select * from melody_artist_relation where parent_artist_id=artist loop
		select count(*) into _count from melody_artist_relation where parent_artist_id=main_artist and is_current=_res.is_current and artist_id=_res.artist_id;

		if _count>0 then
			delete from melody_artist_relation where parent_artist_id=artist and artist_id=_res.artist_id;
		else
			update melody_artist_relation SET parent_artist_id = main_artist
				where parent_artist_id=artist and artist_id=_res.artist_id;
		end if;
	end loop;


	/*card*/
	for _res in select * from melody_card_artist where artist_id=artist loop
		select count(*) into _count from melody_card_artist where artist_id=main_artist and card_id=_res.card_id;

		if _count>0 then
			delete from melody_card_artist where artist_id=artist and card_id=_res.card_id;
		else
			update melody_card_artist SET artist_id = main_artist
				where artist_id=artist and card_id=_res.card_id; 
		end if;
	end loop;


	/*album*/
	for _res in select * from melody_album where primary_artist_id=artist loop
		select count(*) into _count from melody_album where primary_artist_id=main_artist and melody_album_id=_res.melody_album_id;

		if _count>0 then
			delete from melody_album where primary_artist_id=artist and melody_album_id=_res.melody_album_id;
		else
			update melody_album SET primary_artist_id = main_artist
				where primary_artist_id=artist and melody_album_id=_res.melody_album_id; 
		end if;
	end loop;


	/*news*/
	for _res in select * from news_artist where artist_id=artist loop
		select count(*) into _count from news_artist where artist_id=main_artist and news_id=_res.news_id;

		if _count>0 then
			delete from news_artist where artist_id=artist and news_id=_res.news_id;
		else
			update news_artist SET artist_id = main_artist
				where artist_id=artist and news_id=_res.news_id; 
		end if;
	end loop;


	/*preview*/
	for _res in select * from preview_relation where source_id=artist loop
		select count(*) into _count from preview_relation where source_id=main_artist and preview_id=_res.preview_id;

		if _count>0 then
			delete from preview_relation where source_id=artist and preview_id=_res.preview_id;
		else
			update preview_relation SET source_id = main_artist
				where source_id=artist and preview_id=_res.preview_id; 
		end if;
	end loop;

	delete from melody_artist where melody_artist_id = artist;
END;
$$;

ALTER FUNCTION _temp_join_artists(UUID, UUID) OWNER TO postgres;

