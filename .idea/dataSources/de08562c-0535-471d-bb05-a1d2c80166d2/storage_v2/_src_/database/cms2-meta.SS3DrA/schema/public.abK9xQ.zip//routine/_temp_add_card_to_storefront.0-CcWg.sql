CREATE FUNCTION _temp_add_card_to_storefront(_card_id uuid, _section_id integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_count integer;

	_have_goodok boolean;
begin

select count(*) into _count from storefront.content where card_id=_card_id;

if (_count>0) then
	return 0;
end if;


select have_goodok(melody_card_id,1) into _have_goodok 
	from melody_card
	where melody_card_id=_card_id;

/*вставляем максимальные коды для каждого формата */
 
insert into storefront.content
select  content_code,melody_card_id,name,_section_id,user_format_id,'melody_card' as tablename,name as search_text,lyrics,minimal_cost,is_free,is_hit, null as drm_type,_have_goodok
from (
	select distinct melody_card_id as card_id, max(content_code) as content_code,user_format.user_format_id from 
	melody_card
	inner join  card_file
	 on melody_card.melody_card_id=card_file.card_id
	inner join file_content_code on card_file.file_id=file_content_code.file_id
	inner join content_type on content_type.content_type_id=file_content_code.content_type_id
	inner join content_code on content_code.content_code_id=file_content_code.content_code_id
	inner join user_format on user_format.user_format_id=content_type.user_format_id 
	where melody_card_id=_card_id
	group by melody_card_id,user_format.user_format_id
	) t
	inner join melody_card on melody_card.melody_card_id=t.card_id;


/*артисты, если их не хватает*/

insert into storefront.melody_artist (melody_artist_id, last_name, first_name, middle_name, "group", 
       search_text, first_letter_first_name, first_letter_last_name, 
       have_goodok, description_short, birthday )
select ma.melody_artist_id,  ma.last_name, ma.first_name, ma.middle_name, ma.group,
	COALESCE(ma.group,'') || ' ' || COALESCE(ma.last_name,'') || ' ' || COALESCE(ma.first_name,'') || ' '||  COALESCE(ma.tag,''),  
	CASE WHEN ma.group is null THEN upper(substring(ma.first_name,1,1)) ELSE upper(substring(ma.group,1,1)) END, 
	CASE WHEN ma.group is null THEN upper(substring(ma.last_name,1,1)) ELSE upper(substring(ma.group,1,1)) END, 
	_have_goodok, ma.description_short, ma.birthday
from melody_card_artist
inner join melody_artist ma on melody_card_artist.artist_id=ma.melody_artist_id
left join storefront.melody_artist on melody_card_artist.artist_id=melody_artist.melody_artist_id
where card_id=_card_id and melody_artist.melody_artist_id is null;

insert into storefront.melody_card_artist
select mca.* from melody_card_artist mca
left join storefront.melody_card_artist on melody_card_artist.artist_id=mca.artist_id and melody_card_artist.card_id=mca.card_id
where mca.card_id=_card_id and melody_card_artist.artist_id is null;

/*альбомы, если их не хватает*/

insert into storefront.melody_album (melody_album_id, primary_artist_id, search_text, "name", released, 
       have_goodok, count_track, is_collection)
select  ma.melody_album_id, ma.primary_artist_id, ma.name, ma.name, ma.released,  _have_goodok, 0, ma.is_collection 
from melody_card_album
inner join melody_album ma on melody_card_album.album_id=ma.melody_album_id
left join storefront.melody_album on melody_card_album.album_id=melody_album.melody_album_id
where card_id=_card_id and melody_album.melody_album_id is null;

insert into storefront.melody_card_album
select mca.* from melody_card_album mca
left join storefront.melody_card_album on melody_card_album.album_id=mca.album_id and melody_card_album.card_id=mca.card_id
where mca.card_id=_card_id and melody_card_album.album_id is null; 


/* превью */
insert into storefront.preview_picture
select p.* from 
preview_picture p left join storefront.preview_picture on p.preview_picture_id=preview_picture.preview_picture_id
where preview_picture.preview_picture_id is null;

insert into storefront.preview_relation
select p.* from 
preview_relation p left join storefront.preview_relation on p.preview_id=preview_relation.preview_id
where preview_relation.preview_id is null;


return 1;

end;
$$;

ALTER FUNCTION _temp_add_card_to_storefront(UUID, INTEGER) OWNER TO postgres;

