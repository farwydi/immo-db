CREATE FUNCTION _temp_news_nashe_to_storefront() RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
	_row record;

	_row_detail record;
	_count integer;
begin

/*новые новости на витрину*/
for _row in select news.* from news 
		left join storefront.news snews on news.news_id=snews.news_id
		where news.news_type_id in (4,5,6) and  snews.news_id is null loop

	insert into storefront.news 
	select * from news where news_id=_row.news_id;

	/*артисты*/
	for _row_detail in select * from news_artist where news_id=_row.news_id loop
		select count(*) into _count from storefront.melody_artist where melody_artist_id=_row_detail.artist_id;

		if (_count>0) then
			insert into storefront.news_artist (news_id,artist_id) values (_row.news_id,_row_detail.artist_id);
		end if;
		
	
	end loop;

	/*альбомы*/
	for _row_detail in select * from news_album where news_id=_row.news_id loop
		select count(*) into _count from storefront.melody_album where melody_album_id=_row_detail.album_id;

		if (_count>0) then
			insert into storefront.news_album (news_id,album_id) values (_row.news_id,_row_detail.album_id);
		end if;
		
	
	end loop;

	/*карточки*/
	for _row_detail in select * from news_card where news_id=_row.news_id loop
		select count(*) into _count from storefront.content where card_id=_row_detail.card_id;

		if (_count>0) then
			insert into storefront.news_card (news_id,card_id) values (_row.news_id,_row_detail.card_id);
		end if;
	
	end loop;
		
end loop;
		



/*удаляем с витрины новости, удаленные из меты*/
delete from storefront.news where news_id in (
select snews.news_id from storefront.news snews 
left join news on news.news_id=snews.news_id
where snews.news_type_id in (4,5,6) and  news.news_id is null);

return 1;
end;
$$;

ALTER FUNCTION _temp_news_nashe_to_storefront() OWNER TO postgres;

