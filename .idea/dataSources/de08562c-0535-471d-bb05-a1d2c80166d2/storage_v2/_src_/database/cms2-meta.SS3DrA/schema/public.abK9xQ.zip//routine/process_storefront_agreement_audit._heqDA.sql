CREATE FUNCTION process_storefront_agreement_audit() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") VALUES (OLD.storefront_id, OLD.agreement_id, 'D');
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") VALUES (OLD.storefront_id, OLD.agreement_id, 'D');
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") VALUES (NEW.storefront_id, NEW.agreement_id, 'I');
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") VALUES (NEW.storefront_id, NEW.agreement_id, 'I');
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

ALTER FUNCTION process_storefront_agreement_audit() OWNER TO postgres;

