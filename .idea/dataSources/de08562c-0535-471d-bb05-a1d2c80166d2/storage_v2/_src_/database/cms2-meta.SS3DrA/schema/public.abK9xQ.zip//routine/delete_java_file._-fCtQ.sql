CREATE FUNCTION delete_java_file(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
                -- delete dependencies
                DELETE FROM card_file WHERE file_id = id;
                DELETE FROM supported_model WHERE file_id = id;
                DELETE FROM file_content_code WHERE file_id = id;
                --delete java file
                DELETE FROM java_file WHERE java_file_id = id;
END;
$$;

ALTER FUNCTION delete_java_file(UUID) OWNER TO postgres;

