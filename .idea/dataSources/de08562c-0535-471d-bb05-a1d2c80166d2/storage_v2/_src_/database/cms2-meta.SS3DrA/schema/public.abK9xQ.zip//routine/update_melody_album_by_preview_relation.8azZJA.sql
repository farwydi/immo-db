CREATE FUNCTION update_melody_album_by_preview_relation() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            UPDATE melody_album SET modification_date=now() WHERE melody_album_id = OLD.source_id;
        ELSE
            UPDATE melody_album SET modification_date=now() WHERE melody_album_id = NEW.source_id;
        END IF;
        RETURN NULL;
    END;
$$;

ALTER FUNCTION update_melody_album_by_preview_relation() OWNER TO postgres;

