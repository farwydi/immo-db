CREATE FUNCTION delete_melody_genre(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM melody_genre WHERE melody_genre_id = id;
END;
$$;

ALTER FUNCTION delete_melody_genre(INTEGER) OWNER TO postgres;

