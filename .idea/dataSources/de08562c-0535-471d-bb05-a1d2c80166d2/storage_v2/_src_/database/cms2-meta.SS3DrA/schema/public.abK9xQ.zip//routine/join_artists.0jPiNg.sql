CREATE FUNCTION join_artists(main_artist uuid, artist uuid) RETURNS SETOF boolean
	LANGUAGE plpgsql
AS
$$
declare
	_res record;
	_count integer;
BEGIN
/*artists*/	
  SELECT
		melody_artist.melody_artist_id,
		COALESCE(melody_artist.last_name,melody_artist1.last_name) as last_name,
		COALESCE(melody_artist.first_name,melody_artist1.first_name) as first_name,
		COALESCE(melody_artist.middle_name,melody_artist1.middle_name) as middle_name,
		COALESCE(melody_artist.group,melody_artist1.group) as group,
		COALESCE(melody_artist.search_text,melody_artist1.search_text) as search_text,
		COALESCE(melody_artist.first_letter_first_name,melody_artist1.first_letter_first_name) as first_letter_first_name,
		COALESCE(melody_artist.first_letter_last_name,melody_artist1.first_letter_last_name) as first_letter_last_name,
		COALESCE(melody_artist.have_goodok,melody_artist1.have_goodok) as have_goodok,
		COALESCE(melody_artist.description_short,melody_artist1.description_short) as description_short,
		COALESCE(melody_artist.birthday,melody_artist1.birthday) as birthday,
		COALESCE(melody_artist.fts,melody_artist1.fts) as fts
		into _res
	from 
		melody_artist ,
		melody_artist melody_artist1 
	where 
		melody_artist.melody_artist_id=main_artist
	and 
		melody_artist1.melody_artist_id=artist;
    
   
	UPDATE  melody_artist SET
		last_name = _res.last_name,
		first_name = _res.first_name,
		middle_name = _res.middle_name,
		"group" = _res.group,
		search_text = _res.search_text,
		first_letter_first_name = _res.first_letter_first_name,
		first_letter_last_name = _res.first_letter_last_name,
		have_goodok = _res.have_goodok,
		description_short = _res.description_short,
		birthday = _res.birthday,
		fts = _res.fts
	WHERE
		melody_artist_id = main_artist;



	/*relation artist*/ 
	for _res in select * from melody_artist_relation where artist_id=artist loop
		select count(*) into _count from melody_artist_relation where artist_id=main_artist and parent_artist_id=_res.parent_artist_id;

		if _count>0 then
			delete from melody_artist_relation where artist_id=artist and parent_artist_id=_res.parent_artist_id;
		else
			update melody_artist_relation SET artist_id = main_artist
				where artist_id=artist and parent_artist_id=_res.parent_artist_id;
		end if;
	end loop;


	/*relation parent_artist*/
	for _res in select * from melody_artist_relation where parent_artist_id=artist loop
		select count(*) into _count from melody_artist_relation where parent_artist_id=main_artist and is_current=_res.is_current and artist_id=_res.artist_id;

		if _count>0 then
			delete from melody_artist_relation where parent_artist_id=artist and artist_id=_res.artist_id;
		else
			update melody_artist_relation SET parent_artist_id = main_artist
				where parent_artist_id=artist and artist_id=_res.artist_id;
		end if;
	end loop;


	/*card*/
	for _res in select * from melody_card_artist where artist_id=artist loop
		select count(*) into _count from melody_card_artist where artist_id=main_artist and card_id=_res.card_id;

		if _count>0 then
			delete from melody_card_artist where artist_id=artist and card_id=_res.card_id;
		else
			update melody_card_artist SET artist_id = main_artist
				where artist_id=artist and card_id=_res.card_id; 
		end if;
	end loop;


	/*torefront.melody_artist_user_format*/
	for _res in select * from melody_artist_user_format where artist_id=artist loop
		select count(*) into _count from melody_artist_user_format where artist_id=main_artist and user_format_id=_res.user_format_id;

		if _count>0 then
			delete from melody_artist_user_format where artist_id=artist and user_format_id=_res.user_format_id;
		else
			update melody_artist_user_format SET artist_id = main_artist
				where artist_id=artist and user_format_id=_res.user_format_id; 
		end if;
	end loop;


	/*news*/
	for _res in select * from news_artist where artist_id=artist loop
		select count(*) into _count from news_artist where artist_id=main_artist and news_id=_res.news_id;

		if _count>0 then
			delete from news_artist where artist_id=artist and news_id=_res.news_id;
		else
			update news_artist SET artist_id = main_artist
				where artist_id=artist and news_id=_res.news_id; 
		end if;
	end loop;


	/*preview
	for _res in select * from preview_relation where source_id=artist loop
		select count(*) into _count from preview_relation where source_id=main_artist and preview_id=_res.preview_id;

		if _count>0 then
			delete from preview_relation where source_id=artist and preview_id=_res.preview_id;
		else
			update preview_relation SET source_id = main_artist
				where source_id=artist and preview_id=_res.preview_id; 
		end if;
	end loop;
*/
	delete from melody_artist where melody_artist_id = artist;
END;
$$;

ALTER FUNCTION join_artists(UUID, UUID) OWNER TO postgres;

