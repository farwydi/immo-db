CREATE FUNCTION section_type_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('section_type', OLD.section_type_id, 'D', 'section_type_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.section_type_id =  OLD.section_type_id) THEN
																																					INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('section_type', NEW.section_type_id, 'U', 'section_type_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('section_type', NEW.section_type_id, 'I', 'section_type_id');
																																																	INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('section_type', OLD.section_type_id, 'D', 'section_type_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('section_type', NEW.section_type_id, 'I', 'section_type_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION section_type_change_log() OWNER TO postgres;

