CREATE FUNCTION add_daily_artist(_artist_id uuid, _section_id integer, _day_number integer, _schema_proto text) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_founded integer;
_section_daily_id uuid;
_d text;
begin

	_sql_text = '
		select 
			section_daily_id 
		from 
			'|| _schema_proto ||'.section_daily
		where 
			section_id = '|| _section_id ||'
		';
		
	EXECUTE _sql_text into _section_daily_id;		
	
	IF _section_daily_id is null THEN

		return false;
	
		--RAISE EXCEPTION 'not found section_daily by section_id: %',_section_id;
		
	END IF;
	
	
	_sql_text = '
		select 
			count(*) as c
		from
			'|| _schema_proto ||'.section_daily_artist
		where
			artist_id = ''' || _artist_id || '''
		and
			section_daily_id = 
			(
				select 
					section_daily_id 
				from 
					'|| _schema_proto ||'.section_daily 
				where 
					section_id = '|| _section_id ||'
			)
	';
	RAISE NOTICE '%',_sql_text;
	EXECUTE _sql_text into _founded;

	_d = 'null';

	IF(not(_day_number is null)) THEN
		_d = _day_number;
	END IF;	

	if(_founded = 0) THEN
	
		_sql_text = '
			INSERT INTO '|| _schema_proto ||'.section_daily_artist(
				    section_daily_id, artist_id, day_number)
			    VALUES (
				(select 
					section_daily_id 
				from 
					'|| _schema_proto ||'.section_daily
				where 
					section_id = '|| _section_id ||'
				), 
			    ''' || _artist_id || ''',
			    ' || _d ||'
			    );
		';
	ELSE
		_sql_text = '
			UPDATE '|| _schema_proto ||'.section_daily_artist
			SET
				day_number = ' || _d || '
			WHERE
				artist_id = ''' || _artist_id || '''
			AND
				section_daily_id = 
					(select 
						section_daily_id 
					from 
						'|| _schema_proto ||'.section_daily
					where 
						section_id = '|| _section_id ||'
					)
		';

	END IF;
	RAISE NOTICE '%',_sql_text;

	EXECUTE _sql_text;

	return true;

end;
$$;

ALTER FUNCTION add_daily_artist(UUID, INTEGER, INTEGER, TEXT) OWNER TO postgres;

