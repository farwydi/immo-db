CREATE FUNCTION update_java_pdr() RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
update java_card jco set rightholder_id = foo.java_pdr_id from
(
select distinct jc.java_card_id, jp.java_pdr_id
from java_card jc
join card_file cf on jc.java_card_id = cf.card_id
join file_content_code fcc on cf.file_id = fcc.file_id
join content_code cc on fcc.content_code_id = cc.content_code_id
join agreement2content ac on cc.content_billing_id = ac.content
join agreement a on ac.agreement = a.agreement
join contragent c on a.contragent = c.contragent
join agreement2region on agreement2region.agreement = a.agreement
join java_pdr jp on c.contragent = jp.billing_id
) as foo
where jco.java_card_id = foo.java_card_id;
END;
$$;

ALTER FUNCTION update_java_pdr() OWNER TO postgres;

