CREATE FUNCTION update_card_content_category_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

  IF (TG_OP = 'DELETE') THEN
    update melody_card set modification_date=now() where melody_card_id=OLD.card_id;
  ELSE
    update melody_card set modification_date=now() where melody_card_id=NEW.card_id;
END IF;


RETURN null;
END;
$$;

ALTER FUNCTION update_card_content_category_trigger() OWNER TO postgres;

