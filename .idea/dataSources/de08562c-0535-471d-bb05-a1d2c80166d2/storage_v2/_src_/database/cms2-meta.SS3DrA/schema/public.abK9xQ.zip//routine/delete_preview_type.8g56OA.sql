CREATE FUNCTION delete_preview_type(_preview_type_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM preview_type WHERE preview_type_id = _preview_type_id;
END;
$$;

ALTER FUNCTION delete_preview_type(INTEGER) OWNER TO postgres;

