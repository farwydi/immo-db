CREATE FUNCTION preview_picture_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_picture', OLD.preview_picture_id, 'D', 'preview_picture_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.preview_picture_id =  OLD.preview_picture_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_picture', NEW.preview_picture_id, 'U', 'preview_picture_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_picture', NEW.preview_picture_id, 'I', 'preview_picture_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_picture', OLD.preview_picture_id, 'D', 'preview_picture_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_picture', NEW.preview_picture_id, 'I', 'preview_picture_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION preview_picture_change_log() OWNER TO postgres;

