CREATE FUNCTION update_code_author_name_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
 IF old.name <> new.name and exists 
 (select 1 from melody_card_composer where composer_id = old.melody_composer_id)
    THEN
        update content_code cc
        set author_music = left(name,500), billing_modification_date = null
        from
        (select content_code_id, array_to_string(array_agg(distinct name),'; ') as name
        from
        (select fcc.content_code_id, mc.name
        from melody_composer mc 
        join melody_card_composer mca on mca.composer_id = mc.melody_composer_id
        join card_file cf on cf.card_id = mca.card_id
        join file_content_code fcc on fcc.file_id = cf.file_id
        where cf.card_id in (select mca1.card_id from melody_card_composer mca1 
        where mca1.composer_id = old.melody_composer_id)
        order by mc.name) ss
        group by content_code_id) ss where ss.content_code_id = cc.content_code_id;

ELSIF  old.name <> new.name and exists 
 (select 1 from melody_card_author_lyrics where author_lyrics_id = old.melody_composer_id)
    THEN
        update content_code cc
        set author_text = left(name,500), billing_modification_date = null
        from
        (select content_code_id, array_to_string(array_agg(distinct name),'; ') as name
        from
        (select fcc.content_code_id, mc.name
        from melody_composer mc 
        join melody_card_author_lyrics mca on mca.author_lyrics_id = mc.melody_composer_id
        join card_file cf on cf.card_id = mca.card_id
        join file_content_code fcc on fcc.file_id = cf.file_id
        where cf.card_id in (select mca1.card_id from melody_card_author_lyrics mca1 where mca1.author_lyrics_id = old.melody_composer_id)
        order by mc.name) ss
        group by content_code_id) ss 
        where ss.content_code_id = cc.content_code_id;
    END IF;
        RETURN NEW;
END;
$$;

ALTER FUNCTION update_code_author_name_trigger() OWNER TO postgres;

