CREATE FUNCTION delete_picture_genre(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM picture_genre WHERE picture_genre_id = id;
END;
$$;

ALTER FUNCTION delete_picture_genre(INTEGER) OWNER TO postgres;

