CREATE FUNCTION update_melody_card_by_melody_file() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            UPDATE melody_card SET modification_date=now() WHERE melody_card_id in (select card_id from card_file where file_id  = OLD.melody_file_id);
            RETURN OLD;
        ELSE
            UPDATE melody_card SET modification_date=now() WHERE melody_card_id in (select card_id from card_file where file_id = NEW.melody_file_id);
        END IF;
        RETURN NULL;
    END;
$$;

ALTER FUNCTION update_melody_card_by_melody_file() OWNER TO postgres;

