CREATE FUNCTION delete_theme_file(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
 -- delete dependencies
 DELETE FROM card_file WHERE file_id = id;
 DELETE FROM supported_model WHERE file_id = id;
 DELETE FROM file_content_code WHERE file_id = id;
 --delete theme file
 DELETE FROM theme_file WHERE theme_file_id = id;
END;
$$;

ALTER FUNCTION delete_theme_file(UUID) OWNER TO postgres;

