CREATE FUNCTION fill_melody_card_weight() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row RECORD;
	_counter integer;
begin

_counter := 1000;

FOR _row IN select melody_card_id from melody_card order by name
LOOP
	update melody_card set weight = _counter where melody_card_id = _row.melody_card_id;
	_counter = _counter + 1000;
END LOOP;

end;
$$;

ALTER FUNCTION fill_melody_card_weight() OWNER TO postgres;

