CREATE FUNCTION prototype_update_price_category(_schema text) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
            _row RECORD;
            _id int;
BEGIN
            FOR _row IN EXECUTE 'SELECT pc.* from price_category pc'
            LOOP   
                    _id = null;
                        EXECUTE 'SELECT 1 FROM '|| _schema ||'.price_category WHERE tariff_id = '|| _row.tariff_id INTO _id;
                        
                        IF _id is not null THEN               
                        
                        EXECUTE 'UPDATE '|| _schema ||'.price_category SET '
                                               || coalesce('"name" = '''|| _row.name ||'''','"name" = null')||','
                                               || coalesce('description = '''|| _row.description ||'''','description = null')||','
                                               || coalesce('billing_uri_id = '''|| _row.billing_uri_id ||'''', 'billing_uri_id = null')||',
                                               abonent_price = '|| coalesce(_row.abonent_price, 0) ||','
                                               || coalesce('tariff_code = '''|| _row.tariff_code ||'', 'tariff_code = null')||'                                              
                                   WHERE
                                               tariff_id = '|| _row.tariff_id ||'
                        ';                      
                        ELSE
                        EXECUTE 'INSERT INTO '|| _schema || '.price_category
                        (
                                   tariff_id,
                                   "name",
                                   description,
                                   billing_uri_id,
                                   abonent_price,
                                   tariff_code
                        )
                        VALUES
                        (                                  
                                   '|| _row.tariff_id ||','
                                    || coalesce(''''|| _row.name ||'''','null')||','
                                   || coalesce(''''|| _row.description ||'''','null')||','
                                   || coalesce(''''|| _row.billing_uri_id ||'''', 'null')||','
                                   || coalesce(_row.abonent_price, 0) ||','
                                   || coalesce(''''|| _row.tariff_code ||'', 'null')||'
                        )
                        ';
                        END IF;                        
            END LOOP;

END;
$$;

ALTER FUNCTION prototype_update_price_category(TEXT) OWNER TO postgres;

