CREATE FUNCTION get_section_daily_content_by_type(_schema text, _section_type_id integer, _section_id integer, _day_number integer, _where text, _pattern text, _delimiter text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
	_row_section_daily RECORD;
	_row RECORD;
	_text_day_number text;

begin

	IF (_section_id is NULL) THEN

		EXECUTE 'SELECT *
			FROM
			     ' || _schema || '.section  LEFT JOIN ' || _schema || '.section_daily ON section.section_id = section_daily.section_id
			WHERE section_type_id =' ||_section_type_id ||
			' ORDER BY section_daily.order
			LIMIT 1' into _row_section_daily;
	ELSE 

		EXECUTE 'SELECT  *
			FROM ' || _schema || '.section_daily
			WHERE section_id = '|| _section_id ||
			' ORDER BY section_daily.order
			LIMIT 1' into _row_section_daily;
	END IF;

	if (_row_section_daily is null) THEN
		return;
	END IF;
	
	_text_day_number:='';

	IF (_day_number is not NULL) THEN
		_text_day_number:=' and day_number=' || _day_number;
	END IF; 


	FOR _row in EXECUTE 
			'select * from '|| _schema ||'."get_melody_card"
				('''|| _schema || '''::text,
				null,
				''INNER JOIN (select card_id from ' || _schema || '.section_daily_content where section_daily_id=''''' || _row_section_daily.section_daily_id || ''''' ' || COALESCE( _text_day_number,'') ||
					' ORDER BY RANDOM() limit '|| COALESCE(_row_section_daily.limit,1) || ') t on t.card_id=content.card_id''::text , 
				'''|| COALESCE (_where,'') ||'''::text,
				''''::text,
				0,
				'''|| _pattern ||'''::text,'''|| _delimiter ||'''::text,'|| _preview_type_id ||','|| _preview_watermark_id||') as (card_id uuid,"name" text,artist text,artist_uuid text, preview_fat_name text)'
			LOOP 
		return next _row;
	END LOOP;

 

end;
$$;

ALTER FUNCTION get_section_daily_content_by_type(TEXT, INTEGER, INTEGER, INTEGER, TEXT, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

