CREATE FUNCTION delete_content_type_delivery_type(dtype_id integer, ctype_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM content_type_delivery_type WHERE delivery_type_id = dtype_id AND content_type_id = ctype_id;
END;
$$;

ALTER FUNCTION delete_content_type_delivery_type(INTEGER, INTEGER) OWNER TO postgres;

