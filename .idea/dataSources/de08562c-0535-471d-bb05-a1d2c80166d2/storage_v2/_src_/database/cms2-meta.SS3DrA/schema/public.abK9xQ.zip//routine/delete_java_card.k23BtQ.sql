CREATE FUNCTION delete_java_card(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM java_card WHERE java_card_id = id;
	DELETE FROM card_content_category WHERE card_id = id;
	DELETE FROM card_association WHERE card_id = id;
END;
$$;

ALTER FUNCTION delete_java_card(UUID) OWNER TO postgres;

