CREATE FUNCTION update_melody_artist_genre_by_ddex_genres() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
           UPDATE melody_artist_genre SET modification_date=now() WHERE genre_id in (select genre_id from ddex_genre_genre dgg Where ddex_genre_id = OLD.ddex_genre_id);
        ELSE
            UPDATE melody_artist_genre SET modification_date=now() WHERE genre_id in (select genre_id from ddex_genre_genre dgg Where ddex_genre_id = NEW.ddex_genre_id);
        END IF;
        RETURN NULL;
    END;
$$;

ALTER FUNCTION update_melody_artist_genre_by_ddex_genres() OWNER TO postgres;

