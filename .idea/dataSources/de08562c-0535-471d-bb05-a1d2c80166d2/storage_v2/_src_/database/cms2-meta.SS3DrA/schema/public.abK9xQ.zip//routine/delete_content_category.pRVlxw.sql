CREATE FUNCTION delete_content_category(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM content_category WHERE content_category_id = id;
END;
$$;

ALTER FUNCTION delete_content_category(INTEGER) OWNER TO postgres;

