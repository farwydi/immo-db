CREATE FUNCTION update_code_registration_name_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        update content_code 
        set registration_name = left(new.name,500), billing_modification_date = null
        where content_code_id in (select content_code_id 
        from file_content_code fcc
        join card_file cf on cf.file_id = fcc.file_id
        where cf.card_id = old.melody_card_id);
        RETURN NEW;
END;
$$;

ALTER FUNCTION update_code_registration_name_trigger() OWNER TO postgres;

