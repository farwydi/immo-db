CREATE FUNCTION delete_new_java_card(card_id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
                --delete user relations
                DELETE FROM user_new_content WHERE new_source_id IN
                (
                               SELECT card_id
                               union
                               SELECT new_file_id from new_card_file where new_card_id = card_id
                               union
                               SELECT new_preview_id from new_preview_relation where source_id = card_id
                );

                --delete new java files
                DELETE FROM new_supported_model where new_file_id in (SELECT new_file_id from new_card_file where new_card_id = card_id);
                DELETE FROM new_unsupported_model where new_file_id in (SELECT new_file_id from new_card_file where new_card_id = card_id);
                DELETE FROM new_java_file WHERE new_java_file_id in (SELECT new_file_id from new_card_file where new_card_id = card_id);
                DELETE FROM new_card_file WHERE new_card_id = card_id;

                --delete previews
                DELETE FROM new_preview_picture WHERE new_preview_picture_id in (SELECT new_preview_id from new_preview_relation where source_id = card_id);
                DELETE FROM new_preview_video WHERE new_preview_video_id in (SELECT new_preview_id from new_preview_relation where source_id = card_id);
                DELETE FROM new_preview_relation WHERE source_id = card_id;

                --delete tags relations
                delete from new_java_card_tag where new_java_card_id = card_id;

                --delete new java card
                DELETE FROM new_java_card WHERE new_java_card_id = card_id;

END;
$$;

ALTER FUNCTION delete_new_java_card(UUID) OWNER TO postgres;

