CREATE VIEW new_card_goodok(card_id, operator_id, goodok_code_short, goodok_code_long, status) AS
SELECT DISTINCT cf.card_id,
				p.operator_id,
				rbt.goodok_code_short,
				rbt.goodok_code_long,
				rbt.status
FROM card_file cf
		 JOIN rbt_code rbt ON cf.file_id = rbt.file_id
		 JOIN rbt_platform p ON p.rbt_platform_id = rbt.rbt_platform_id
WHERE rbt.status = 0
ORDER BY cf.card_id, p.operator_id, rbt.goodok_code_short, rbt.goodok_code_long, rbt.status;

ALTER TABLE new_card_goodok
	OWNER TO postgres;

