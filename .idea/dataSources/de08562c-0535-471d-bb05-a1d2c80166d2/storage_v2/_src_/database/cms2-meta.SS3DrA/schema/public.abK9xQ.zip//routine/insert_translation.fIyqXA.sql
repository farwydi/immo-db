CREATE FUNCTION insert_translation(from_text text, to_text text, from_lang integer, to_lang integer, context integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
   id int;
BEGIN
    IF from_text = '' OR to_text = '' THEN
        RETURN;
    END IF;
    BEGIN
        INSERT INTO language_translation(context_id, language_id, token) VALUES (context, from_lang, from_text) RETURNING language_translation_id INTO id;
    EXCEPTION WHEN unique_violation THEN
        SELECT language_translation_id INTO id FROM language_translation WHERE md5_hash = md5(from_text) AND context_id = context AND language_id = from_lang AND source_id is null;
    END;
    BEGIN
        INSERT INTO language_translation(context_id, language_id, token, source_id) VALUES (context, to_lang, to_text, id);
    EXCEPTION WHEN unique_violation THEN
        UPDATE language_translation SET token = to_text WHERE context_id = context AND language_id = to_lang AND source_id = id;
    END;
END;
$$;

ALTER FUNCTION insert_translation(TEXT, TEXT, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

