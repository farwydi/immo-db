CREATE FUNCTION update_melody_artist_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

    --обновляем modification_date в melody_album
    IF (TG_OP = 'DELETE') THEN
        update melody_album set modification_date = now() where primary_artist_id = OLD.melody_artist_id;  
        update melody_card set modification_date = now() where melody_card_id in (select card_id from melody_card_artist where artist_id = OLD.melody_artist_id);
    ELSE
        update melody_album set modification_date = now() where primary_artist_id = NEW.melody_artist_id;  
        update melody_card set modification_date = now() where melody_card_id in (select card_id from melody_card_artist where artist_id = NEW.melody_artist_id);
    END IF;

    --обновляем поисковый индекс
    IF (TG_OP = 'DELETE') THEN
        delete from extra.artist_search where melody_artist_id = OLD.melody_artist_id;
    ELSIF (TG_OP = 'UPDATE') THEN
        update extra.artist_search 
        set name = coalesce(nullif(trim(NEW.first_name || chr(32) || NEW.last_name), ''), nullif(trim(NEW.group), ''), nullif(trim(NEW.first_name), ''), nullif(trim(NEW.last_name), '')) 
        where melody_artist_id = OLD.melody_artist_id;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO extra.artist_search(melody_artist_id, name) 
        VALUES (NEW.melody_artist_id, coalesce(nullif(trim(NEW.first_name || chr(32) || NEW.last_name), ''), nullif(trim(NEW.group), ''), nullif(trim(NEW.first_name), ''), nullif(trim(NEW.last_name), '')));
    END IF;

    IF (TG_OP = 'DELETE') THEN RETURN OLD; END IF;
    RETURN NEW;

    END;
$$;

ALTER FUNCTION update_melody_artist_trigger() OWNER TO postgres;

