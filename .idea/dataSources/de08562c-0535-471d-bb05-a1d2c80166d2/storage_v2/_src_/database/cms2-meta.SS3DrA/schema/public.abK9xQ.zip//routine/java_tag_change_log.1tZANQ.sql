CREATE FUNCTION java_tag_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_tag', OLD.java_tag_id, 'D', 'java_tag_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.java_tag_id =  OLD.java_tag_id) THEN
																																					INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_tag', NEW.java_tag_id, 'U', 'java_tag_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_tag', NEW.java_tag_id, 'I', 'java_tag_id');
																																																	INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_tag', OLD.java_tag_id, 'D', 'java_tag_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_tag', NEW.java_tag_id, 'I', 'java_tag_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION java_tag_change_log() OWNER TO postgres;

