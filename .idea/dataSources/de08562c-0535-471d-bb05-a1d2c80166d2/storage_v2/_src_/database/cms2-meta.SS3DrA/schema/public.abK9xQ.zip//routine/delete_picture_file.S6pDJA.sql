CREATE FUNCTION delete_picture_file(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM picture_file WHERE picture_file_id = id;
	DELETE FROM card_file WHERE file_id = id;
	DELETE FROM file_content_code WHERE file_id = id;
END;
$$;

ALTER FUNCTION delete_picture_file(UUID) OWNER TO postgres;

