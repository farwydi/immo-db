CREATE FUNCTION update_card_file_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

        IF (TG_OP = 'DELETE') THEN
                update theme_card set modification_date=now()   where theme_card_id=OLD.card_id;
                update java_card set modification_date=now()    where java_card_id=OLD.card_id;
                update picture_card set modification_date=now() where picture_card_id=OLD.card_id;
                update video_card set modification_date=now()   where video_card_id=OLD.card_id;
                update melody_card set modification_date=now()  where melody_card_id=OLD.card_id;

                update melody_file set modification_date=now()  where melody_file_id=OLD.file_id;
                update rbt_file set modification_date=now()     where rbt_file_id=OLD.file_id;
                update video_file set modification_date=now()   where video_file_id=OLD.file_id;
                update picture_file set modification_date=now() where picture_file_id=OLD.file_id;
                update java_file set modification_date=now()    where java_file_id=OLD.file_id;
                update theme_file set modification_date=now()   where theme_file_id=OLD.file_id;

        ELSE
                update theme_card set modification_date=now()   where theme_card_id=NEW.card_id;
                update java_card set modification_date=now()    where java_card_id=NEW.card_id;
                update picture_card set modification_date=now() where picture_card_id=NEW.card_id;
                update video_card set modification_date=now()   where video_card_id=NEW.card_id;
                update melody_card set modification_date=now()  where melody_card_id=NEW.card_id;

                update melody_file set modification_date=now()  where melody_file_id=NEW.file_id;
                update rbt_file set modification_date=now()     where rbt_file_id=NEW.file_id;
                update video_file set modification_date=now()   where video_file_id=NEW.file_id;
                update picture_file set modification_date=now() where picture_file_id=NEW.file_id;
                update java_file set modification_date=now()    where java_file_id=NEW.file_id;
                update theme_file set modification_date=now()   where theme_file_id=NEW.file_id;

        END IF;

        RETURN null;
END;
$$;

ALTER FUNCTION update_card_file_trigger() OWNER TO postgres;

