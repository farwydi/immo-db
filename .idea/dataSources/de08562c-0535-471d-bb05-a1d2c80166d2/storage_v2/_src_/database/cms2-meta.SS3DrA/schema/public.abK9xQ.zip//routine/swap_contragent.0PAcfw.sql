CREATE FUNCTION swap_contragent() RETURNS void
	LANGUAGE sql
AS
$$
	ALTER TABLE contragent RENAME TO contragent_old;

ALTER TABLE contragent_temp RENAME TO contragent;

DROP TABLE contragent_old CASCADE;

ALTER TABLE contragent
  ADD CONSTRAINT pk_contragent PRIMARY KEY(contragent);

	$$;

ALTER FUNCTION swap_contragent() OWNER TO postgres;

