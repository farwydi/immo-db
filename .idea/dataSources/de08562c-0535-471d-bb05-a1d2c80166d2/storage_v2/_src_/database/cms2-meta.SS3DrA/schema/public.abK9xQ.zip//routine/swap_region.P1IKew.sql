CREATE FUNCTION swap_region() RETURNS void
	LANGUAGE sql
AS
$$
	ALTER TABLE region RENAME TO region_old;

ALTER TABLE region_temp RENAME TO region;

DROP TABLE region_old CASCADE;

ALTER TABLE region
  ADD CONSTRAINT pk_region PRIMARY KEY(region);

	$$;

ALTER FUNCTION swap_region() OWNER TO postgres;

