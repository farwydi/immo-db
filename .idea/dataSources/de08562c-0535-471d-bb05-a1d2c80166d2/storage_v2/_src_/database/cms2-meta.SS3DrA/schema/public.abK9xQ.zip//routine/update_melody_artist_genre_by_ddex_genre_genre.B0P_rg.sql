CREATE FUNCTION update_melody_artist_genre_by_ddex_genre_genre() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            UPDATE melody_artist_genre SET modification_date=now() WHERE genre_id = OLD.genre_id;
        ELSE
            UPDATE melody_artist_genre SET modification_date=now() WHERE genre_id = NEW.genre_id;
        END IF;
        RETURN NULL;
    END;
$$;

ALTER FUNCTION update_melody_artist_genre_by_ddex_genre_genre() OWNER TO postgres;

