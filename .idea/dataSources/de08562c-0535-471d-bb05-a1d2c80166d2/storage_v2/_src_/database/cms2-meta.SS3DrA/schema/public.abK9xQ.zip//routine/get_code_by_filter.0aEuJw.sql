CREATE FUNCTION get_code_by_filter(_filter_id integer, _table text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_where text;
	_sql text;
begin
_where = get_query_by_filter(_filter_id,_table);


_sql = '';

if _where <> '' and _table='melody_card' then
	_sql = 'select distinct content_code.content_code_id,content_code.content_billing_id,melody_card.melody_card_id,content_code.user_format_id,content_code.content_code  
                from content_code
                join file_content_code fcc on fcc.content_code_id=content_code.content_code_id
                join card_file cf on cf.file_id=fcc.file_id
                join melody_card  on melody_card.melody_card_id = cf.card_id  
		inner join melody_card_artist on melody_card.melody_card_id=melody_card_artist.card_id
		inner join melody_artist_genre on melody_artist_genre.artist_id=melody_card_artist.artist_id
		inner join card_file on melody_card.melody_card_id = card_file.card_id
		left join rbt_code on rbt_code.file_id = card_file.file_id where '
		 || _where;
end if;

if _where <> '' and _table = 'video_card' then
	_sql = _sql || 'select distinct content_code.content_code_id,content_code.content_billing_id,cf.card_id,content_code.user_format_id,content_code.content_code  
                from content_code
                join file_content_code fcc on fcc.content_code_id=content_code.content_code_id
                join card_file cf on cf.file_id=fcc.file_id
                join video_card  on video_card.video_card_id = cf.card_id
                left join video_card_genre on video_card.video_card_id=video_card_genre.card_id  
		where ' || _where;
end if;

if _where <> '' and _table = 'java_card' then
	_sql = _sql || 'select distinct content_code.content_code_id,content_code.content_billing_id,cf.card_id,content_code.user_format_id,content_code.content_code  
                from content_code
                join file_content_code fcc on fcc.content_code_id=content_code.content_code_id
                join card_file cf on cf.file_id=fcc.file_id
                join java_card  on java_card.java_card_id = cf.card_id
                left join java_card_tag on java_card_tag.java_card_id = java_card.java_card_id where ' || _where;		
end if;

if _where <> '' and _table = 'picture_card' then
	_sql = _sql || 'select distinct content_code.content_code_id,content_code.content_billing_id,cf.card_id,content_code.user_format_id,content_code.content_code  
                from content_code
                join file_content_code fcc on fcc.content_code_id=content_code.content_code_id
                join card_file cf on cf.file_id=fcc.file_id
                join picture_card  on picture_card.picture_card_id = cf.card_id
		left join picture_card_genre on picture_card_genre.card_id = picture_card.picture_card_id where ' || _where;		
end if;

if _where <> '' and _table = 'theme_card' then
	_sql = _sql || 'select distinct content_code.content_code_id,content_code.content_billing_id,cf.card_id,content_code.user_format_id,content_code.content_code  
                from content_code
                join file_content_code fcc on fcc.content_code_id=content_code.content_code_id
                join card_file cf on cf.file_id=fcc.file_id
                join theme_card  on theme_card.theme_card_id = cf.card_id
		left join theme_card_genre on theme_card_genre.card_id = theme_card.theme_card_id where ' || _where;		
end if;


if _sql <> '' then
	for _row in execute _sql loop
		return next _row;
	end loop;
end if;


end;
$$;

ALTER FUNCTION get_code_by_filter(INTEGER, TEXT) OWNER TO postgres;

