CREATE FUNCTION update_melody_album_by_preview_picture() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            UPDATE melody_album SET modification_date=now() WHERE melody_album_id in (select source_id from preview_relation pr Where pr.preview_id = OLD.preview_picture_id);
        ELSE
            UPDATE melody_album SET modification_date=now() WHERE melody_album_id in (select source_id from preview_relation pr Where pr.preview_id = NEW.preview_picture_id);
        END IF;
        RETURN NULL;
    END;
$$;

ALTER FUNCTION update_melody_album_by_preview_picture() OWNER TO postgres;

