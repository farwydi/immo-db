CREATE VIEW melody_author_lyrics(melody_author_lyrics_id, name) AS
SELECT melody_composer.melody_composer_id AS melody_author_lyrics_id,
	   melody_composer.name
FROM melody_composer;

ALTER TABLE melody_author_lyrics
	OWNER TO postgres;

