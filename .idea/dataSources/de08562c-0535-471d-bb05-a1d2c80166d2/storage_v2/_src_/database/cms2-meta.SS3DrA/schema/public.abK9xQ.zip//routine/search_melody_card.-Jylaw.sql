CREATE FUNCTION search_melody_card(_query text, _section_id integer, _schema_proto text, _schema_meta text, _limit integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_row_res record;
begin
	_sql_text = '
		select 
			c.content_id::integer,
			c.content_code::character varying(15),
			c.card_id::uuid,
			c.section_id::integer,
			c.is_force_publish::boolean,
			mc.name::text,
			coalesce(ma.first_name || chr(32) || ma.last_name,ma.group,ma.first_name,ma.last_name)::text as artist,
			malb.name::text as album
		from 
			'|| _schema_proto ||'.content as c
		inner join
			'|| _schema_meta ||'.melody_card as mc
		on
			mc.melody_card_id = c.card_id
		inner join
			'|| _schema_meta ||'.melody_card_artist as mca
		on	
			mca.card_id = c.card_id
		inner join
			'|| _schema_meta ||'.melody_artist as ma
		on
			ma.melody_artist_id = mca.artist_id	
		left join
			'|| _schema_meta ||'.melody_card_album as mcalb
		on
			mcalb.card_id = c.card_id
		left join
			'|| _schema_meta ||'.melody_album as malb
		on
			malb.melody_album_id = mcalb.album_id
		where 
			fts @@ to_tsquery(''' || replace(_query,'''','''''') || ''')
	';

	if _section_id > 0 then

		_sql_text = _sql_text || '
			and
			(
				c.section_id = ' || _section_id ||' or
				c.section_id in
					(select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')
				or c.section_id in
					(select section_id from '|| _schema_proto ||'.section where parent_id 
					 in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||'))
				or c.section_id in
					(select section_id from '|| _schema_proto ||'.section where parent_id 
					 in (select section_id from '|| _schema_proto ||'.section where parent_id 
					  in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id || ')))
			)
		'; 	

	end if;

	_sql_text = _sql_text || '
		limit '|| _limit ||';		
	';
	FOR _row_res IN EXECUTE _sql_text LOOP
		RETURN NEXT _row_res;
	END LOOP;	
end;
$$;

ALTER FUNCTION search_melody_card(TEXT, INTEGER, TEXT, TEXT, INTEGER) OWNER TO postgres;

