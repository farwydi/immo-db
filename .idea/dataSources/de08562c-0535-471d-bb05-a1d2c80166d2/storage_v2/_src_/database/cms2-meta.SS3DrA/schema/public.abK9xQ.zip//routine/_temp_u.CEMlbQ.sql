CREATE FUNCTION _temp_u() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
begin
for _row in select * from storefront.access_point loop

insert into storefront.user_category_access_point (user_category_id,access_point_id) 
values (1,_row.access_point_id);



end loop;


end;
$$;

ALTER FUNCTION _temp_u() OWNER TO postgres;

