CREATE FUNCTION truncate_table(_table text) RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
begin
	execute 'truncate table ' || _table;
end;
$$;

ALTER FUNCTION truncate_table(TEXT) OWNER TO postgres;

