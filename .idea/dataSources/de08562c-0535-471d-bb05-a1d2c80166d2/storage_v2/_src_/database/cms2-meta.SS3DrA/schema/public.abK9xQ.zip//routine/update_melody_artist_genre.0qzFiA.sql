CREATE FUNCTION update_melody_artist_genre(id uuid, genres integer[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	genreId integer;
	real_id uuid;
BEGIN
real_id=(SELECT(get_main_from_recycle(id)));
	DELETE FROM melody_artist_genre WHERE artist_id = real_id;
	
	FOR i IN COALESCE(array_lower(genres,1),0) .. COALESCE(array_upper(genres,1),-1) LOOP
	genreId := genres[i];
	
	INSERT INTO melody_artist_genre (artist_id, genre_id) VALUES (real_id, genreId);

	END LOOP;
	return;
END;
$$;

ALTER FUNCTION update_melody_artist_genre(UUID, INTEGER[]) OWNER TO postgres;

