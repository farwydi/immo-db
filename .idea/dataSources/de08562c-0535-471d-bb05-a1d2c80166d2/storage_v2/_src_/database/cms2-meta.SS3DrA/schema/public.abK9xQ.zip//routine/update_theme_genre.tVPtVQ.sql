CREATE FUNCTION update_theme_genre(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE theme_genre SET name = _name WHERE theme_genre_id = id;
	IF NOT FOUND THEN
	INSERT INTO theme_genre (theme_genre_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_theme_genre(INTEGER, VARCHAR) OWNER TO postgres;

