CREATE FUNCTION get_tablename_by_card_id(_card_id uuid) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
cnt integer;
tables text[];
begin

tables:=ARRAY['melody','java','picture','video','theme'];

FOR i IN array_lower(tables,1) .. array_upper(tables,1) LOOP
	execute 'select count(*) as cnt from ' ||  tables[i] || '_card where '||  tables[i] ||'_card_id=''' || _card_id || '''' into cnt;

	if (cnt>0) then
		return tables[i] || '_card';
	end if;

END LOOP ;


return '';
end;
$$;

COMMENT ON FUNCTION get_tablename_by_card_id(UUID) IS 'Возвращает название таблицы по card_id';

ALTER FUNCTION get_tablename_by_card_id(UUID) OWNER TO postgres;

