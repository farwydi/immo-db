CREATE FUNCTION update_prototype_search_card_by_section(_schema_meta text, _schema_proto text, _section_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_sql_text1 text;
_card_id uuid;
_search_text text;
_s text;
_i integer;
begin
	if(_section_id > 0) then
		_sql_text = 'select melody_card_id as card_id from '|| _schema_proto ||'.content where section_id = ' || _section_id || ' group by melody_card_id';
	else
		_sql_text = 'select melody_card_id as card_id from '|| _schema_proto ||'.content group by melody_card_id';
	end if;

	_i=0;
	FOR _card_id IN EXECUTE _sql_text LOOP
	
		_sql_text1 = '
			select 
				name
			from 
				' || _schema_meta || '.melody_card as mc
			where
				mc.melody_card_id = ''' || _card_id || '''
		';
		
		EXECUTE _sql_text into _search_text;
		
		_sql_text1 = '
			select
				coalesce(ma.first_name,'''') || chr(32) || coalesce(ma.last_name,'''') || chr(32) || coalesce(ma.group,'''') :: text
			from
				' || _schema_meta || '.melody_artist as ma
			inner join
				' || _schema_meta || '.melody_card_artist as mca
			on
				ma.melody_artist_id = mca.artist_id
				and
				mca.card_id = ''' || _card_id || '''
		';
		
		FOR _s IN EXECUTE _sql_text1 LOOP
			_search_text = _search_text || chr(32) || _s;
		END LOOP;
		
		if(_section_id > 0) then
			_sql_text1 = '
				update 
					'|| _schema_proto ||'.content as c
				set 
					search_text = ''' || replace(_search_text,'''','''''') || ' '' || c.content_code
				where
					card_id = ''' || _card_id || '''
				and
					section_id = '|| _section_id ||'
			';
		else
			_sql_text1 = '
				update 
					'|| _schema_proto ||'.content as c
				set 
					search_text = ''' || replace(_search_text,'''','''''') || ' '' || c.content_code
				where
					card_id = ''' || _card_id || '''
			';
		end if;		
		
		EXECUTE _sql_text1;
		_i = _i+1;

		if(_i % 1000 = 0) then
			RAISE INFO '%',_i;
		end if;
		
	END LOOP;


end;
$$;

ALTER FUNCTION update_prototype_search_card_by_section(TEXT, TEXT, INTEGER) OWNER TO postgres;

