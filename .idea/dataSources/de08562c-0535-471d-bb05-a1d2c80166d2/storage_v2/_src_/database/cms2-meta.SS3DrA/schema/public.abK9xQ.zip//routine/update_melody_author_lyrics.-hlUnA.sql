CREATE FUNCTION update_melody_author_lyrics(author_id uuid, author_name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE melody_composer SET name = author_name WHERE melody_composer_id = author_id;
	
	IF NOT FOUND
		THEN
		INSERT INTO melody_composer (melody_composer_id, name) VALUES (author_id, author_name);
	END IF;
END;
$$;

ALTER FUNCTION update_melody_author_lyrics(UUID, VARCHAR) OWNER TO postgres;

