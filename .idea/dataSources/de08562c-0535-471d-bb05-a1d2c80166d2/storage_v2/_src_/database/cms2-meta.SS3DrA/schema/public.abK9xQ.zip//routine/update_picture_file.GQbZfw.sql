CREATE FUNCTION update_picture_file(_picture_file_id uuid, _content_type_id integer, _fat_name character varying, _rightholder_name character varying, _rightholder_id character varying, _card_id uuid, _height integer, _width integer, _color_depth integer, _horisontal_resolution integer, _vertical_resolution integer, _frame_rate integer, _frame_number integer, _codeid integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE picture_file SET		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		rightholder_name = _rightholder_name,
		rightholder_id = _rightholder_id,
		height = _height, 
		width = _width,
		color_depth = _color_depth,
		horisontal_resolution = _horisontal_resolution,
		vertical_resolution = _vertical_resolution,
		frame_rate = _frame_rate,
		frame_number = _frame_number
	WHERE
		picture_file_id = _picture_file_id;
	IF NOT FOUND THEN
	INSERT INTO picture_file
	(
		picture_file_id,
		content_type_id,
		fat_name,
		rightholder_name,
		rightholder_id,
		height, 
		width,
		color_depth,
		horisontal_resolution,
		vertical_resolution,
		frame_rate,
		frame_number		
	)
	VALUES
	(
		_picture_file_id,
		_content_type_id,
		_fat_name,
		_rightholder_name,
		_rightholder_id,
		_height, 
		_width,
		_color_depth,
		_horisontal_resolution,
		_vertical_resolution,
		_frame_rate,
		_frame_number		
	);
	END IF;

	DELETE FROM card_file WHERE file_id = _picture_file_id;
	INSERT INTO card_file (card_id, file_id) VALUES (_card_id, _picture_file_id);

	DELETE FROM file_content_code WHERE file_id = _picture_file_id;
	INSERT INTO file_content_code (file_id, content_code_id, content_type_id, fat_name)
		SELECT _picture_file_id, content_code_id, _content_type_id, _fat_name FROM content_code WHERE cms_content_code_lookup_id = _codeid;	

	
END;
$$;

ALTER FUNCTION update_picture_file(UUID, INTEGER, VARCHAR, VARCHAR, VARCHAR, UUID, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

