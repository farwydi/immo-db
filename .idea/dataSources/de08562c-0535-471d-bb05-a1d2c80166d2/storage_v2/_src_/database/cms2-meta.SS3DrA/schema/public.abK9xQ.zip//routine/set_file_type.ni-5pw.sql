CREATE FUNCTION set_file_type(_fat_name text, _type integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
    BEGIN
        INSERT INTO extra.file_type(fat_name, type) VALUES (_fat_name, _type);
    EXCEPTION WHEN unique_violation THEN
    UPDATE extra.file_type SET type = _type WHERE fat_name = _fat_name;
    END;
END;
$$;

ALTER FUNCTION set_file_type(TEXT, INTEGER) OWNER TO postgres;

