CREATE FUNCTION create_agreement2content_temp() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
begin

SELECT  count(*) into _count
FROM 
	pg_class c
	JOIN pg_namespace ns ON (c.relnamespace = ns.oid) 
	WHERE
		relkind ='r' and nspname NOT IN ('pg_catalog', 'pg_toast','information_schema') and relname='agreement2content_new';
		

--RAISE EXCEPTION '%',_count;

IF (_count<>0) THEN
	DROP TABLE agreement2content_new;
END IF;		

CREATE TABLE agreement2content_new
(
  agreement2content integer NOT NULL,
  agreement integer NOT NULL,
  "content" integer NOT NULL, -- Соответствует полю content_billing_id в таблице content_code
  owner_content_id character varying(100),
  content_owner_share numeric
);
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE agreement2content_new TO inform;
EXECUTE 'COMMENT ON TABLE agreement2content_new IS ''creation date: ' || now()::varchar || '''';

end;
$$;

ALTER FUNCTION create_agreement2content_temp() OWNER TO postgres;

