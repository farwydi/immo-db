CREATE FUNCTION update_melody_composer_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
          NEW.modification_date := now();
                --обновляем modification_date в melody_card
    IF (TG_OP = 'DELETE') THEN
        select 1;
    ELSE 
        update melody_card set modification_date = now() where melody_card_id in (select card_id from melody_card_composer where composer_id = NEW.melody_composer_id union select card_id from melody_card_author_lyrics where author_lyrics_id = NEW.melody_composer_id) ;
    END IF;
                RETURN NEW;
END;
$$;

ALTER FUNCTION update_melody_composer_trigger() OWNER TO postgres;

