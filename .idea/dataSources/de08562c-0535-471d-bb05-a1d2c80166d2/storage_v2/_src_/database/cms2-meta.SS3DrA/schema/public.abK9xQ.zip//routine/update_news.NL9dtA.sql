CREATE FUNCTION update_news(id uuid, _title character varying, _announcement text, _body text, _display_start_date timestamp without time zone, _expiration_date timestamp without time zone, _source character varying, _source_href character varying, _date timestamp without time zone) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_news_type_id int;
BEGIN
	_news_type_id := 1;	
	UPDATE news_type SET "name" = 'Новости', display_name = 'Новости' WHERE news_type_id = _news_type_id;
	IF NOT FOUND THEN
	INSERT INTO news_type (news_type_id, "name", display_name) VALUES (_news_type_id, 'Новости', 'Новости');
	END IF;

	UPDATE news SET 
		news_type_id = _news_type_id,
		title = _title,
		announcement = _announcement,
		body = _body,
		display_start_date = _display_start_date,
		expiration_date = _expiration_date,
		source = _source,
		source_href = _source_href,
		start_date = _date,
		end_date = _date
	WHERE
		news_id = id;
	IF NOT FOUND THEN
	INSERT INTO news
	(
		news_id,
		news_type_id,
		title,
		announcement,
		body,
		display_start_date,
		expiration_date,
		source,
		source_href,
		start_date,
		end_date	
	)
	VALUES
	(
		id,
		_news_type_id,
		_title,
		_announcement,
		_body,
		_display_start_date,
		_expiration_date,
		_source,
		_source_href,
		_date,
		_date	
	);
	END IF;
END;
$$;

ALTER FUNCTION update_news(UUID, VARCHAR, TEXT, TEXT, TIMESTAMP, TIMESTAMP, VARCHAR, VARCHAR, TIMESTAMP) OWNER TO postgres;

