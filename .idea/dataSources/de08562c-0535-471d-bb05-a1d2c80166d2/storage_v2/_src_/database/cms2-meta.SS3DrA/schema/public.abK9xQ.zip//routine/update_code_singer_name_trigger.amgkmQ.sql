CREATE FUNCTION update_code_singer_name_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
 update content_code cc
        set singer = left(name,500), billing_modification_date = null
        from
        (select content_code_id, array_to_string(array_agg(distinct name),'; ') as name
        from
        (select fcc.content_code_id, eas.name
        from card_file cf
        join file_content_code fcc on fcc.file_id = cf.file_id
        join melody_card_artist mca on mca.card_id = cf.card_id and mca.artist_id = old.melody_artist_id
        JOIN extra.artist_search eas on mca.artist_id = eas.melody_artist_id) ss 
        group by content_code_id) ss where ss.content_code_id = cc.content_code_id;
        RETURN NEW;
END;
$$;

ALTER FUNCTION update_code_singer_name_trigger() OWNER TO postgres;

