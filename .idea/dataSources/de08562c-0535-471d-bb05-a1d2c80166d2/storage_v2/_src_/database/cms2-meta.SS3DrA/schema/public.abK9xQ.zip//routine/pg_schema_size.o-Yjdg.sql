CREATE FUNCTION pg_schema_size(text) RETURNS bigint
	LANGUAGE sql
AS
$$
SELECT SUM(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(tablename)))::BIGINT FROM pg_tables WHERE schemaname = $1
$$;

ALTER FUNCTION pg_schema_size(TEXT) OWNER TO postgres;

