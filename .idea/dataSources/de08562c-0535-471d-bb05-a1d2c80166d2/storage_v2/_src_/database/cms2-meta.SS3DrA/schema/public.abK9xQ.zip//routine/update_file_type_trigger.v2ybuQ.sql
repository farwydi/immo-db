CREATE FUNCTION update_file_type_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        PERFORM set_file_type(NEW.fat_name::TEXT, TG_ARGV[0]::int);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        PERFORM unset_file_type(OLD.fat_name::TEXT);
        RETURN OLD;
    END IF;
END;
$$;

ALTER FUNCTION update_file_type_trigger() OWNER TO postgres;

