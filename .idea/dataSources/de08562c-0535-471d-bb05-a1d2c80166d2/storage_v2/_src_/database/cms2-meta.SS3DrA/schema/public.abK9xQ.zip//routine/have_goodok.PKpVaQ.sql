CREATE FUNCTION have_goodok(_card_id uuid, _operator_id integer) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
DECLARE
	_result boolean;
BEGIN 
	SELECT count(*)>0 INTO _result FROM card_goodok WHERE card_id=_card_id AND operator_id=_operator_id;

	RETURN _result;
END;
$$;

ALTER FUNCTION have_goodok(UUID, INTEGER) OWNER TO postgres;

