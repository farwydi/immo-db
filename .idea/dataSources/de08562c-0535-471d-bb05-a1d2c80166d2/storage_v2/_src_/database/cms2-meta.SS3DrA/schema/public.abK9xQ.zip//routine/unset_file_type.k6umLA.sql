CREATE FUNCTION unset_file_type(_fat_name text) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
    DELETE FROM extra.file_type WHERE fat_name = _fat_name;
END;
$$;

ALTER FUNCTION unset_file_type(TEXT) OWNER TO postgres;

