CREATE FUNCTION _temp_ac() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	_row_card record;
	_count integer;
begin
for _row in select * from storefront.association loop

	select (random()*20)::int into _count;
	
	for _row_card in execute 'select card_id from storefront.content where card_id not in (select card_id from storefront.card_association where
		association_id='|| _row.association_id|| ')  
	 order by random() limit ' ||_count loop
		insert into storefront.card_association(card_id,association_id) values (_row_card.card_id,_row.association_id);
	end loop;
	

end loop;
end;
$$;

ALTER FUNCTION _temp_ac() OWNER TO postgres;

