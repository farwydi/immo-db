CREATE FUNCTION update_preview_video(_preview_video_id uuid, _preview_type_id integer, _content_type_id integer, _source_id uuid, _fat_name character varying, _duration character varying, _format character varying, _coding character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE preview_video SET
		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		duration = _duration,
		format = _format,
		coding = _coding		
	WHERE
		preview_video_id = _preview_video_id;
	IF NOT FOUND THEN
	INSERT INTO preview_video
	(
		preview_video_id,
		content_type_id,
		fat_name,
		duration,
		format,
		coding			
	)
	VALUES
	(
		_preview_video_id,		
		_content_type_id,
		_fat_name,
		_duration,
		_format,
		_coding			
	);
	END IF;
	UPDATE preview_relation SET 
		preview_id=_preview_video_id,
		source_id=
source_id,
		preview_type_id=_preview_type_id
	WHERE preview_id=_preview_video_id AND source_id=_source_id;

	IF NOT FOUND THEN
		INSERT INTO preview_relation 
		(
			preview_id,
			source_id,
			preview_type_id
		)
		VALUES
		(
			_preview_video_id,
			_source_id,
			_preview_type_id
		);
	END IF;			
	
END;
$$;

ALTER FUNCTION update_preview_video(UUID, INTEGER, INTEGER, UUID, VARCHAR, VARCHAR, VARCHAR, VARCHAR) OWNER TO postgres;

