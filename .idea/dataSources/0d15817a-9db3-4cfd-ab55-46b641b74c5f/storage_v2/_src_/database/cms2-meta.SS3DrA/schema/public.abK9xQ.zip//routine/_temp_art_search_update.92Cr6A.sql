CREATE FUNCTION _temp_art_search_update() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	_searct_text text;
begin

for _row in select * from storefront.melody_artist loop

	select COALESCE("group",'') || ' ' || COALESCE(last_name,'') || ' ' || COALESCE(first_name,'') || ' '||  COALESCE(tag,'') into _searct_text
	from melody_artist
	where melody_artist_id=_row.melody_artist_id;

	if (_searct_text is not null) then 
		update storefront.melody_artist
			set search_text=_searct_text
		where melody_artist_id=_row.melody_artist_id;
	end if;
end loop;

DROP INDEX storefront.melody_artist_fts_idx;
ALTER TABLE storefront.melody_artist DROP COLUMN fts; 


ALTER TABLE storefront.melody_artist ADD COLUMN fts tsvector;
UPDATE storefront.melody_artist SET fts = to_tsvector('russian', (coalesce(search_text,'')));
CREATE INDEX melody_artist_fts_idx ON storefront.melody_artist USING gin(fts);


end;
$$;

ALTER FUNCTION _temp_art_search_update() OWNER TO postgres;

