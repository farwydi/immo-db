CREATE FUNCTION delete_preview_melody(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM preview_melody WHERE preview_melody_id = id;
	DELETE FROM preview_relation WHERE preview_id = id;
END;
$$;

ALTER FUNCTION delete_preview_melody(UUID) OWNER TO postgres;

