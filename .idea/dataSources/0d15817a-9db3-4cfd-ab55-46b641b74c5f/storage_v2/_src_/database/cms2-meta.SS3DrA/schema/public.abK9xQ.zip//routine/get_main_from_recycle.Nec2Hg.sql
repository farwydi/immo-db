CREATE FUNCTION get_main_from_recycle(source uuid) RETURNS uuid
	LANGUAGE plpgsql
AS
$$
declare
ret uuid;	
BEGIN
SELECT into ret original_id from recycle where deleted_id=source;
if ret IS NULL THEN
          RETURN source;
          ELSE
          RETURN get_main_from_recycle(ret); 
      END IF;
END;
$$;

ALTER FUNCTION get_main_from_recycle(UUID) OWNER TO postgres;

