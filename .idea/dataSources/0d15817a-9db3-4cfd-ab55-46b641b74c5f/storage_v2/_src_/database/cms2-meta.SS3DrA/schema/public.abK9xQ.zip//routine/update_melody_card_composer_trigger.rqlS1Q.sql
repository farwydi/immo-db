CREATE FUNCTION update_melody_card_composer_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

        IF (TG_OP = 'DELETE') THEN
                update melody_card set modification_date=now() where melody_card_id=OLD.card_id;
                update melody_composer set modification_date=now() where melody_composer_id=OLD.composer_id;
        ELSE
                update melody_card set modification_date=now() where melody_card_id=NEW.card_id;
                update melody_composer set modification_date=now() where melody_composer_id=NEW.composer_id;
        END IF;

        RETURN null;
END;
$$;

ALTER FUNCTION update_melody_card_composer_trigger() OWNER TO postgres;

