CREATE FUNCTION delete_new_melodies(id_user integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
_sql_mci text;
_deleting_sources_id text;
_i integer;
_row record;
BEGIN

_deleting_sources_id = '';
_i = 0;

--�������� ������ id ��������� ������, ��������� � ������
_sql_mci = '
                    select new_melody_card_id from new_melody_card WHERE new_melody_card_id in (select new_source_id from user_new_content where user_id = ' || id_user || ')
                    UNION
                    select new_melody_file_id from new_melody_file WHERE new_melody_file_id in (select new_source_id from user_new_content where user_id = ' || id_user || ')
                   ';
FOR _row IN EXECUTE _sql_mci LOOP
                IF (_i <> 0) THEN
                               _deleting_sources_id = _deleting_sources_id || ', ';
                END IF;
                _deleting_sources_id = _deleting_sources_id || '''' || cast(_row.new_melody_card_id as text) || '''';
                _i = _i + 1;
END LOOP;

--��������� � ������ id ��������� �������

IF ( char_length(_deleting_sources_id) > 0 ) THEN 

                _sql_mci = 'SELECT new_preview_id FROM new_preview_relation WHERE source_id in (' || _deleting_sources_id || ')';
                FOR _row IN EXECUTE _sql_mci LOOP
                               IF (_i <> 0) THEN
                                               _deleting_sources_id = _deleting_sources_id || ', ';
                               END IF;
                               _deleting_sources_id = _deleting_sources_id || '''' || cast(_row.new_preview_id as text) || '''';
                               _i = _i + 1;
                END LOOP;

END IF;

--RAISE NOTICE '%', _deleting_sources_id;
--RAISE NOTICE '%', char_length(_deleting_sources_id) ;

--drop items

IF ( char_length(_deleting_sources_id) > 0 ) THEN 

                EXECUTE 'DELETE FROM new_card_file WHERE new_card_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_album WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_album WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_artist WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_composer WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_author_lyrics WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_association WHERE card_id  IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_card_category WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';

                EXECUTE 'DELETE FROM new_preview_picture WHERE new_preview_picture_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_preview_melody WHERE new_preview_melody_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_preview_relation WHERE source_id IN (' || _deleting_sources_id || ')';

                EXECUTE 'DELETE FROM new_melody_file WHERE new_melody_file_id IN (' || _deleting_sources_id || ')';
                EXECUTE 'DELETE FROM new_melody_card WHERE new_melody_card_id IN (' || _deleting_sources_id || ')';

                EXECUTE 'DELETE FROM user_new_content WHERE user_id = ' || cast(id_user as integer) || ' AND new_source_id IN (' || _deleting_sources_id || ')';

END IF;


END;
$$;

ALTER FUNCTION delete_new_melodies(INTEGER) OWNER TO postgres;

