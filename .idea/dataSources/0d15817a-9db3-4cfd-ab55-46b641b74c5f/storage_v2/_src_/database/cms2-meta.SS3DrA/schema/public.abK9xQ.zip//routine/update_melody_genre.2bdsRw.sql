CREATE FUNCTION update_melody_genre(id integer, _name character varying, _equivalent character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_id integer;
	_max_id integer;
BEGIN
	_max_id=500000;

	IF (id=-1) THEN

		select COALESCE(max(melody_genre_id)+1,_max_id ) into _id from melody_genre;

		IF (_id<_max_id ) THEN
			_id=_max_id;
		END IF;
	ELSE
		_id=id;
	END IF;


	UPDATE melody_genre SET name = _name, equivalent = _equivalent WHERE melody_genre_id = _id;
	IF NOT FOUND THEN
		INSERT INTO melody_genre (melody_genre_id, "name", equivalent) VALUES (_id, _name, _equivalent);
	END IF;
END;
$$;

ALTER FUNCTION update_melody_genre(INTEGER, VARCHAR, VARCHAR) OWNER TO postgres;

