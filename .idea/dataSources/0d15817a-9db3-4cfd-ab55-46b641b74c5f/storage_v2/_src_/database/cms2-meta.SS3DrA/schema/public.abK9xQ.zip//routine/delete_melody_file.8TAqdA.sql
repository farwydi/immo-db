CREATE FUNCTION delete_melody_file(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM melody_file WHERE melody_file_id = id;
	DELETE FROM card_file WHERE file_id = id;
	DELETE FROM file_content_code WHERE file_id = id;
END;
$$;

ALTER FUNCTION delete_melody_file(UUID) OWNER TO postgres;

