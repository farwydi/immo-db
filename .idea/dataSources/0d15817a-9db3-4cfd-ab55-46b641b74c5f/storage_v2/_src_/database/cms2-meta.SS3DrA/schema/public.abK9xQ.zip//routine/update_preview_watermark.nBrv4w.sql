CREATE FUNCTION update_preview_watermark(_preview_watermark_id integer, _name character varying, _fat_name character varying, _height integer, _width integer, _transparency integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE preview_watermark SET
		name = _name
		, fat_name = _fat_name
		, height = _height
		, width = _width
		, transparency = _transparency
	WHERE preview_watermark_id = _preview_watermark_id;
	
	IF NOT FOUND
		THEN
		INSERT INTO preview_watermark (preview_watermark_id, name, fat_name, height, width, transparency)
			VALUES (_preview_watermark_id, _name, _fat_name, _height, _height, _transparency);
	END IF;
END;
$$;

ALTER FUNCTION update_preview_watermark(INTEGER, VARCHAR, VARCHAR, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

