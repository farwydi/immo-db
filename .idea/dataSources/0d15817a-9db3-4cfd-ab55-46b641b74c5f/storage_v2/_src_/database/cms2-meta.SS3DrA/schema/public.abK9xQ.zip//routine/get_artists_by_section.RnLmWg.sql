CREATE FUNCTION get_artists_by_section(_section_id integer, _schema_meta text, _schema_proto text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_sql_text_before1 text;
_sql_text_before2 text;
_sql_text_after text;
_row_res record;
_founded integer;
begin

	_sql_text_before1 = '
		select 
			ma.melody_artist_id as artist_id,
			coalesce(ma.last_name || chr(32) ||  ma.first_name, ma.group, ma.last_name, ma.first_name) as Name,
		';
			
	_sql_text_before2 = '	
		from
			' || _schema_meta ||'.melody_artist as ma
		where
			ma.melody_artist_id
		in
			(
				select 
					artist_id
				from
					' || _schema_meta ||'.melody_card_artist as mca
				where
					mca.card_id
				in
					(
						select
							c.card_id
						from
							prototype2.content as c
						where
	';

	_sql_text_after = '
						group by c.card_id
					)
				group by artist_id
			)
	';

	--_sql_text = _sql_text_before1 || 'false'  || _sql_text_before2 || 'c.section_id = ' || _section_id || _sql_text_after; 
	--_founded = 0;

	---RAISE NOTICE '%',_sql_text;

	/*FOR _row_res IN EXECUTE _sql_text LOOP
		_founded = _founded + 1;
		RETURN NEXT _row_res;
	END LOOP;	*/

	--Если не нашли в главной секции, ищем в дочерних
	--Расчитанно на тройную вложенность максимум
	--IF _founded = 0 THEN
		--RAISE NOTICE ' не нашли';
	_sql_text = '
		select 
			ma.melody_artist_id as artist_id,
			coalesce(ma.last_name || chr(32) ||  ma.first_name, ma.group, ma.last_name, ma.first_name) as Name,
			true
		from
			' || _schema_meta ||'.melody_artist as ma
		where
			ma.melody_artist_id
		in
			(
				select 
					artist_id
				from
					' || _schema_meta ||'.melody_card_artist as mca
				where
					mca.card_id
				in
					(
						select
							c.card_id
						from
							prototype2.content as c
						where
							c.section_id = ' || _section_id || '
							or
							c.section_id in
								(select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')
							or c.section_id in
								(select section_id from '|| _schema_proto ||'.section where parent_id 
								 in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||'))
							or c.section_id in
								(select section_id from '|| _schema_proto ||'.section where parent_id 
								 in (select section_id from '|| _schema_proto ||'.section where parent_id 
								  in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')))						
						group by c.card_id
					)
				group by artist_id
			)								  
		';
		
		/*_sql_text = _sql_text_before1 || 'true'  || _sql_text_before2 || '
			c.section_id = ' || _section_id || '
			or
			c.section_id in
				(select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')
			or c.section_id in
				(select section_id from '|| _schema_proto ||'.section where parent_id 
				 in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||'))
			or c.section_id in
				(select section_id from '|| _schema_proto ||'.section where parent_id 
				 in (select section_id from '|| _schema_proto ||'.section where parent_id 
				  in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')))				 
		' || _sql_text_after;*/
		--RAISE NOTICE '%',_sql_text;
		FOR _row_res IN EXECUTE _sql_text LOOP
			RETURN NEXT _row_res;
		END LOOP;			
	--END IF;
end;
$$;

ALTER FUNCTION get_artists_by_section(INTEGER, TEXT, TEXT) OWNER TO postgres;

