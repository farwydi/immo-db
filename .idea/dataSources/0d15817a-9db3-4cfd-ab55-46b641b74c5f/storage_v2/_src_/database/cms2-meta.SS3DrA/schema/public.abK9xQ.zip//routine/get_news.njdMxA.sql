CREATE FUNCTION get_news(_schema text, _where text, _orderby text, _limit integer, _pattern text, _delimiter text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_news_id uuid;
_guid_empty uuid;

_sql_text text;

_row record;
_row_temp record;
_res_record record;

_artist_name text;
_artist_name_temp text;

_artist_uuid text;
_artist_uuid_temp uuid;

_album_name text;
_album_uuid text;
_album_uuid_temp uuid;

_card_name text;
_card_uuid text;
_card_uuid_temp uuid;

_preview_fat_name text;

_i integer;

begin


_sql_text= 
	'select news.*,news_artist.*,news_album.*,news_card.*,melody_artist.*, melody_album.*, content.name as content_name
	 from ' || _schema || '.news 
		left outer join ' || _schema || '.news_artist on news.news_id=news_artist.news_id
		left outer join ' || _schema || '.news_album on news.news_id=news_album.news_id
		left outer join ' || _schema || '.news_card on news.news_id=news_card.news_id
		left outer join ' || _schema || '.melody_artist on melody_artist.melody_artist_id=news_artist.artist_id
		left outer join ' || _schema || '.melody_album on melody_album.melody_album_id=news_album.album_id 
		left outer join ' || _schema || '.content on news_card.card_id=content.card_id '
		
		||COALESCE (_where,'') || ' '
			|| CASE WHEN _orderby is null THEN 'ORDER BY '
					WHEN _orderby='' THEN 'ORDER BY '
					ELSE _orderby || ', '
			   END
			|| 'news.news_id '; 

_news_id='00000000-0000-0000-0000-000000000000'; 
_guid_empty='00000000-0000-0000-0000-000000000000'; 

_artist_name='';
_artist_uuid='';

_album_name='';
_album_uuid='';

_i=0;

FOR _row IN EXECUTE _sql_text LOOP
	IF (_news_id<>_row.news_id) THEN

		IF (_limit>0 and _i>=_limit) THEN 
			exit;
		END IF;
		
		--новая карточка
		IF (_news_id<>_guid_empty) THEN
			--сохраняем предыдущую

			select  _news_id::uuid,
				_row_temp.news_type_id::integer,
				_row_temp.title::text,
				_row_temp.announcement::text,
				_row_temp.body::text,
				_row_temp.display_start_date::timestamp,
				_row_temp.expiration_date::timestamp,
				_row_temp.source::text,
				_row_temp.source_href::text,
				_row_temp.start_date::timestamp,
				_row_temp.end_date::timestamp,
				_row_temp.location::text,
				_artist_name::text,
				_artist_uuid::text,
				_album_name::text,
				_album_uuid::text,
				_card_name::text,
				_card_uuid::text,
				_preview_fat_name::text

			into _res_record; 
				


			
			return next _res_record;

			_i=_i+1;
			
		END IF;
		_artist_name=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name=replace(_artist_name,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name=replace(_artist_name,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name=replace(_artist_name,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name=trim(both ' ' from _artist_name);

		_artist_uuid=cast(_row.melody_artist_id as text);

		_artist_uuid_temp=_row.melody_artist_id;


		_album_name=_row.name;
		_album_uuid=_row.melody_album_id::text;
		_album_uuid_temp=_row.melody_album_id;

		_card_name=_row.content_name;
		_card_uuid=_row.card_id;
		_card_uuid_temp=_row.card_id;

		execute 'select ' ||_schema || '.get_preview_picture('''||_schema ||''','||_preview_type_id ||','|| _preview_watermark_id ||','''|| _row.news_id || ''') ' into _preview_fat_name;	

		
	ELSE

		IF (_artist_uuid_temp<>_row.melody_artist_id) THEN
			--другой исполнитель
			_artist_name_temp=replace(_pattern,'{group}',COALESCE( _row.group,''));
			_artist_name_temp=replace(_artist_name_temp,'{last_name}',COALESCE( _row.last_name,''));
			_artist_name_temp=replace(_artist_name_temp,'{first_name}',COALESCE( _row.first_name,''));
			_artist_name_temp=replace(_artist_name_temp,'{middle_name}',COALESCE( _row.middle_name,''));
			_artist_name_temp=trim(both ' ' from _artist_name_temp);

			_artist_name=_artist_name || _delimiter || _artist_name_temp;

			_artist_uuid=_artist_uuid ||_delimiter || cast(_row.melody_artist_id as text);

			_artist_uuid_temp=_row.melody_artist_id;
		END IF;

		IF (_album_uuid_temp<>_row.melody_album_id) THEN
			
			_album_name=_album_name || _delimiter || _row."name";

			_album_uuid=_album_uuid ||_delimiter || cast(_row.melody_album_id as text);

			_album_uuid_temp=_row.melody_album_id;
		END IF;

		IF (_card_uuid_temp<>_row.card_id) THEN
			_card_name=_card_name || _delimiter || _row.content_name;
			_card_uuid=_card_uuid || _delimiter || _row.card_id;
			_card_uuid_temp=_row.card_id;
		END IF;
		
	
	END IF;

	_news_id=_row.news_id;
	_row_temp=_row;
	
END LOOP;


IF (_news_id<>_guid_empty and _limit>0 and _i<_limit) THEN

	--сохраняем последнюю карточку
	select  _news_id::uuid,
			_row_temp.news_type_id::integer,
			_row_temp.title::text,
			_row_temp.announcement::text,
			_row_temp.body::text,
			_row_temp.display_start_date::timestamp,
			_row_temp.expiration_date::timestamp,
			_row_temp.source::text,
			_row_temp.source_href::text,
			_row_temp.start_date::timestamp,
			_row_temp.end_date::timestamp,
			_row_temp.location::text,
			_artist_name::text,
			_artist_uuid::text,
			_album_name::text,
			_album_uuid::text,
			_card_name::text,
			_card_uuid::text,
			_preview_fat_name::text

		into _res_record; 
			


		
		return next _res_record;

	
END IF;
end;
$$;

ALTER FUNCTION get_news(TEXT, TEXT, TEXT, INTEGER, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

