CREATE FUNCTION update_association(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE association SET name = _name WHERE association_id = id;
	IF NOT FOUND THEN
	INSERT INTO association (association_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_association(INTEGER, VARCHAR) OWNER TO postgres;

