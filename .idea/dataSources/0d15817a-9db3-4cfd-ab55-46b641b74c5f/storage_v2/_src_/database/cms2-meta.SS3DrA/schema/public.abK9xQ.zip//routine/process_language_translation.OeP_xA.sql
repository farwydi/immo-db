CREATE FUNCTION process_language_translation() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'INSERT') THEN
		NEW.created_at := now();
        END IF;
        NEW.md5_hash := md5(NEW.token);
	RETURN NEW;                
    END;
$$;

ALTER FUNCTION process_language_translation() OWNER TO postgres;

