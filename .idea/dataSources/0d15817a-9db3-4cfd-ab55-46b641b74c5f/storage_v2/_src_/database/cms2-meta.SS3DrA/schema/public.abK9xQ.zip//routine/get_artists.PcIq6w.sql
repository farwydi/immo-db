CREATE FUNCTION get_artists(_melody_card_id uuid) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
_card_id uuid;
_guid_empty uuid;

_sql_text text;

_row record;
_row_temp record;
_res_record record;

_artist_name text;
_artist_name_temp text;

_artist_uuid text;

_pattern text;
_delimiter text;

_i integer;

begin


_sql_text:= 'SELECT 	distinct 	melody_card_artist.card_id, 
			melody_artist.melody_artist_id,	
			melody_artist.group, melody_artist.last_name,
			melody_artist.first_name, melody_artist.middle_name, melody_card_artist.is_dominant
			
	     FROM
			melody_card_artist  
			LEFT JOIN melody_artist  
				ON  melody_card_artist.artist_id=melody_artist.melody_artist_id 
			WHERE  melody_card_artist.card_id = ''' || _melody_card_id || '''

			ORDER BY melody_card_artist.card_id, melody_card_artist.is_dominant desc';


_card_id:='00000000-0000-0000-0000-000000000000'; 
_guid_empty:='00000000-0000-0000-0000-000000000000'; 
_artist_name:='';
_artist_uuid:='';
_pattern:= '{group}{last_name} {first_name} {middle_name}';
_delimiter:= ';';

_i:=0;

FOR _row IN EXECUTE _sql_text LOOP
	IF (_card_id<>_row.card_id) THEN
	
		_artist_name=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name=replace(_artist_name,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name=replace(_artist_name,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name=replace(_artist_name,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name=trim(both ' ' from _artist_name);

		_artist_uuid=cast(_row.melody_artist_id as text);
		
	ELSE
		_artist_name_temp=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name_temp=replace(_artist_name_temp,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name_temp=replace(_artist_name_temp,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name_temp=replace(_artist_name_temp,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name_temp=trim(both ' ' from _artist_name_temp);

		_artist_name:=_artist_name || _delimiter || _artist_name_temp;
	
	END IF;

	_card_id=_row.card_id;
	
END LOOP;

IF (_card_id<>_guid_empty) THEN
	return _artist_name;
else
	return '-';
END IF;
end;
$$;

ALTER FUNCTION get_artists(UUID) OWNER TO postgres;

