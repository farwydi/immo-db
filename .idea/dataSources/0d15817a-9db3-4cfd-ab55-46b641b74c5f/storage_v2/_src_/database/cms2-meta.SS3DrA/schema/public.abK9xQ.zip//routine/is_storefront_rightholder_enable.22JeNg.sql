CREATE FUNCTION is_storefront_rightholder_enable(_storefront_id integer, _agreement_id integer) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
DECLARE
      _count integer;
      _count2 integer;
      _contragent_id integer;
      BEGIN
        --проверить ИД договора в справочнике, если нет считать разрешенным
        SELECT INTO _contragent_id contragent FROM agreement WHERE agreement = _agreement_id;
        IF (_contragent_id is null) THEN RETURN true; END IF;


          --проверить задан ли и черный и белый список правообладателей и договоров, если не задан считать что все разрешено
          SELECT INTO _count count(*) FROM storefront_contragent WHERE storefront_id = _storefront_id;
          SELECT INTO _count2 count(*) FROM storefront_agreement WHERE storefront_id = _storefront_id;
          if ((_count > 0)OR(_count2 >0)) THEN

            --проверить существования белого списка правообладателей или договоров
            SELECT INTO _count count(*) FROM storefront_contragent WHERE storefront_id = _storefront_id AND NOT is_blacklist;
            SELECT INTO _count2 count(*) FROM storefront_agreement WHERE storefront_id = _storefront_id AND NOT is_blacklist;
            IF ((_count > 0)OR(_count2 >0)) THEN
              --задан белый список, работаем по нему
              SELECT INTO _count count(*) FROM storefront_contragent WHERE storefront_id = _storefront_id AND contragent_id = _contragent_id AND NOT is_blacklist;
              --если в белом списке есть, считать разрешенным
              IF (_count > 0) THEN
                RETURN true;
          END IF;
          SELECT INTO _count count(*) FROM storefront_agreement WHERE storefront_id = _storefront_id AND agreement_id = _agreement_id AND NOT is_blacklist;
          --если в белом списке есть считать разрешенным
          IF (_count > 0) THEN 
            RETURN true; 
          END IF;
          --если нет в белых списках то запрещено
          RETURN false;
        ELSE
          --задан черный список
          --задан черный список, работаем по нему
          SELECT INTO _count count(*) FROM storefront_contragent WHERE storefront_id = _storefront_id AND contragent_id = _contragent_id AND is_blacklist;
          --если в черном списке есть, считать запрещенным
          IF (_count > 0) THEN
            RETURN false;
          END IF;
          SELECT INTO _count count(*) FROM storefront_agreement WHERE storefront_id = _storefront_id AND agreement_id = _agreement_id AND is_blacklist;
          --если в черном списке есть считать запрещенным
          IF (_count > 0) THEN 
            RETURN false; 
          END IF;
          -- если нет в черных списках, считать разрешенным
          RETURN true;
          END IF;
        ELSE
          RETURN TRUE;
          END IF;
          END;
$$;

ALTER FUNCTION is_storefront_rightholder_enable(INTEGER, INTEGER) OWNER TO postgres;

