CREATE FUNCTION _temp_artist_from_demo() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
begin

for _row in 
		select melody_artist_temp.* from melody_artist inner join melody_artist_temp on melody_artist.melody_artist_id=melody_artist_temp.melody_artist_id
		where 
			COALESCE(melody_artist.last_name,'') <> COALESCE(melody_artist_temp.last_name,'') or
			COALESCE(melody_artist.first_name,'') <> COALESCE(melody_artist_temp.first_name,'') or
			COALESCE(melody_artist.middle_name,'') <> COALESCE(melody_artist_temp.middle_name,'') or
			COALESCE(melody_artist.group,'') <> COALESCE(melody_artist_temp.group,'') or
			COALESCE(melody_artist.description_short,'') <> COALESCE(melody_artist_temp.description_short,'') or
			COALESCE(melody_artist.description_detailed,'') <> COALESCE(melody_artist_temp.description_detailed,'') or 
			COALESCE(melody_artist.birthday,'1801-01-01') <>COALESCE(melody_artist_temp.birthday,'1801-01-01')
	loop

update melody_artist
	set 
		last_name=_row.last_name,  
		first_name=_row.first_name, 
		middle_name=_row.middle_name,
		"group"=_row.group, 
		description_short=_row.description_short,
		description_detailed=_row.description_detailed,
		birthday=_row.birthday
	where melody_artist_id=_row.melody_artist_id;
	
end loop;


end;
$$;

ALTER FUNCTION _temp_artist_from_demo() OWNER TO postgres;

