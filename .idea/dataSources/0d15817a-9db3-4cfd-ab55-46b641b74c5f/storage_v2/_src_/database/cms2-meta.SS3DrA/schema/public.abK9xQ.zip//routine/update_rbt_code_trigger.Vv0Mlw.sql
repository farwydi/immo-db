CREATE FUNCTION update_rbt_code_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        NEW.modification_date := now();
        RETURN NEW;
    END;
$$;

ALTER FUNCTION update_rbt_code_trigger() OWNER TO postgres;

