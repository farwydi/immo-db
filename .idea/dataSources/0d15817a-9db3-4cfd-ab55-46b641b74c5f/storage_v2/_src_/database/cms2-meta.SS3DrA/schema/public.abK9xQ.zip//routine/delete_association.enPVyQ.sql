CREATE FUNCTION delete_association(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM association WHERE association_id = id;
END;
$$;

ALTER FUNCTION delete_association(INTEGER) OWNER TO postgres;

