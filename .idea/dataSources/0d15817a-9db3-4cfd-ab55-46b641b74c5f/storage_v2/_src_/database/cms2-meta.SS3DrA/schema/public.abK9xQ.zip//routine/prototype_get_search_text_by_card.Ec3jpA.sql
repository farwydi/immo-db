CREATE FUNCTION prototype_get_search_text_by_card(_schema_meta text, _schema_proto text, _card_id uuid) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_search_text text;
_s text;
begin

	_sql_text = '
		select 
			name
		from 
			' || _schema_meta || '.melody_card as mc
		where
			mc.melody_card_id = ''' || _card_id || '''
	';
	
	EXECUTE _sql_text into _search_text;
	
	_sql_text = '
		select
			coalesce(ma.first_name,'''') || chr(32) || coalesce(ma.last_name,'''') || chr(32) || coalesce(ma.group,'''') :: text
		from
			' || _schema_meta || '.melody_artist as ma
		inner join
			' || _schema_meta || '.melody_card_artist as mca
		on
			ma.melody_artist_id = mca.artist_id
			and
			mca.card_id = ''' || _card_id || '''
	';
	
	FOR _s IN EXECUTE _sql_text LOOP
		_search_text = _search_text || chr(32) || _s;
	END LOOP;
	
	return _search_text;
	
/*	_sql_text = '
		update 
			'|| _schema_proto ||'.content as c
		set 
			search_text = ''' || replace(_search_text,'''','''''') || ' '' || c.content_code
		where
			card_id = ''' || _card_id || '''
	';
	
	EXECUTE _sql_text;
*/
end;
$$;

ALTER FUNCTION prototype_get_search_text_by_card(TEXT, TEXT, UUID) OWNER TO postgres;

