CREATE FUNCTION update_release(id uuid, _title character varying, _body text, _display_start_date timestamp without time zone, _expiration_date timestamp without time zone, _date timestamp without time zone, _albums uuid[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_news_type_id int;
	albumId uuid;
BEGIN
	_news_type_id := 2;	
	UPDATE news_type SET "name" = 'Релизы', display_name = 'Релизы' WHERE news_type_id = _news_type_id;
	IF NOT FOUND THEN
	INSERT INTO news_type (news_type_id, "name", display_name) VALUES (_news_type_id, 'Релизы', 'Релизы');
	END IF;

	UPDATE news SET 
		news_type_id = _news_type_id,
		title = _title,
		body = _body,
		display_start_date = _display_start_date,
		expiration_date = _expiration_date,
		start_date = _date,
		end_date = _date
	WHERE
		news_id = id;
	IF NOT FOUND THEN
	INSERT INTO news
	(
		news_id,
		news_type_id,
		title,
		body,
		display_start_date,
		expiration_date,
		start_date,
		end_date	
	)
	VALUES
	(
		id,
		_news_type_id,
		_title,
		_body,
		_display_start_date,
		_expiration_date,
		_date,
		_date	
	);
	END IF;

	DELETE FROM news_album WHERE news_id = id;
	
	FOR i IN COALESCE(array_lower(albums,1),0) .. COALESCE(array_upper(albums,1),-1) LOOP
	albumId:=albums[i];
	INSERT INTO news_album (news_id, album_id) VALUES (id, albumId);

	END LOOP;
	
END;
$$;

ALTER FUNCTION update_release(UUID, VARCHAR, TEXT, TIMESTAMP, TIMESTAMP, TIMESTAMP, UUID[]) OWNER TO postgres;

