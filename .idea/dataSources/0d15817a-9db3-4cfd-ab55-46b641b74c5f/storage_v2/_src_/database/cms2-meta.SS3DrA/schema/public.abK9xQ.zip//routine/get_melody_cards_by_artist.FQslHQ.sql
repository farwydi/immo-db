CREATE FUNCTION get_melody_cards_by_artist(_artist_id uuid, _section_id integer, usesubsections boolean, _schema_meta text, _schema_proto text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_row_res record;
_where text;
begin

if usesubsections THEN
	_where = '
		c.section_id in
			(select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')
		or c.section_id in
			(select section_id from '|| _schema_proto ||'.section where parent_id 
			 in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||'))
		or c.section_id in
			(select section_id from '|| _schema_proto ||'.section where parent_id 
			 in (select section_id from '|| _schema_proto ||'.section where parent_id 
			  in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id || ')))
	'; 	
ELSE
	_where = 'c.section_id = ' || _section_id;
END IF;

_sql_text = '
	select
		mc.melody_card_id,
		mc.name::text,
		mc.rating,
		mca.album_id,
		mca.number_in_album::integer,
		ma.name::text
	from
		'|| _schema_meta ||'.melody_card as mc
	left join
		'|| _schema_meta ||'.melody_card_album as mca
	on
		mca.card_id = mc.melody_card_id
	left join 
		'|| _schema_meta ||'.melody_album as ma
	on
		ma.melody_album_id = mca.album_id		
	where
		mc.melody_card_id
		in
		(
			select
				card_id
			from
				'|| _schema_meta ||'.melody_card_artist as mcart
			where
				mcart.artist_id = \'' || _artist_id || '\'
		)
	and
		mc.melody_card_id
		in
		(
			select
				c.card_id
			from
				'|| _schema_proto ||'.content as c
			where	' || _where ||'
			group by c.card_id
		)
		';

FOR _row_res IN EXECUTE _sql_text LOOP
	RETURN NEXT _row_res;
END LOOP;


end;
$$;

ALTER FUNCTION get_melody_cards_by_artist(UUID, INTEGER, BOOLEAN, TEXT, TEXT) OWNER TO postgres;

