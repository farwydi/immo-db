CREATE FUNCTION to_slug(arg character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
    RETURN to_ascii(convert_to(translit_underscore(clear_special_chars(trim(arg))), 'latin1'), 'latin1'); 
END
$$;

ALTER FUNCTION to_slug(VARCHAR) OWNER TO postgres;

