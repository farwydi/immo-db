CREATE FUNCTION video_file_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('video_file', OLD.video_file_id, 'D', 'video_file_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.video_file_id =  OLD.video_file_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('video_file', NEW.video_file_id, 'U', 'video_file_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('video_file', NEW.video_file_id, 'I', 'video_file_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('video_file', OLD.video_file_id, 'D', 'video_file_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('video_file', NEW.video_file_id, 'I', 'video_file_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION video_file_change_log() OWNER TO postgres;

