CREATE FUNCTION melody_album_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_album', OLD.melody_album_id, 'D', 'melody_album_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.melody_album_id =  OLD.melody_album_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_album', NEW.melody_album_id, 'U', 'melody_album_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_album', NEW.melody_album_id, 'I', 'melody_album_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_album', OLD.melody_album_id, 'D', 'melody_album_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_album', NEW.melody_album_id, 'I', 'melody_album_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION melody_album_change_log() OWNER TO postgres;

