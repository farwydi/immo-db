CREATE FUNCTION update_melody_genre_parent(id integer, parent_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE melody_genre SET parent_genre_id = parent_id WHERE melody_genre_id = id;
END;
$$;

ALTER FUNCTION update_melody_genre_parent(INTEGER, INTEGER) OWNER TO postgres;

