CREATE FUNCTION update_melody_album(id uuid, artist_id uuid, _name character varying, des text, releaseddate timestamp without time zone, rightholder character varying, cost real, _copyright character varying, _is_collection boolean) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
    real_id uuid;
    real_artist_id uuid;
BEGIN
real_id=(select(get_main_from_recycle(id)));
real_artist_id=(select(get_main_from_recycle(artist_id)));

	UPDATE melody_album SET 
		primary_artist_id = real_artist_id, 
		name = _name,
		description = des,
		released = releasedDate,
		rightholder_id = rightholder,
		minimal_cost = cost,
		copyright = _copyright, 
		is_collection = _is_collection
	WHERE
		melody_album_id = real_id;
	IF NOT FOUND THEN
		INSERT INTO melody_album (
			melody_album_id, 
			primary_artist_id, 
			name, 
			description,
			released,
			rightholder_id, 
			minimal_cost,
			copyright,
			is_collection
		)
		VALUES
		(
			real_id,
			real_artist_id,
			_name,
			des,
			releasedDate,
			rightholder,
			cost,
			_copyright,
			_is_collection
		);
	END IF;
END;
$$;

ALTER FUNCTION update_melody_album(UUID, UUID, VARCHAR, TEXT, TIMESTAMP, VARCHAR, REAL, VARCHAR, BOOLEAN) OWNER TO postgres;

