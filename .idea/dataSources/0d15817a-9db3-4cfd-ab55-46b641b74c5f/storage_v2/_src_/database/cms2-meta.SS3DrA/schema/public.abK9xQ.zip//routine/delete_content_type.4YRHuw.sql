CREATE FUNCTION delete_content_type(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM content_type WHERE content_type_id = id;
END;
$$;

ALTER FUNCTION delete_content_type(INTEGER) OWNER TO postgres;

