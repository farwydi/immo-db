CREATE FUNCTION update_file_content_code_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

		IF (TG_OP = 'DELETE') THEN

				update melody_file set modification_date=now() where melody_file_id=OLD.file_id;
				update video_file set modification_date=now() where video_file_id=OLD.file_id;

		ELSE
				update melody_file set modification_date=now() where melody_file_id=NEW.file_id;
				update video_file set modification_date=now() where video_file_id=NEW.file_id;

		END IF;


		RETURN null;
END;
$$;

ALTER FUNCTION update_file_content_code_trigger() OWNER TO postgres;

