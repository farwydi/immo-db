CREATE FUNCTION _temp_art() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
_row record;
_search_text text;
begin

for _row in
select ma.* from melody_artist ma inner join storefront.melody_artist sma on ma.melody_artist_id=sma.melody_artist_id
where
COALESCE(ma.last_name,'') <> COALESCE(sma.last_name,'') or
COALESCE(ma.first_name,'') <> COALESCE(sma.first_name,'') or
COALESCE(ma.middle_name,'') <> COALESCE(sma.middle_name,'') or
COALESCE(ma.group,'') <> COALESCE(sma.group,'') or
COALESCE(ma.description_short,'') <> COALESCE(sma.description_short,'') or
COALESCE(ma.birthday,'1801-01-01') <>COALESCE(sma.birthday,'1801-01-01') or
(COALESCE(ma."group",'') || ' ' || COALESCE(ma.last_name,'') || ' ' || COALESCE(ma.first_name,'') || ' '|| COALESCE(ma.tag,'')) <> COALESCE(sma.search_text,'')
loop

update storefront.melody_artist
set
last_name=_row.last_name,
first_name=_row.first_name,
middle_name=_row.middle_name,
"group"=_row.group,
description_short=_row.description_short,
birthday=_row.birthday
where melody_artist_id=_row.melody_artist_id;

select COALESCE("group",'') || ' ' || COALESCE(last_name,'') || ' ' || COALESCE(first_name,'') || ' '|| COALESCE(tag,'') into _search_text
from melody_artist
where melody_artist_id=_row.melody_artist_id;

update storefront.melody_artist
set search_text=_search_text
where melody_artist_id=_row.melody_artist_id;

update storefront.melody_artist
set first_letter_first_name=CASE WHEN "group" is null THEN upper(substring(first_name,1,1)) ELSE upper(substring("group",1,1)) END,
first_letter_last_name=CASE WHEN "group" is null THEN upper(substring(last_name,1,1)) ELSE upper(substring("group",1,1)) END
where melody_artist_id=_row.melody_artist_id;
end loop;



end;
$$;

ALTER FUNCTION _temp_art() OWNER TO postgres;

