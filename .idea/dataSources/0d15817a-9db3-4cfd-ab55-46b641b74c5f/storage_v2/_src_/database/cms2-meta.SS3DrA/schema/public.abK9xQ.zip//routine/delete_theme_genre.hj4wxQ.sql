CREATE FUNCTION delete_theme_genre(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM theme_genre WHERE theme_genre_id = id;
END;
$$;

ALTER FUNCTION delete_theme_genre(INTEGER) OWNER TO postgres;

