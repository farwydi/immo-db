CREATE FUNCTION prototype_update_news(_schema text) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_row RECORD;
BEGIN
	FOR _row in EXECUTE 'SELECT n.news_id FROM news n
					LEFT JOIN '|| _schema || '.news on n.news_id=news.news_id 
				WHERE news.news_id is null'
			LOOP
		EXECUTE 'INSERT INTO '|| _schema || '.news (news_id) VALUES ('''|| _row.news_id ||''')';
	END LOOP;

END;
$$;

ALTER FUNCTION prototype_update_news(TEXT) OWNER TO postgres;

