CREATE FUNCTION delete_melody_author_lyrics(author_id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM melody_composer WHERE melody_composer_id = author_id;
END;
$$;

ALTER FUNCTION delete_melody_author_lyrics(UUID) OWNER TO postgres;

