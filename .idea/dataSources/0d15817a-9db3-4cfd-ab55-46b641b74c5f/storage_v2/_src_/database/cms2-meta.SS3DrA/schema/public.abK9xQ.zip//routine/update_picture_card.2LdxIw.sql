CREATE FUNCTION update_picture_card(_picture_card_id uuid, _name character varying, _description text, _is_erotica boolean, _is_free boolean, _minimal_cost double precision, genres integer[], categories integer[], associations integer[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	genreId integer;
	categoryId integer;
	associationId integer;
BEGIN
	UPDATE picture_card SET
		name = _name,
		description = _description,
		is_erotica = _is_erotica,
		is_free = _is_free,
		minimal_cost = _minimal_cost,
		modification_date = NOW()
	WHERE
		picture_card_id = _picture_card_id;
	IF NOT FOUND THEN
		INSERT INTO picture_card 
		(
			picture_card_id,
			name,
			description,
			is_erotica,
			is_free,
			minimal_cost,		
			creation_date
		)
		VALUES
		(
			_picture_card_id,
			_name,
			_description,
			_is_erotica,
			_is_free,
			_minimal_cost,
			NOW()
		);
	END IF;

	DELETE FROM picture_card_genre WHERE card_id = _picture_card_id;
	FOR i IN COALESCE(array_lower(genres,1),0) .. COALESCE(array_upper(genres,1),-1) LOOP
		genreId := genres[i];
		INSERT INTO picture_card_genre (card_id, genre_id) VALUES (_picture_card_id, genreId);
	END LOOP;

	DELETE FROM card_content_category WHERE card_id = _picture_card_id;
	FOR i IN COALESCE(array_lower(categories,1),0) .. COALESCE(array_upper(categories,1),-1) LOOP
		categoryId := categories[i];
		INSERT INTO card_content_category (card_id, category_id) VALUES (_picture_card_id, categoryId);
	END LOOP;

	--association
	DELETE FROM card_association WHERE card_id = _picture_card_id;
	FOR i IN COALESCE(array_lower(associations,1),0) .. COALESCE(array_upper(associations,1),-1) LOOP
		associationId := associations[i];
		INSERT INTO card_association (card_id, association_id) VALUES (_picture_card_id, associationId);
	END LOOP;
	
END;
$$;

ALTER FUNCTION update_picture_card(UUID, VARCHAR, TEXT, BOOLEAN, BOOLEAN, DOUBLE PRECISION, INTEGER[], INTEGER[], INTEGER[]) OWNER TO postgres;

