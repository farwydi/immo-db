CREATE FUNCTION delete_melody_album(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
                  DELETE FROM availability WHERE source_id = id;
				                  DELETE FROM melody_album WHERE melody_album_id = id;
								  END;

$$;

ALTER FUNCTION delete_melody_album(UUID) OWNER TO postgres;

