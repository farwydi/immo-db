CREATE FUNCTION update_melody_file(_melody_file_id uuid, _content_type_id integer, _fat_name character varying, _rightholder_name character varying, _duration character varying, _format character varying, _coding character varying, _is_mono boolean, _sampling_rate integer, _bit_rate integer, _rightholder_id character varying, _card_id uuid, _codeid integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
real_card_id uuid;
real_file_id uuid;
BEGIN
real_card_id=(SELECT (get_main_from_recycle(_card_id)));
real_file_id=(SELECT (get_main_from_recycle(_melody_file_id)));
	UPDATE melody_file SET		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		rightholder_name = _rightholder_name,
		duration = _duration,
		format = _format,
		coding = _coding,
		is_mono = _is_mono,
		sampling_rate = _sampling_rate,
		bit_rate = _bit_rate,
		rightholder_id = _rightholder_id
	WHERE
		melody_file_id = real_file_id;
	IF NOT FOUND THEN
	INSERT INTO melody_file
	(
		melody_file_id,
		content_type_id,
		fat_name,
		rightholder_name,
		duration,
		format,
		coding,
		is_mono,
		sampling_rate,
		bit_rate,
		rightholder_id
	)
	VALUES
	(
		real_file_id,
		_content_type_id,
		_fat_name,
		_rightholder_name,
		_duration,
		_format,
		_coding,
		_is_mono,
		_sampling_rate,
		_bit_rate,
		_rightholder_id
	);
	END IF;


	DELETE FROM card_file WHERE file_id = real_file_id;
	INSERT INTO card_file (card_id, file_id) VALUES (real_card_id, real_file_id);

	DELETE FROM file_content_code WHERE file_id = real_file_id;
	INSERT INTO file_content_code (file_id, content_code_id, content_type_id, fat_name)
		SELECT real_file_id, content_code_id, _content_type_id, _fat_name FROM content_code WHERE cms_content_code_lookup_id = _codeid;	

END;
$$;

ALTER FUNCTION update_melody_file(UUID, INTEGER, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, BOOLEAN, INTEGER, INTEGER, VARCHAR, UUID, INTEGER) OWNER TO postgres;

