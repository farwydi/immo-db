CREATE FUNCTION swap_all(mode character varying) RETURNS boolean
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
DECLARE
   _c int;
   _result boolean;
   _old_postfix character varying;
   _current_old_postfix character varying;
BEGIN

_old_postfix := 'none';

	IF (mode = 'release')
	THEN								
		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'agreement2content_new';
		if (_c = 0) THEN return false; END IF;
		SELECT INTO _c count(*) from agreement2content_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'agreement_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from agreement_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'region_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from region_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'contragent_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from contragent_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'agreement2region_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from agreement2region_new;		
		if (_c = 0) THEN return false; END IF;

		SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = 'tariff2agreement_new';
		if (_c = 0) THEN return false; END IF;		
		SELECT INTO _c count(*) from tariff2agreement_new;		
		if (_c = 0) THEN return false; END IF;
	END IF;

	if (swap_sync_by_table_replic('agreement2content'::text) = false) then return false; end if;
	if (swap_sync_by_table_replic('agreement'::text) = false) then return false; end if;
	if (swap_sync_by_table_replic('region'::text) = false) then return false; end if;
	if (swap_sync_by_table_replic('contragent'::text) = false) then return false; end if;
	if (swap_sync_by_table_replic('agreement2region'::text) = false) then return false; end if;
	if (swap_sync_by_table_replic('tariff2agreement'::text) = false) then return false; end if;
	
	ALTER TABLE agreement
		ADD CONSTRAINT pk_agreement PRIMARY KEY(agreement);
	CREATE INDEX ix_agreement_contragent
	  ON agreement
	  USING btree
	  (contragent);
	  
	ALTER TABLE agreement2content
	  ADD CONSTRAINT pk_agreement2content PRIMARY KEY(agreement2content);

	CREATE INDEX ix_agreement2content_agreement
	  ON agreement2content
	  USING btree
	  (agreement);

	CREATE INDEX ix_agreement2content_content
	  ON agreement2content
	  USING btree
	  (content);

	ALTER TABLE agreement2region
	  ADD CONSTRAINT pk_agreement2region PRIMARY KEY(agreement2region);

	CREATE INDEX ix_agreement2region_agreement
	  ON agreement2region
	  USING btree
	  (agreement);

	CREATE INDEX ix_agreement2region_region
	  ON agreement2region
	  USING btree
	  (region);
	  
	ALTER TABLE contragent
	  ADD CONSTRAINT pk_contragent PRIMARY KEY(contragent);		
	  
	ALTER TABLE tariff2agreement
	  ADD CONSTRAINT pk_tariff2agreement PRIMARY KEY(content_sale2point);		  
		
	return true;
END;
$$;

ALTER FUNCTION swap_all(VARCHAR) OWNER TO postgres;

