CREATE FUNCTION add_new_content(_card_id uuid, _section_id integer, _schema_proto text, _new_content_section_type_id integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
_new_content_section_id integer;
_section_top_id uuid;
_sql_text text;
_count integer;
begin
	_sql_text = '
		select
			section_id
		from
			'|| _schema_proto ||'.section
		where
			section_type_id = ' || _new_content_section_type_id ||'
		and
			parent_id = ' || _section_id ||'
	';
	
	EXECUTE _sql_text into _new_content_section_id;
	
	IF _new_content_section_id is null THEN
		
		_sql_text = '
			select
				max(section_id)
			from
				'|| _schema_proto ||'.section
		';
		EXECUTE _sql_text into _new_content_section_id;
		
		_new_content_section_id = _new_content_section_id + 1;
		
		_sql_text = '
			INSERT INTO 
				'|| _schema_proto ||'.section
				(
					section_id, 
					section_type_id, 
					parent_id, 
					"name", 
					is_navigation_node
				)
			VALUES 
				(
					' || _new_content_section_id ||',
					' || _new_content_section_type_id ||',
					' || _section_id ||',
					''Новинки'',
					false
				)
		';
		EXECUTE _sql_text;
		return _new_content_section_id;
	ELSE

		_sql_text = '
			select
				section_top_id
			from
				'|| _schema_proto ||'.section_top
			where
				section_id = ' || _new_content_section_id ||'
		';

		EXECUTE _sql_text into _section_top_id;

		IF _section_top_id is null THEN
			--Ошибка ловится в asp.net, там создается новый guid, и создается section_top
			return _new_content_section_id;
			--RAISE EXCEPTION '|section_top_not_exists|%',_new_content_section_id;
		ELSE

			_sql_text = '
				select 
					count(*)
				from
					'|| _schema_proto ||'.section_top_content
				where
					section_top_id = ''' || _section_top_id || '''
				and
					card_id = ''' || _card_id || '''
			';

			EXECUTE _sql_text into _count;
			IF _count=0 THEN		
				_sql_text = '
					INSERT INTO 
						'|| _schema_proto ||'.section_top_content
						(
							section_top_id, 
							card_id, 
							rating, 
							rating_old
						)
					VALUES 
					(
						''' || _section_top_id || ''', 
						''' || _card_id || ''', 
						1, 
						1
					);
				';
				EXECUTE _sql_text;
			END IF;
			return -1;
		
		END IF;
	END IF;
	


end;
$$;

ALTER FUNCTION add_new_content(UUID, INTEGER, TEXT, INTEGER) OWNER TO postgres;

