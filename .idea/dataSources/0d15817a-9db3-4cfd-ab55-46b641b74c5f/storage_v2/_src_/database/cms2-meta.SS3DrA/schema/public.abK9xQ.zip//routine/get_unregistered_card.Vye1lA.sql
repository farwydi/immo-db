CREATE FUNCTION get_unregistered_card(_table_name text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare 
    _row record;
begin

FOR _row in EXECUTE '
            select distinct '|| _table_name ||'.'|| _table_name ||'_id
             from '|| _table_name ||' 
             left join card_file cf on cf.card_id = '|| _table_name ||'.'|| _table_name ||'_id
             left join file_content_code fcc on fcc.file_id = cf.file_id 
             where fcc.content_code_id is null '
        LOOP

return next _row;
        
END LOOP;

end;
$$;

ALTER FUNCTION get_unregistered_card(TEXT) OWNER TO postgres;

