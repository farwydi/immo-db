CREATE FUNCTION get_content_owner_share_sum(_content_id integer, _region_id integer, _is_allied_rights boolean, _date timestamp without time zone) RETURNS numeric
	LANGUAGE sql
AS
$$
select sum(content_owner_share) from agreement2content
  	inner join agreement on agreement.agreement=agreement2content.agreement
		inner join agreement2region on agreement2region.agreement=agreement.agreement
		where 
		content=$1 
		and agreement2region.region=$2 
		and is_allied_rights=$3 and start_date<=$4 and end_date>=$4
$$;

ALTER FUNCTION get_content_owner_share_sum(INTEGER, INTEGER, BOOLEAN, TIMESTAMP) OWNER TO postgres;

