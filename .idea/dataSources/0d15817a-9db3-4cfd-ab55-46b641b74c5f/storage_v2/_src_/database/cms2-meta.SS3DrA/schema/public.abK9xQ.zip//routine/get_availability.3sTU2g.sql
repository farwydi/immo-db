CREATE FUNCTION get_availability(_storefront_id integer, _sub_query text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
    _territories RECORD;
    _default boolean;
    _query text;
    _joins text;
    _auto_publish text;
    _has_rights text;
    _r record;
    _list_type availability.agreement_list_type;
    _last_update_date timestamp;
    begin
        _default := true;
        select list_type from availability.storefront_agreement_list_type where storefront_id = _storefront_id into _list_type;
        select start_date from availability.update_log order by update_log_id desc limit 1 into _last_update_date;
        if _list_type = 'white'::availability.agreement_list_type then
            _default := false;
        end if;
        _query := 'select cc.content_code_id, ';
        _auto_publish := 'coalesce(scc.is_auto_publish, ' || _default::text || ') and ecc.content_code_id is null and nc.content_code_id is null';
        _has_rights := 'coalesce(scc.has_rights, ' || _default::text || ') and ecc.content_code_id is null and nc.content_code_id is null';
        _joins := 'left join availability.storefront_content_code scc on scc.content_code_id = cc.content_code_id and scc.storefront_id = ' || _storefront_id::text;
        _joins := _joins || ' left join availability.empty_content_code ecc on ecc.content_code_id = cc.content_code_id';
        _joins := _joins || ' left join content_code nc on nc.creation_date > ''' || _last_update_date::text || ''' and nc.content_code_id = cc.content_code_id';
        for _r in select region_id from availability.storefront_region where storefront_id = _storefront_id
        loop
            _joins := _joins || ' left join availability.region_content_code rcc' || _r.region_id::text || ' on rcc' || _r.region_id::text || '.content_code_id = cc.content_code_id and rcc' || _r.region_id::text || '.region_id = ' || _r.region_id::text;
            _auto_publish :=  _auto_publish || ' and coalesce(rcc' || _r.region_id::text || '.is_auto_publish, true)';
            _has_rights := _has_rights || ' and coalesce(rcc'  || _r.region_id::text || '.has_rights, true)';
        end loop;
        _query := _query || _auto_publish || ' as auto_publish, ' || _has_rights || ' as has_rights from content_code cc ' || _joins || ' where cc.content_code_id in (' || _sub_query || ')';
        raise notice '%', _query;
        for _r in EXECUTE _query
        loop
            return next _r;
        end loop;

        end;
$$;

ALTER FUNCTION get_availability(INTEGER, TEXT) OWNER TO postgres;

