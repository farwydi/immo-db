CREATE FUNCTION update_album_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

IF (TG_OP = 'UPDATE') THEN
    IF NEW."billing modification_date" <> OLD."billing modification_date" THEN
                       --RAISE NOTICE 'test_billing_modification_date';
                       --RAISE NOTICE '%', NEW.billing_modification_date;
                       --RAISE NOTICE '%', OLD.billing_modification_date;
                        RETURN NEW;
                ELSIF NEW.modification_date <> OLD.modification_date THEN
                        --RAISE NOTICE 'test_modification_date';
                        RETURN NEW;
                END IF;
        END IF;
        NEW.modification_date := now();
        RETURN NEW;
END;
$$;

ALTER FUNCTION update_album_trigger() OWNER TO postgres;

