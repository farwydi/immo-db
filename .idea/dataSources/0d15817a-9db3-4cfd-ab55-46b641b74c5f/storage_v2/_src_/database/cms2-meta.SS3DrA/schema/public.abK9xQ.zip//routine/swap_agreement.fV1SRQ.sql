CREATE FUNCTION swap_agreement() RETURNS void
	LANGUAGE sql
AS
$$
	ALTER TABLE agreement RENAME TO agreement_old;

ALTER TABLE agreement_temp RENAME TO agreement;

DROP TABLE agreement_old CASCADE;

ALTER TABLE agreement
  ADD CONSTRAINT pk_agreement PRIMARY KEY(agreement);

CREATE INDEX ix_agreement_contragent
  ON agreement
  USING btree
  (contragent);

	$$;

ALTER FUNCTION swap_agreement() OWNER TO postgres;

