CREATE FUNCTION prototype_update_access_point(_schema text, _operator_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE 
	_row record;
BEGIN

	FOR _row IN EXECUTE 
		'SELECT apn.apn_id as access_point_id 
		 from apn 
		 LEFT JOIN '|| _schema || '.access_point ap ON apn.apn_id = ap.access_point_id
		 WHERE apn.operator_id = ' || _operator_id || ' and ap.access_point_id is null'
	LOOP
		EXECUTE 'INSERT INTO '|| _schema || '.access_point (access_point_id) VALUES ('|| _row.access_point_id ||')';
	END LOOP;
	
END;
$$;

ALTER FUNCTION prototype_update_access_point(TEXT, INTEGER) OWNER TO postgres;

