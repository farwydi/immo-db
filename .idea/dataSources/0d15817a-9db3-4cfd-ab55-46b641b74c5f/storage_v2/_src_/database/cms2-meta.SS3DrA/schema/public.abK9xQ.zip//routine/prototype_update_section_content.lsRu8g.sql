CREATE FUNCTION prototype_update_section_content(_schema text, _section_id integer, _region_id integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
DECLARE 
	_filter_id integer;
	_row record;
	_count integer;	
BEGIN

	EXECUTE 'select filter_id from ' || _schema || '.section where section_id=' || _section_id into _filter_id; 

	EXECUTE 'update ' || _schema || '.content set is_deleted=true where section_id=' || _section_id;

	FOR _row IN 
			select  content_code,card_id, user_format_id, (content_owner_share_sum>=public_owner_share_sum and  content_allied_share_sum>=public_allied_share_sum) as is_auto_publish
			from
			(select  *, content_owner_share_sum>=public_owner_share_sum, content_allied_share_sum>=public_allied_share_sum  from 
			(
			select *,   --100 as content_owner_share_sum, 100 as content_allied_share_sum
			COALESCE(get_content_owner_share_sum(content_billing_id,_region_id,false,now()::timestamp),0) as content_owner_share_sum, COALESCE(get_content_owner_share_sum(content_billing_id,_region_id,true,now()::timestamp),0) as content_allied_share_sum 
			from 
			(
			select distinct content_code,user_format.user_format_id, cards.card_id, content_billing_id,COALESCE(public_owner_share_sum,0) as public_owner_share_sum,COALESCE(public_allied_share_sum,0)  as public_allied_share_sum
			from card_file 
			inner join 
			(select * from get_card_by_filter(_filter_id) as (card_id uuid)) cards on cards.card_id=card_file.card_id
			inner join file_content_code on card_file.file_id=file_content_code.file_id
			inner join content_type on content_type.content_type_id=file_content_code.content_type_id
			inner join content_code on content_code.content_code_id=file_content_code.content_code_id
			inner join user_format on user_format.user_format_id=content_type.user_format_id 
			) temp_table )temp_table
			where content_owner_share_sum+content_allied_share_sum>0 
			) public_content
			inner join melody_card on melody_card.melody_card_id=public_content.card_id
		LOOP

		
		EXECUTE 'select count(*) from ' ||_schema || '.content where section_id='||_section_id || ' and content_code='''|| _row.content_code ||'''' into _count;

		IF _count=0 THEN
			EXECUTE 'INSERT INTO '|| _schema || '.content
					(content_code,card_id,melody_card_id,section_id,user_format_id,is_auto_publish)
					VALUES
					('''|| _row.content_code ||''','''|| _row.card_id||''','''||_row.card_id||''','||_section_id ||',' ||_row.user_format_id||','||_row.is_auto_publish ||')';
		ELSE
			EXECUTE  'update ' || _schema || '.content set is_deleted=false and is_auto_publish=' || _row.is_auto_publish
					|| ' where section_id='||_section_id || ' and content_code='''|| _row.content_code ||'''';

		END IF;

	END LOOP;

	EXECUTE 'delete from ' || _schema || '.content where is_deleted=true and section_id=' || _section_id;


RETURN 1;


END;
$$;

ALTER FUNCTION prototype_update_section_content(TEXT, INTEGER, INTEGER) OWNER TO postgres;

