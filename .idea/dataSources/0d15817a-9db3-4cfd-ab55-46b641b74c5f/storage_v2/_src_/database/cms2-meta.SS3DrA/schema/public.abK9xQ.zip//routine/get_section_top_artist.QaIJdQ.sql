CREATE FUNCTION get_section_top_artist(_section_id integer, _schema_meta text, _schema_proto text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_row_res record;
begin
_sql_text = '
	select 	
		sta.section_top_artist_id,
		sta.section_top_id,
		sta.artist_id,
		sta.rating,
		coalesce(ma.last_name || chr(32) ||  ma.first_name, ma.group, ma.last_name, ma.first_name) as Name
	from 
		'|| _schema_proto ||'.section_top_artist as sta
	left join
		'|| _schema_meta ||'.melody_artist as ma
	on
		sta.artist_id = ma.melody_artist_id
	where
		section_top_id = 
		(
			select 
				section_top_id 
			from 
				'|| _schema_proto ||'.section_top 
			where 
				section_id = '|| _section_id ||'
		)
';

FOR _row_res IN EXECUTE _sql_text LOOP
	RETURN NEXT _row_res;
END LOOP;	

end;
$$;

ALTER FUNCTION get_section_top_artist(INTEGER, TEXT, TEXT) OWNER TO postgres;

