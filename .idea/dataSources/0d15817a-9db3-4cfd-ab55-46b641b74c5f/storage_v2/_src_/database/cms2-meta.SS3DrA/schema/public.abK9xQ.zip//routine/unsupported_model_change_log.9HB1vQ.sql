CREATE FUNCTION unsupported_model_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('unsupported_model', OLD.phone_model_id, 'D', 'phone_model_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.phone_model_id =  OLD.phone_model_id) THEN
																																					INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('unsupported_model', NEW.phone_model_id, 'U', 'phone_model_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('unsupported_model', NEW.phone_model_id, 'I', 'phone_model_id');
																																																	INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('unsupported_model', OLD.phone_model_id, 'D', 'phone_model_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('unsupported_model', NEW.phone_model_id, 'I', 'phone_model_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION unsupported_model_change_log() OWNER TO postgres;

