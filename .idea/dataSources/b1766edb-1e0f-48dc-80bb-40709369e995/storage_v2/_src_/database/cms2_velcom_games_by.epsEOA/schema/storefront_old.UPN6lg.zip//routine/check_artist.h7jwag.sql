CREATE FUNCTION check_artist(_schema text, _artist_id uuid) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare 
	_res boolean;begin
	EXECUTE 'select exists(select * from '|| _schema ||'.melody_card_artist where artist_id='''||_artist_id||''')' INTO _res;RETURN _res;end;
$$;

ALTER FUNCTION check_artist(TEXT, UUID) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION check_artist(_schema TEXT, _artist_id UUID) TO inform;

