CREATE FUNCTION update_children_column(_schema text, _section_id integer) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
	_row record;_res text;_res_temp text;begin
	_res=_section_id;FOR _row IN EXECUTE 'SELECT * from ' || _schema || '.section where parent_id=' || _section_id LOOP
	EXECUTE 'select * from ' || _schema || '.update_children_column('''|| _schema ||''',' || _row.section_id || ')' into _res_temp;_res=_res || ',' ||_res_temp;END LOOP;return _res;end;
$$;

ALTER FUNCTION update_children_column(TEXT, INTEGER) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION update_children_column(_schema TEXT, _section_id INTEGER) TO inform;

