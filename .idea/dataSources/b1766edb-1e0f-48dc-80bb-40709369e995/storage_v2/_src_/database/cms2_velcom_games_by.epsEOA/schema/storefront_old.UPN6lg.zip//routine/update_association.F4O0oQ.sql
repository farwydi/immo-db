CREATE FUNCTION update_association(_schema text) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
	_row record;begin
	FOR _row IN EXECUTE 'select association_id, count(*) as cnt from ' || _schema || '.card_association group by association_id' LOOP

		IF _row.cnt>0 THEN
			EXECUTE 'update ' || _schema || '.association  set "count"='|| _row.cnt ||' where association_id=' || _row.association_id;END IF;END LOOP;EXECUTE 'delete from ' || _schema || '.association where "count"=0';return 1;end;
$$;

ALTER FUNCTION update_association(TEXT) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION update_association(_schema TEXT) TO inform;

