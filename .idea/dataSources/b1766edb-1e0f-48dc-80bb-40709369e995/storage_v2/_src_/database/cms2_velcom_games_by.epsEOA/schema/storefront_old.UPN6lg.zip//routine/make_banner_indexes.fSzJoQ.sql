CREATE FUNCTION make_banner_indexes() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
BEGIN
  CREATE INDEX baner_relation_baner_idx ON banner_block_relation USING btree(banner_id);CREATE INDEX baner_relation_block_idx ON banner_block_relation USING btree(banner_block_id);CREATE INDEX banner_file_banner_idx ON banner_file USING btree(banner_id);ALTER TABLE banner_type ADD CONSTRAINT pk_banner_type PRIMARY KEY(banner_type_id);ALTER TABLE banner_resolution ADD CONSTRAINT pk_banner_resolution PRIMARY KEY(banner_resolution_id);ALTER TABLE banner_file ADD CONSTRAINT pk_banner_file PRIMARY KEY(banner_file_id);ALTER TABLE banner_block_relation ADD CONSTRAINT pk_banner_block_relation PRIMARY KEY(banner_block_id, banner_id);ALTER TABLE banner_block ADD CONSTRAINT pk_banner_block PRIMARY KEY(banner_block_id);ALTER TABLE banner ADD CONSTRAINT pk_banner PRIMARY KEY(banner_id);ALTER TABLE banner_resolution ADD CONSTRAINT banner_file_banner_resolution_fk FOREIGN KEY (banner_file_id)
  REFERENCES banner_file (banner_file_id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE;ALTER TABLE banner_file ADD CONSTRAINT banner_file_banner_fk FOREIGN KEY (banner_id)
  REFERENCES banner (banner_id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE;ALTER TABLE banner_block_relation ADD CONSTRAINT banner_block_relation_banner_block_fk FOREIGN KEY (banner_block_id)
  REFERENCES banner_block (banner_block_id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE;ALTER TABLE banner_block_relation ADD CONSTRAINT bsnner_block_relation_banner_fk FOREIGN KEY (banner_id)
  REFERENCES banner (banner_id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE;ALTER TABLE banner ADD CONSTRAINT banner_banner_type_fk FOREIGN KEY (banner_type_id)
  REFERENCES banner_type (banner_type_id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE;END;
$$;

ALTER FUNCTION make_banner_indexes() OWNER TO postgres;

GRANT EXECUTE ON FUNCTION make_banner_indexes() TO inform;

