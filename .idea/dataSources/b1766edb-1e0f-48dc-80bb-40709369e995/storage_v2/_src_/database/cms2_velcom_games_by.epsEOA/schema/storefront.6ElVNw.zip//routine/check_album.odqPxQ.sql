CREATE FUNCTION check_album(_schema text, _album_id uuid) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare 
	_res boolean;begin
	EXECUTE 'select exists(select * from '|| _schema ||'.melody_card_album where album_id='''||_album_id||''')' INTO _res;RETURN _res;end;
$$;

ALTER FUNCTION check_album(TEXT, UUID) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION check_album(_schema TEXT, _album_id UUID) TO inform;

