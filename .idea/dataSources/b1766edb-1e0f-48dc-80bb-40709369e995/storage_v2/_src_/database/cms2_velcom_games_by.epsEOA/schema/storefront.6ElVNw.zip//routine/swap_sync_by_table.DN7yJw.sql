CREATE FUNCTION swap_sync_by_table(table_name character varying, scheme character varying, mode character varying) RETURNS boolean
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
DECLARE
   _c int;_sql varchar;BEGIN
   IF (mode = 'release')
   THEN
       SELECT INTO _c count(*) FROM pg_tables where schemaname = scheme and tablename in (table_name || '_new', table_name);IF (_c = 2)
       THEN
           SELECT INTO _c count(*) FROM pg_tables where schemaname = scheme and tablename = table_name || '_old';IF (_c = 1)
           THEN
               execute 'DROP TABLE ' || table_name || '_old CASCADE';END IF;execute 'ALTER TABLE ' || table_name || ' RENAME TO ' || table_name || '_old';FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
					 FROM pg_constraint 
					 INNER JOIN pg_class ON conrelid=pg_class.oid 
					 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					 where nspname = scheme and relname = table_name || '_old' LOOP
			EXECUTE _sql;END LOOP;FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
					FROM pg_index
					JOIN pg_class ON indexrelid=pg_class.oid
					JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					JOIN pg_class c on indrelid = c.oid
					WHERE nspname = scheme and c.relname = table_name || '_old' LOOP
			EXECUTE _sql;END LOOP;execute 'ALTER TABLE ' || table_name || '_new RENAME TO ' || table_name;FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
					 FROM pg_constraint 
					 INNER JOIN pg_class ON conrelid=pg_class.oid 
					 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					 where nspname = scheme and relname = table_name || '_new' LOOP
			EXECUTE _sql;END LOOP;FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
					FROM pg_index
					JOIN pg_class ON indexrelid=pg_class.oid
					JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					JOIN pg_class c on indrelid = c.oid
					WHERE nspname = scheme and c.relname = table_name || '_new' LOOP
			EXECUTE _sql;END LOOP;RETURN true;END IF;ELSE
       IF (mode = 'revert') THEN
           SELECT INTO _c count(*) FROM pg_tables where schemaname = scheme and tablename in (table_name || '_old', table_name);IF (_c = 2)
           THEN
               SELECT INTO _c count(*) FROM pg_tables where schemaname = scheme and tablename = table_name || '_new';IF (_c = 1)
               THEN
                   execute 'DROP TABLE ' || table_name || '_new CASCADE';END IF;execute 'ALTER TABLE ' || table_name || ' RENAME TO ' || table_name || '_new';FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
							 FROM pg_constraint 
							 INNER JOIN pg_class ON conrelid=pg_class.oid 
							 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
							 where nspname = scheme and relname = table_name || '_new' LOOP
					EXECUTE _sql;END LOOP;FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
							FROM pg_index
							JOIN pg_class ON indexrelid=pg_class.oid
							JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
							JOIN pg_class c on indrelid = c.oid
							WHERE nspname = scheme and c.relname = table_name || '_new' LOOP
					EXECUTE _sql;END LOOP;execute 'ALTER TABLE ' || table_name || '_old RENAME TO ' || table_name;return true;RETURN false;END IF;END IF;END IF;RETURN false;END;
$$;

ALTER FUNCTION swap_sync_by_table(VARCHAR, VARCHAR, VARCHAR) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION swap_sync_by_table(TABLE_NAME CHARACTER VARYING, scheme CHARACTER VARYING, MODE CHARACTER VARYING) TO inform;

