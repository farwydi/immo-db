CREATE FUNCTION check_content(_schema text, _key text, _value text) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare 
	_res boolean;begin
	EXECUTE 'select exists(select * from '|| _schema || '.content where '||_key||'='''||_value ||''')' INTO _res;RETURN _res;end;
$$;

ALTER FUNCTION check_content(TEXT, TEXT, TEXT) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION check_content(_schema TEXT, _key TEXT, _value TEXT) TO inform;

