CREATE FUNCTION get_section_top_artist(_schema text, _section_top_id uuid, _inner_join text, _where text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_row_top record;_sql_text text;_row_res record;begin

EXECUTE 'select * from ' || _schema || '.section_top where section_top_id=''' || _section_top_id || '''' into _row_top;_sql_text:='
	SELECT 
		melody_artist_id,
		last_name,
		first_name,
		middle_name,
		"group",
	 '
	||_schema || '.get_preview_picture('''||_schema ||''','||_preview_type_id ||','|| _preview_watermark_id ||',t.melody_artist_id) as  fat_name,
	  rating,
	  rating_old
	
	FROM (
		SELECT
                        DISTINCT (melody_artist.melody_artist_id::uuid),
                        melody_artist.last_name::text,
                        melody_artist.first_name::text,
                        melody_artist.middle_name::text,
                        melody_artist."group"::text,
                        section_top_artist.rating::integer, 
                        section_top_artist.rating_old::integer
                    FROM
                        ' || _schema|| '.section_top_artist 
                        INNER JOIN
                            ' ||_schema|| '.melody_artist 
                        ON
                            (section_top_artist.artist_id = melody_artist.melody_artist_id)'
                        
                        || COALESCE(_inner_join,'') || ' ' ||
                        
			CASE WHEN _where is null THEN ' WHERE '
				    WHEN _where='' THEN ' WHERE '
				    ELSE _where || ' and '
			   END ||
                    
                    ' section_top_artist.section_top_id = '''|| _row_top.section_top_id || '''  

                    ORDER BY 
                        section_top_artist.rating DESC
                    LIMIT 
			' || _row_top.limit || ') as t ' ;FOR _row_res IN EXECUTE _sql_text LOOP
	RETURN NEXT _row_res;END LOOP;end;
$$;

ALTER FUNCTION get_section_top_artist(TEXT, UUID, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION get_section_top_artist(_schema TEXT, _section_top_id UUID, _inner_join TEXT, _where TEXT, _preview_type_id INTEGER, _preview_watermark_id INTEGER) TO inform;

