CREATE FUNCTION update_right(_schemas text, _login text) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE 
	_row RECORD;begin


FOR _row IN EXECUTE '
		select ''GRANT SELECT, UPDATE, INSERT, DELETE on ''||schemaname||''.''||tablename||'' to '||_login||';'' as t
		from pg_tables
		where schemaname in ('||_schemas||')
		order by schemaname, tablename '
		LOOP

	EXECUTE _row.t;END LOOP;FOR _row IN EXECUTE '
		select ''GRANT EXECUTE on function
		''||n.nspname||''."''||p.proname||''"(''||oidvectortypes(p.proargtypes)||'') to
		'||_login||';'' as t
		from pg_proc p, pg_namespace n
		where n.oid = p.pronamespace
		and n.nspname in ('||_schemas||')
		order by n.nspname, p.proname '
		loop
	execute _row.t;end loop;FOR _row IN EXECUTE '
		select ''revoke all on function
		''||n.nspname||''."''||p.proname||''"(''||oidvectortypes(p.proargtypes)||'') from
		public;'' as t
		from pg_proc p, pg_namespace n
		where n.oid = p.pronamespace
		and n.nspname in ('||_schemas||')
		order by n.nspname, p.proname '
		loop
	execute _row.t;end loop;FOR _row IN EXECUTE '
		select ''grant SELECT, UPDATE ON SEQUENCE ''||n.nspname||''.''||c.relname||'' to '||_login||';'' as t
		from pg_class c, pg_namespace n
		where n.oid = c.relnamespace
		and c.relkind IN (''S'')
		and n.nspname in ('||_schemas||')'
	loop
execute _row.t;end loop;end;
$$;

ALTER FUNCTION update_right(TEXT, TEXT) OWNER TO postgres;

GRANT EXECUTE ON FUNCTION update_right(_schemas TEXT, _login TEXT) TO inform;

