CREATE VIEW pg_stat_repl
			(pid, usesysid, usename, application_name, client_addr, client_hostname, client_port, backend_start,
			 backend_xmin, state, sent_lsn, write_lsn, flush_lsn, replay_lsn, write_lag, flush_lag, replay_lag,
			 sync_priority, sync_state, reply_time)
AS
SELECT pg_stat_repl.pid,
	   pg_stat_repl.usesysid,
	   pg_stat_repl.usename,
	   pg_stat_repl.application_name,
	   pg_stat_repl.client_addr,
	   pg_stat_repl.client_hostname,
	   pg_stat_repl.client_port,
	   pg_stat_repl.backend_start,
	   pg_stat_repl.backend_xmin,
	   pg_stat_repl.state,
	   pg_stat_repl.sent_lsn,
	   pg_stat_repl.write_lsn,
	   pg_stat_repl.flush_lsn,
	   pg_stat_repl.replay_lsn,
	   pg_stat_repl.write_lag,
	   pg_stat_repl.flush_lag,
	   pg_stat_repl.replay_lag,
	   pg_stat_repl.sync_priority,
	   pg_stat_repl.sync_state,
	   pg_stat_repl.reply_time
FROM pg_stat_repl() pg_stat_repl(pid, usesysid, usename, application_name, client_addr, client_hostname, client_port,
								 backend_start, backend_xmin, state, sent_lsn, write_lsn, flush_lsn, replay_lsn,
								 write_lag, flush_lag, replay_lag, sync_priority, sync_state, reply_time);

ALTER TABLE pg_stat_repl
	OWNER TO postgres;

