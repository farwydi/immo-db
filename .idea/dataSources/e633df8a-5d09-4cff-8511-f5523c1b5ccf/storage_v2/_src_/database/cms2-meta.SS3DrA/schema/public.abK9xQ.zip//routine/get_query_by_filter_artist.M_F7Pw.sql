CREATE FUNCTION get_query_by_filter_artist(_filter_id integer) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_where text;
	_parent record;
	_count int;
	_inner text;

begin
_where = '';
_inner = '';
select * into _parent from filter where filter_id= _filter_id;  
select count(*) into _count from filter_relation where parent_filter_id = _filter_id;
--RAISE NOTICE '%',_count;
if (_count != 0) then 
for _row in select * from filter join filter_relation on filter_relation.filter_id = filter.filter_id
where parent_filter_id = _filter_id loop
_inner = (select(get_query_by_filter_artist(_row.filter_id)));
		if (_inner <> '')
		THEN
		if (_where <> '') THEN
			if (_parent.is_union) THEN
				_where = _where || ' or ';
			ELSE
				_where = _where || ' and ';
			END IF;
		END IF;
		
		_where = _where || '(' || _inner || ')';
		END IF;
END LOOP;
else

for 
	_row 
in 
	select 
		"table", 
		"column", 
		filter_operation.value as operation, 
		filter_condition.value,
		is_union
	from 
		filter 
	inner join filter_condition on filter_condition.filter_id=filter.filter_id
	inner join filter_operation on filter_condition.filter_operation_id=filter_operation.filter_operation_id
	inner join filter_column on filter_condition.filter_column_id=filter_column.filter_column_id
	where filter.filter_id=_filter_id and filter_column.filter_column_id = 1
loop

		if (_where <> '') THEN
			if (_row.is_union) THEN
				_where = _where || ' or ';
			ELSE
				_where = _where || ' and ';
			END IF;
		ELSE
			_where=' ';
		END IF;
		_where = _where || _row.table || '.' || _row.column || _row.operation || _row.value;
end loop;
end if;
--RAISE NOTICE '%','"'||_where||'"';
--_where= coalesce(_where,'true');
return _where;
end;
$$;

ALTER FUNCTION get_query_by_filter_artist(INTEGER) OWNER TO postgres;

