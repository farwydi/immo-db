CREATE FUNCTION update_java_file(_java_file_id uuid, _content_type_id integer, _fat_name character varying, _rightholder_name character varying, _rightholder_id character varying, _card_id uuid, _jad_fat_name character varying, _jar_size integer, _codeid integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE java_file SET		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		rightholder_name = _rightholder_name,
		rightholder_id = _rightholder_id,
		jad_fat_name = _jad_fat_name,
		jar_size = _jar_size
	WHERE
		java_file_id = _java_file_id;
	IF NOT FOUND THEN
	INSERT INTO java_file
	(
		java_file_id,
		content_type_id,
		fat_name,
		rightholder_name,
		rightholder_id,
		jad_fat_name,
		jar_size
	)
	VALUES
	(
		_java_file_id,
		_content_type_id,
		_fat_name,
		_rightholder_name,
		_rightholder_id,
		_jad_fat_name,
		_jar_size
	);
	END IF;

	DELETE FROM card_file WHERE file_id = _java_file_id;
	INSERT INTO card_file (card_id, file_id) VALUES (_card_id, _java_file_id);
	
	DELETE FROM file_content_code WHERE file_id = _java_file_id;
	INSERT INTO file_content_code (file_id, content_code_id, content_type_id, fat_name)
		SELECT _java_file_id, content_code_id, _content_type_id, _fat_name FROM content_code WHERE cms_content_code_lookup_id = _codeid;	
	

END;
$$;

ALTER FUNCTION update_java_file(UUID, INTEGER, VARCHAR, VARCHAR, VARCHAR, UUID, VARCHAR, INTEGER, INTEGER) OWNER TO postgres;

