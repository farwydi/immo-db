CREATE FUNCTION swap_agreement2content() RETURNS void
	LANGUAGE sql
AS
$$
	ALTER TABLE agreement2content RENAME TO agreement2content_old;

ALTER TABLE agreement2content_temp RENAME TO agreement2content;

DROP TABLE agreement2content_old CASCADE;

ALTER TABLE agreement2content
  ADD CONSTRAINT pk_agreement2content PRIMARY KEY(agreement2content);

CREATE INDEX ix_agreement2content_agreement
  ON agreement2content
  USING btree
  (agreement);

CREATE INDEX ix_agreement2content_content
  ON agreement2content
  USING btree
  (content);

	$$;

ALTER FUNCTION swap_agreement2content() OWNER TO postgres;

