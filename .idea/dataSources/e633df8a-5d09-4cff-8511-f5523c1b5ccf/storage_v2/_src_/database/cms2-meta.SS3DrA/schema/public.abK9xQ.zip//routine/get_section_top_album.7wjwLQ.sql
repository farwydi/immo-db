CREATE FUNCTION get_section_top_album(_schema text, _section_top_id uuid, _inner_join text, _where text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_row_top record;
_sql_text text;
_row_res record;
begin

EXECUTE 'select * from ' || _schema || '.section_top where section_top_id=''' || _section_top_id ||'''' into _row_top;

_sql_text:='

		SELECT t.*, '
		||_schema || '.get_preview_picture('''||_schema ||''','||_preview_type_id ||','|| _preview_watermark_id ||',t.melody_album_id) as  fat_name  
		FROM (
		SELECT
                        DISTINCT (melody_album.melody_album_id::uuid),
                        melody_album.name::text,
                        melody_album.is_collection::boolean,
                        melody_album.primary_artist_id::uuid,
                        melody_artist.last_name::text,
                        melody_artist.first_name::text,
                        melody_artist.middle_name::text,
                        melody_artist.\"group\"::text,
                        section_top_album.rating::integer,
                        section_top_album.rating_old::integer
                   FROM      
                         ' || _schema || '.section_top_album 
                        INNER JOIN
                            ' || _schema || '.melody_album 
                        ON
                            (section_top_album.album_id = melody_album.melody_album_id)
                            INNER JOIN
                                ' || _schema || '.melody_artist 
                            ON
                                (melody_album.primary_artist_id = melody_artist.melody_artist_id) '
			|| COALESCE(_inner_join,'') || ' ' ||
			/*'
			LEFT JOIN 
				(select source_id, max(fat_name) as fat_name from  ' || _schema || '.preview_relation 
				LEFT JOIN ' || _schema || '.preview_picture on preview_picture.preview_picture_id=preview_relation.preview_id
				where preview_type_id='||_preview_type_id ||' and preview_watermark_id='|| _preview_watermark_id ||' group by source_id ) preview 
				ON preview.source_id=melody_album.melody_album_id '
			
			||*/
			CASE WHEN _where is null THEN ' WHERE '
				    WHEN _where='' THEN ' WHERE '
				    ELSE _where || ' and '
			   END
			
                    || ' section_top_album.section_top_id = '''|| _row_top.section_top_id || '''  
                    ORDER BY 
                        section_top_album.rating DESC
                    LIMIT 
			' || _row_top.limit  || ' ) as t' ;

--Raise EXception '%', _sql_text;

FOR _row_res IN EXECUTE _sql_text LOOP
	RETURN NEXT _row_res;
END LOOP;
end;
$$;

ALTER FUNCTION get_section_top_album(TEXT, UUID, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

