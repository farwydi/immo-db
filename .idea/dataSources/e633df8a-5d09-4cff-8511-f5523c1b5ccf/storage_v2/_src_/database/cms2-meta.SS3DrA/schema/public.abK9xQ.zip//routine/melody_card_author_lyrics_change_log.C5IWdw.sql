CREATE FUNCTION melody_card_author_lyrics_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_author_lyrics', OLD.author_lyrics_id, 'D', 'author_lyrics_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.author_lyrics_id =  OLD.author_lyrics_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_author_lyrics', NEW.author_lyrics_id, 'U', 'author_lyrics_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_author_lyrics', NEW.author_lyrics_id, 'I', 'author_lyrics_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_author_lyrics', OLD.author_lyrics_id, 'D', 'author_lyrics_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_author_lyrics', NEW.author_lyrics_id, 'I', 'author_lyrics_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION melody_card_author_lyrics_change_log() OWNER TO postgres;

