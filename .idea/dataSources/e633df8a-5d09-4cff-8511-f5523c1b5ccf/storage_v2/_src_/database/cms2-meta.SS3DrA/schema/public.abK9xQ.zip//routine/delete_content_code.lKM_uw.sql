CREATE FUNCTION delete_content_code(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM content_code WHERE cms_content_code_lookup_id = id;
END;
$$;

ALTER FUNCTION delete_content_code(INTEGER) OWNER TO postgres;

