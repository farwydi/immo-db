CREATE FUNCTION update_card_file_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

		IF (TG_OP = 'DELETE') THEN

				update melody_card set modification_date=now() where melody_card_id=OLD.card_id;
				update melody_file set modification_date=now() where melody_file_id=OLD.file_id;
				update video_file set modification_date=now() where video_file_id=OLD.file_id;

		ELSE
				update melody_card set modification_date=now() where melody_card_id=NEW.card_id;
				update melody_file set modification_date=now() where melody_file_id=NEW.file_id;
				update video_file set modification_date=now() where video_file_id=NEW.file_id;

		END IF;


		RETURN null;
END;
$$;

ALTER FUNCTION update_card_file_trigger() OWNER TO postgres;

