CREATE FUNCTION melody_card_composer_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_composer', OLD.composer_id, 'D', 'composer_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.composer_id =  OLD.composer_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_composer', NEW.composer_id, 'U', 'composer_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_composer', NEW.composer_id, 'I', 'composer_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_composer', OLD.composer_id, 'D', 'composer_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_card_composer', NEW.composer_id, 'I', 'composer_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION melody_card_composer_change_log() OWNER TO postgres;

