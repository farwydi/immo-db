CREATE FUNCTION split_artist(_values text[]) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
	_i integer;

	_artist_full_name text;
	_artist_join text; 

	_artist_id uuid;
	_artist_main_id uuid;

	_is_used_artist_main_id boolean;

	_is_existed_artist boolean;

	_artist_row record;
	
	_result text;
	_is_artist_dominant boolean;
begin
	_count =0;
	_i=0;
	_is_used_artist_main_id=false;
	
	_result='';

	FOR i IN COALESCE(array_lower(_values,1),0) .. COALESCE(array_upper(_values,1),-1) LOOP
		_is_existed_artist=false;

		IF (_i=0) THEN
			_artist_main_id=substring(_values[i] from 1 for 36)::uuid;
		ELSE
			_artist_id=substring(_values[i] from 1 for 36)::uuid;
			RAISE NOTICE '_artist_id: %',_artist_id;
			_artist_full_name=substring(_values[i] from 38);
			_artist_join=replace(lower(_artist_full_name),' ','');

			select * into _artist_row from melody_artist where replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),' ','') =_artist_join;

			

			if (_artist_row.melody_artist_id is null) then
				--? ????????????
				select * into _artist_row  from melody_artist_equivalent where replace(lower(name),' ','') =_artist_join; 

				if (_artist_row.melody_artist_id is null) then
					if (not _is_used_artist_main_id) then
						
						_artist_id=_artist_main_id;
						_is_used_artist_main_id=true;
						
					end if;
				else
					_is_existed_artist=true;
					_artist_id=_artist_row.melody_artist_id;
				end if;
			else
				_is_existed_artist=true;
				_artist_id=_artist_row.melody_artist_id;
			end if;


			if (_artist_id<>_artist_main_id) then
				RAISE NOTICE '_artist_id_new: %',_artist_id;
				
				if (not _is_existed_artist) then
					insert into melody_artist (melody_artist_id,"group") values (_artist_id,_artist_full_name);
				end if;
								
		
				/*equivalent*/
				for _artist_row in select * from melody_artist_equivalent where melody_artist_id=_artist_main_id loop
					select count(*) into _count from melody_artist_equivalent where melody_artist_id=_artist_id and "name"=_artist_row.name;

					if (_count=0) then
						insert into melody_artist_equivalent (melody_artist_id,"name") 
							values (_artist_id,_artist_row.name);
					end if;
				end loop; 
				
				/*genre*/
				for _artist_row in select * from melody_artist_genre where artist_id=_artist_main_id loop
					select count(*) into _count from melody_artist_genre where artist_id=_artist_id and genre_id=_artist_row.genre_id;

					if (_count=0) then
						insert into melody_artist_genre (artist_id,genre_id) 
							values (_artist_id,_artist_row.genre_id);
					end if;
				end loop;
				
				
				/*relation artist*/ 
				for _artist_row in select * from melody_artist_relation where artist_id=_artist_main_id loop
					select count(*) into _count from melody_artist_relation where artist_id=_artist_id and parent_artist_id=_artist_row.parent_artist_id;

					if (_count=0) then 
						insert into melody_artist_relation (artist_id,parent_artist_id,is_current) 
							values (_artist_id,_artist_row.parent_artist_id,_artist_row.is_current);
					end if;
				end loop;
				
				/*relation parent_artist*/
				for _artist_row in  select * from melody_artist_relation where parent_artist_id=_artist_main_id loop
					select count(*) into _count from melody_artist_relation where parent_artist_id=_artist_id and artist_id=_artist_row.artist_id;

					if (_count=0) then 
						insert into melody_artist_relation (artist_id,parent_artist_id,is_current) 
							values (_artist_row.artist_id,_artist_id,_artist_row.is_current);
					end if;
					
				end loop;
				
				/*card*/
				for _artist_row in select * from melody_card_artist where artist_id=_artist_main_id loop
					select count(*) into _count from melody_card_artist where artist_id=_artist_id and card_id=_artist_row.card_id; 
					RAISE NOTICE '_artist_row.card_id: %',_artist_row.card_id;
					RAISE NOTICE '_count: %',_count;
					if (_count=0) then
						insert into melody_card_artist (card_id,artist_id,is_dominant,is_album_visible)
							values (_artist_row.card_id,_artist_id,false,_artist_row.is_album_visible);
					end if;
					select is_dominant into _is_artist_dominant from melody_card_artist where artist_id=_artist_id and card_id=_artist_row.card_id; 
					RAISE NOTICE '_is_artist_dominant: %',_is_artist_dominant;
					update melody_card_artist set is_dominant=_is_artist_dominant where artist_id=_artist_id and card_id=_artist_row.card_id;
					if (_i=1) then
						update melody_card_artist set is_dominant=_artist_row.is_dominant where artist_id=_artist_id and card_id=_artist_row.card_id;
						RAISE NOTICE '_i=1 _artist_row.is_dominant: %',_artist_row.is_dominant;	
					end if;
				end loop;
				
				
				if (_i=1) then
					/*album*/
					update melody_album set primary_artist_id=_artist_id where primary_artist_id=_artist_main_id; 
					 
				end if;	

				/*news*/
				for _artist_row in select news_id, _artist_id from news_artist where artist_id=_artist_main_id loop
					select count(*) into _count from news_artist where artist_id=_artist_id and news_id=_artist_row.news_id;

					if (_count=0) then
						insert into news_artist (artist_id,news_id)
							values (_artist_id,_artist_row.news_id);
					end if;
					
				end loop;
				
				
				/*preview*/
				delete from preview_relation where source_id=_artist_main_id;
				
				--recommendations one way
				for _artist_row in select * from recommendation where source_id=_artist_main_id loop
					select count(*) into _count from recommendation where source_id=_artist_id and rec_object_id=_artist_row.rec_object_id;
					if (_count=0) then
						insert into recommendation (source_id,rec_object_id,weight)
							values (_artist_id,_artist_row.rec_object_id,_artist_row.weight);
					end if;
				end loop;
				--recommendations other way
				for _artist_row in select * from recommendation where rec_object_id=_artist_main_id loop
					select count(*) into _count from recommendation where rec_object_id=_artist_id and source_id=_artist_row.source_id;

					if (_count=0) then
						insert into recommendation (source_id,rec_object_id,weight)
							values (_artist_row.source_id,_artist_id,_artist_row.weight);
					end if;
				end loop;
				
			else
				update melody_artist set "group"=_artist_full_name,last_name=null, first_name=null, middle_name=null where melody_artist_id=_artist_id;
			end if;
			
			if (_result='') then
				_result= _artist_id;
			else 
				_result=_result || ';' || _artist_id;
			end if;
			 
		END IF;

		_i=_i+1;
	END LOOP;

	if (_is_used_artist_main_id=false) then
		delete from melody_artist where melody_artist_id=_artist_main_id;

		update recycle set original_id=_artist_id where original_id=_artist_main_id;

		insert into recycle
		select _artist_id,_artist_main_id;
		delete from recommendation where rec_object_id = _artist_main_id or source_id=_artist_main_id;
	end if;

	return _result;
	
end;
$$;

ALTER FUNCTION split_artist(TEXT[]) OWNER TO postgres;

