CREATE FUNCTION update_content_type_delivery_type(_delivery_type_id integer, _content_type_id integer, _content_number_block_id integer, _last_digit integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE content_type_delivery_type 
	SET
		content_number_block_id = _content_number_block_id,
		last_digit = _last_digit
	WHERE 
		delivery_type_id = _delivery_type_id AND content_type_id = _content_type_id;
	IF NOT FOUND THEN
	INSERT INTO content_type_delivery_type
	(
		delivery_type_id,
		content_type_id,
		content_number_block_id,
		last_digit
	)
	VALUES
	(
		_delivery_type_id,
		_content_type_id,
		_content_number_block_id,
		_last_digit
	);
	END IF;
		
END;
$$;

ALTER FUNCTION update_content_type_delivery_type(INTEGER, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

