CREATE FUNCTION content_code_logger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
IF NEW.catalog_id = '00000000-0000-0000-0000-000000000000' THEN
    insert into extra.content_code_log (content_code_id) values (NEW.content_code_id);
    NEW.catalog_id = null;
END IF;
RETURN NEW;
END;
$$;

ALTER FUNCTION content_code_logger() OWNER TO postgres;

