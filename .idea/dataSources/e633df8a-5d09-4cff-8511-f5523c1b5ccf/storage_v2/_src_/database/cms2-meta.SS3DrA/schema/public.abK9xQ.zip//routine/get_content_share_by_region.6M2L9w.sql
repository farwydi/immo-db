CREATE FUNCTION get_content_share_by_region(_contentid integer, _regionid integer, _is_allied_rights boolean) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_row record;
begin

for _row in SELECT
cc.content_billing_id,
agr.agreement,
a2c.content_owner_share,
agr.is_allied_rights,
agr.start_date,
agr.end_date,
cnt.contragent,
agr.no,
cnt.name,
reg.name,
reg.region
FROM agreement as agr
JOIN agreement2content as a2c on agr.agreement=a2c.agreement
JOIN agreement2region as a2r on agr.agreement=a2r.agreement
JOIN region as reg on reg.region=a2r.region
JOIN contragent as cnt on cnt.contragent=agr.contragent
JOIN content_code as cc on a2c.content=cc.content_billing_id
WHERE
cc.content_billing_id = _contentid AND a2r.region = _regionid AND agr.is_allied_rights = _is_allied_rights

loop

return next _row;
end loop;


end
$$;

ALTER FUNCTION get_content_share_by_region(INTEGER, INTEGER, BOOLEAN) OWNER TO postgres;

