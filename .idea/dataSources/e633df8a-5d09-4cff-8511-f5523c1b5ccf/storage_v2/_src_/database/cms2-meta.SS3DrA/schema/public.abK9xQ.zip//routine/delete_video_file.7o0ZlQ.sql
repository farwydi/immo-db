CREATE FUNCTION delete_video_file(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
                DELETE FROM card_file WHERE file_id = id;
                DELETE FROM file_content_code WHERE file_id = id;
                DELETE FROM preview_relation WHERE source_id = id;
                DELETE FROM video_file WHERE video_file_id = id;
END;
$$;

ALTER FUNCTION delete_video_file(UUID) OWNER TO postgres;

