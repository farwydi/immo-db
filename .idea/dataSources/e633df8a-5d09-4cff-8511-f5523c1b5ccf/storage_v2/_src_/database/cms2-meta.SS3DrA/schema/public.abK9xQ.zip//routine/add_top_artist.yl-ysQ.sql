CREATE FUNCTION add_top_artist(_artist_id uuid, _section_id integer, _schema_proto text) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_row_res record;
_founded integer;
begin
	_sql_text = '
		select 
			count(*) as c
		from
			'|| _schema_proto ||'.section_top_artist as sta
		where
			section_top_id = 
			(
				select 
					section_top_id 
				from 
					'|| _schema_proto ||'.section_top 
				where 
					section_id = '|| _section_id ||'
			)
		and
			artist_id = \'' || _artist_id || '\'
	';
	RAISE NOTICE '%',_sql_text;
	EXECUTE _sql_text into _founded;

	IF (_founded = 0) THEN
		_sql_text = '
			INSERT INTO '|| _schema_proto ||'.section_top_artist(
				    section_top_id, artist_id, rating, rating_old)
			    VALUES (
				(select 
					section_top_id 
				from 
					'|| _schema_proto ||'.section_top 
				where 
					section_id = '|| _section_id ||'
				), 
			    \'' || _artist_id || '\', 
			    1, 
			    1);
		';
		EXECUTE _sql_text;
		return true;
	ELSE
		return false;
	END IF;

end;
$$;

ALTER FUNCTION add_top_artist(UUID, INTEGER, TEXT) OWNER TO postgres;

