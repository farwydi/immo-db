CREATE FUNCTION get_content_owner_share_sum(_content_id integer, _region_id integer, _is_allied_rights boolean, _date timestamp without time zone, postfix character varying, prefix character varying) RETURNS numeric
	LANGUAGE plpgsql
AS
$$
DECLARE
   _c numeric;
BEGIN   
execute 'select sum(content_owner_share) from '||prefix||'agreement2content'||postfix||' a2c
inner join '||prefix||'agreement'||postfix||' a on a.agreement=a2c.agreement
inner join '||prefix||'agreement2region'||postfix||' a2r on a2r.agreement=a.agreement
where content='||_content_id||' and a2r.region='||_region_id||' and is_allied_rights='||_is_allied_rights||' and start_date<='''||_date||''' and end_date>='''||_date||'''' into _c  ;
RETURN _c;
END;
$$;

ALTER FUNCTION get_content_owner_share_sum(INTEGER, INTEGER, BOOLEAN, TIMESTAMP, VARCHAR, VARCHAR) OWNER TO postgres;

