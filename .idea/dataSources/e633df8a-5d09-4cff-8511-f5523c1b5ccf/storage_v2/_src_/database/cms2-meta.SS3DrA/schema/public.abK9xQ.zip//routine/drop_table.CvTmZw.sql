CREATE FUNCTION drop_table(t character varying) RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
BEGIN
               execute 'DROP TABLE billing_archive.' || t || ' CASCADE';
END;
$$;

ALTER FUNCTION drop_table(VARCHAR) OWNER TO postgres;

