CREATE FUNCTION get_card_by_filter(_filter_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_where text;
begin

_where='';

for _row in select "table", "column", filter_operation.value as operation, filter_condition.value,is_union  from filter 
				inner join filter_condition on filter_condition.filter_id=filter.filter_id
				inner join filter_operation on filter_condition.filter_operation_id=filter_operation.filter_operation_id
				inner join filter_column on filter_condition.filter_column_id=filter_column.filter_column_id
			where filter.filter_id=_filter_id
	loop

	if (_where<>'') THEN
		if (_row.is_union) THEN
			_where=_where || ' or ';
		ELSE
			_where=_where || ' and ';
		END IF;
	ELSE
		_where=' where ';
	END IF;

	_where=_where || _row.table || '.' || _row.column || _row.operation || _row.value;
end loop;


for _row in execute 'select distinct card_id from melody_card 
		inner join melody_card_artist on melody_card.melody_card_id=melody_card_artist.card_id
		inner join melody_artist_genre on melody_artist_genre.artist_id=melody_card_artist.artist_id ' || _where 
	loop
	
return next _row;

end loop;


end;
$$;

ALTER FUNCTION get_card_by_filter(INTEGER) OWNER TO postgres;

