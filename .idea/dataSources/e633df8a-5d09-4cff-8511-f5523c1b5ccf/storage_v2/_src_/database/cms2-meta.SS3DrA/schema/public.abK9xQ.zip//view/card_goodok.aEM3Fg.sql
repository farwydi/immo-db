CREATE VIEW card_goodok (card_goodok_id, card_id, operator_id, goodok_code_short, goodok_code_long, description) AS
SELECT DISTINCT cf.card_id || rbt.goodok_code_long::TEXT AS card_goodok_id,
				cf.card_id,
				p.operator_id,
				rbt.goodok_code_short,
				rbt.goodok_code_long,
				rbt.price_category                       AS description
FROM card_file cf
		 JOIN rbt_code rbt ON cf.file_id = rbt.file_id
		 JOIN rbt_platform p ON p.rbt_platform_id = rbt.rbt_platform_id
		 JOIN file_content_code fcc ON fcc.file_id = rbt.file_id
		 JOIN content_code cc ON cc.content_code_id = fcc.content_code_id
WHERE cc.is_main = TRUE
  AND (rbt.status = ANY (ARRAY [0, 3]))
  AND rbt.rbt_platform_id = 1
ORDER BY cf.card_id, p.operator_id, rbt.goodok_code_short, rbt.goodok_code_long, rbt.price_category,
		 cf.card_id || rbt.goodok_code_long::TEXT;

ALTER TABLE card_goodok
	OWNER TO postgres;

