CREATE FUNCTION update_content_code_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        -- если обновляется modification_date, billing_modification_date или rightholder_info_registration_date, то modification_date не обновляем
        IF (TG_OP = 'UPDATE') THEN
                IF coalesce(NEW.billing_modification_date,'1900-01-01 01:01:01') <> coalesce(OLD.billing_modification_date,'1900-01-01 01:01:01') THEN
                        --RAISE NOTICE 'test_billing_modification_date';
                        --RAISE NOTICE '%', NEW.billing_modification_date;
                        --RAISE NOTICE '%', OLD.billing_modification_date;
                        RETURN NEW;
                ELSIF coalesce(NEW.modification_date,'1900-01-01 01:01:01') <> coalesce(OLD.modification_date,'1900-01-01 01:01:01') THEN
                        --RAISE NOTICE 'test_modification_date';
                        --RAISE NOTICE '%', NEW.modification_date;
                        --RAISE NOTICE '%', OLD.modification_date;
                        RETURN NEW;
                ELSIF coalesce(NEW.rightholder_info_registration_date,'1900-01-01 01:01:01') <> coalesce(OLD.rightholder_info_registration_date,'1900-01-01 01:01:01') THEN
                        --RAISE NOTICE 'test_rightholder_info_registration_date';
                        --RAISE NOTICE '%', NEW.rightholder_info_registration_date;
                        --RAISE NOTICE '%', OLD.rightholder_info_registration_date;
                        RETURN NEW;
                END IF;
        END IF;

        --RAISE NOTICE 'update modification_date';
        NEW.modification_date := now();
        RETURN NEW;

END;
$$;

ALTER FUNCTION update_content_code_trigger() OWNER TO postgres;

