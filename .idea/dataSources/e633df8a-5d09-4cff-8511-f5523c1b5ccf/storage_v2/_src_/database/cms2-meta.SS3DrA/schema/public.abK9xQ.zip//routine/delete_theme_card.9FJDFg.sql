CREATE FUNCTION delete_theme_card(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM theme_card WHERE theme_card_id = id;
	DELETE FROM card_content_category WHERE card_id = id;
	DELETE FROM card_association WHERE card_id = id;
END;
$$;

ALTER FUNCTION delete_theme_card(UUID) OWNER TO postgres;

