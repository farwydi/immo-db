CREATE FUNCTION process_storefront_contragent_audit() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") (
            select OLD.storefront_id, a.agreement, 'D' from contragent c
            join agreement a on a.contragent = c.contragent
            where c.contragent = OLD.contragent_id
        );
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") (
            select OLD.storefront_id, a.agreement, 'D' from contragent c
            join agreement a on a.contragent = c.contragent
            where c.contragent = OLD.contragent_id
        );
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") (
            select NEW.storefront_id, a.agreement, 'I' from contragent c
            join agreement a on a.contragent = c.contragent
            where c.contragent = NEW.contragent_id
        );	    
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO availability.storefront_agreement_audit(storefront_id, agreement_id, "action") (
            select NEW.storefront_id, a.agreement, 'I' from contragent c
            join agreement a on a.contragent = c.contragent
            where c.contragent = NEW.contragent_id
        );
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

ALTER FUNCTION process_storefront_contragent_audit() OWNER TO postgres;

