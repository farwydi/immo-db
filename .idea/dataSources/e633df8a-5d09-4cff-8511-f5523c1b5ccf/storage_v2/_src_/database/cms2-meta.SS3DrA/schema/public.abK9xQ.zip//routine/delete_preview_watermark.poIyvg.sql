CREATE FUNCTION delete_preview_watermark(_preview_watermark_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM preview_watermark WHERE preview_watermark_id = _preview_watermark_id;
END;
$$;

ALTER FUNCTION delete_preview_watermark(INTEGER) OWNER TO postgres;

