CREATE FUNCTION array_uuid_to_string(vars uuid[]) RETURNS character varying
	LANGUAGE plpgsql
AS
$$
DECLARE
	_vars varchar[];
BEGIN
	FOR i IN COALESCE(array_lower(vars,1),0) .. COALESCE(array_upper(vars,1),-1) LOOP
		_vars[i] = quote_literal(vars[i]);
	END LOOP;
	RETURN array_to_string(_vars, ',');
END;
$$;

ALTER FUNCTION array_uuid_to_string(UUID[]) OWNER TO postgres;

