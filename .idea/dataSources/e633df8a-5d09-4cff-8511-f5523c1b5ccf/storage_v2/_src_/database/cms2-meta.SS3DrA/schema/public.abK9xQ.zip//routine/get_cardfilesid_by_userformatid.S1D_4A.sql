CREATE FUNCTION get_cardfilesid_by_userformatid(_card_id uuid, _user_format_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
DECLARE

_table_file text;
_sql_command text;
_row_res record;

BEGIN

                select table_prefix from user_format where user_format_id = _user_format_id into _table_file;
                _sql_command = 'select ' || _table_file || '_file_id from ' || _table_file || '_file ' || 
                                               'where ' 
                                               || _table_file || '_file_id in (select file_id from card_file where card_id = ''' || _card_id || ''')'
                                               || ' and '
                                               || 'content_type_id in (select content_type_id from content_type where user_format_id = ' || _user_format_id || ')';

                --RAISE NOTICE '%',_sql_command;
                
                FOR _row_res IN EXECUTE _sql_command LOOP
                               RETURN NEXT _row_res;
                END LOOP;

END;
$$;

ALTER FUNCTION get_cardfilesid_by_userformatid(UUID, INTEGER) OWNER TO postgres;

