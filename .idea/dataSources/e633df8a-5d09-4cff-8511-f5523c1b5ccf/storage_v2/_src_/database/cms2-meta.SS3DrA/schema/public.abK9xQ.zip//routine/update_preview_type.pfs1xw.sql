CREATE FUNCTION update_preview_type(_preview_type_id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE preview_type SET name = _name WHERE preview_type_id = _preview_type_id;
	
	IF NOT FOUND
		THEN
		INSERT INTO preview_type (preview_type_id, name) VALUES (_preview_type_id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_preview_type(INTEGER, VARCHAR) OWNER TO postgres;

