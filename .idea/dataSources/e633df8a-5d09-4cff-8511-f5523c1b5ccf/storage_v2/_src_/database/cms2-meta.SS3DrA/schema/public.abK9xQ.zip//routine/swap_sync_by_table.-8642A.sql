CREATE FUNCTION swap_sync_by_table(t character varying, mode character varying) RETURNS boolean
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
DECLARE
   _c int;
   _sql varchar;
BEGIN
   IF (mode = 'release')
   THEN
       SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename in (t || '_new', t);
       IF (_c = 2)
       THEN
           SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = t || '_old';
           IF (_c = 1)
           THEN
               execute 'DROP TABLE ' || t || '_old CASCADE';
           END IF;
	   execute 'ALTER TABLE ' || t || ' RENAME TO ' || t || '_old';		
		FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
					 FROM pg_constraint 
					 INNER JOIN pg_class ON conrelid=pg_class.oid 
					 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					 where nspname = 'public' and relname = t || '_old' LOOP
			EXECUTE _sql;
		END LOOP;
	   FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
					FROM pg_index
					JOIN pg_class ON indexrelid=pg_class.oid
					JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					JOIN pg_class c on indrelid = c.oid
					WHERE nspname = 'public' and c.relname = t || '_old' LOOP
			EXECUTE _sql;
		END LOOP;
		
	   execute 'ALTER TABLE ' || t || '_new RENAME TO ' || t;
		FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
					 FROM pg_constraint 
					 INNER JOIN pg_class ON conrelid=pg_class.oid 
					 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					 where nspname = 'public' and relname = t || '_new' LOOP
			EXECUTE _sql;
		END LOOP;	   
	   FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
					FROM pg_index
					JOIN pg_class ON indexrelid=pg_class.oid
					JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					JOIN pg_class c on indrelid = c.oid
					WHERE nspname = 'public' and c.relname = t || '_new' LOOP
			EXECUTE _sql;
		END LOOP;				
	   
        RETURN true;
       END IF;
   ELSE
       IF (mode = 'revert') THEN
           SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename in (t || '_old', t);
           IF (_c = 2)
           THEN
               SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename = t || '_new';
               IF (_c = 1)
               THEN
                   execute 'DROP TABLE ' || t || '_new CASCADE';
               END IF;
               execute 'ALTER TABLE ' || t || ' RENAME TO ' || t || '_new';			   
				FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
							 FROM pg_constraint 
							 INNER JOIN pg_class ON conrelid=pg_class.oid 
							 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
							 where nspname = 'public' and relname = t || '_new' LOOP
					EXECUTE _sql;
				END LOOP;			   
			   FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
							FROM pg_index
							JOIN pg_class ON indexrelid=pg_class.oid
							JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
							JOIN pg_class c on indrelid = c.oid
							WHERE nspname = 'public' and c.relname = t || '_new' LOOP
					EXECUTE _sql;
				END LOOP;								
               execute 'ALTER TABLE ' || t || '_old RENAME TO ' || t;
			   return true;
        RETURN false;
           END IF;
       END IF;
   END IF;
    RETURN false;
END;
$$;

ALTER FUNCTION swap_sync_by_table(VARCHAR, VARCHAR) OWNER TO postgres;

