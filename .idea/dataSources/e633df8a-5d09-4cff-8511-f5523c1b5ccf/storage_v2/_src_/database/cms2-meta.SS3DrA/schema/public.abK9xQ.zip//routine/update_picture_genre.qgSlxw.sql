CREATE FUNCTION update_picture_genre(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE picture_genre SET name = _name WHERE picture_genre_id = id;
	IF NOT FOUND THEN
	INSERT INTO picture_genre (picture_genre_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_picture_genre(INTEGER, VARCHAR) OWNER TO postgres;

