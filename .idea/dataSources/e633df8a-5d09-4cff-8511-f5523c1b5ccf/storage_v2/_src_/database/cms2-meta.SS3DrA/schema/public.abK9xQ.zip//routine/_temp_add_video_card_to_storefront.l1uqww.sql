CREATE FUNCTION _temp_add_video_card_to_storefront(_card_id uuid, _section_id integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	_count integer;
begin

select count(*) into _count from storefront.content where card_id=_card_id;
if (_count>0) then
	return 0;
end if;

/*вставляем максимальные коды для каждого формата */
 
insert into storefront.content
select  content_code,video_card_id,name,_section_id,user_format_id,'video_card' as tablename,name as search_text,null,minimal_cost,is_free,is_hit, null as drm_type,false
from (
	select distinct video_card_id as card_id, max(content_code) as content_code,user_format.user_format_id 
		from video_card
		inner join  card_file
			on video_card.video_card_id=card_file.card_id
	inner join file_content_code on card_file.file_id=file_content_code.file_id
	inner join content_type on content_type.content_type_id=file_content_code.content_type_id
	inner join content_code on content_code.content_code_id=file_content_code.content_code_id
	inner join user_format on user_format.user_format_id=content_type.user_format_id 
	where video_card_id=_card_id
	group by video_card_id,user_format.user_format_id
	) t
	inner join video_card on video_card.video_card_id=t.card_id;

/* превью */
insert into storefront.preview_picture
select p.* from 
preview_picture p left join storefront.preview_picture on p.preview_picture_id=preview_picture.preview_picture_id
where preview_picture.preview_picture_id is null;

insert into storefront.preview_relation
select p.* from 
preview_relation p left join storefront.preview_relation on p.preview_id=preview_relation.preview_id
where preview_relation.preview_id is null;

return 1;
end;
$$;

ALTER FUNCTION _temp_add_video_card_to_storefront(UUID, INTEGER) OWNER TO postgres;

