CREATE FUNCTION swap_tariff2agreement() RETURNS void
	LANGUAGE sql
AS
$$
	ALTER TABLE tariff2agreement RENAME TO tariff2agreement_old;

ALTER TABLE tariff2agreement_temp RENAME TO tariff2agreement;

DROP TABLE tariff2agreement_old;



ALTER TABLE tariff2agreement
  ADD CONSTRAINT pk_tariff2agreement PRIMARY KEY(content_sale2point);
	$$;

ALTER FUNCTION swap_tariff2agreement() OWNER TO postgres;

