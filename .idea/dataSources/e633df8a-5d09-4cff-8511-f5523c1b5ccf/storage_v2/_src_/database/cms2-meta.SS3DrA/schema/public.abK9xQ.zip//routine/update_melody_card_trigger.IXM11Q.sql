CREATE FUNCTION update_melody_card_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
    _prev_weight integer;
BEGIN
        NEW.modification_date := now();

        IF (TG_OP = 'INSERT') THEN
            _prev_weight := -1;
            select into _prev_weight weight from melody_card where name < NEW.name order by name desc limit 1;
            IF (_prev_weight > 0) THEN NEW.weight := (_prev_weight + 1); END IF;
        END IF;
        
        RETURN NEW;
END;
$$;

ALTER FUNCTION update_melody_card_trigger() OWNER TO postgres;

