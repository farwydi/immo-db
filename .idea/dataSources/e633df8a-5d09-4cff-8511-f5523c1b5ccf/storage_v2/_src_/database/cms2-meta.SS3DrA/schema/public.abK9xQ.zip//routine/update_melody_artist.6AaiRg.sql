CREATE FUNCTION update_melody_artist(artistid uuid, lastname character varying, firstname character varying, middlename character varying, artistgroup character varying, descriptionshort text, descriptionfull text, artistbirthday timestamp without time zone) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
    real_artistid uuid;
BEGIN
real_artistid=(select(get_main_from_recycle(artistid)));

	UPDATE melody_artist SET
		last_name = lastName,
		first_name = firstName,
		middle_name = middleName,
		"group" = artistGroup,
		description_short = descriptionShort,
		description_detailed = descriptionFull,
		birthday = artistBirthday
	WHERE
		melody_artist_id = real_artistid;
	IF NOT FOUND
		THEN
		INSERT INTO melody_artist(
			melody_artist_id, 
			last_name,
			first_name,
			middle_name,
			"group",
			description_short,
			description_detailed,
			birthday
		)
		VALUES
		(
			real_artistid, 
			lastName,
			firstName,
			middleName,
			artistGroup,
			descriptionShort,
			descriptionFull,
			artistBirthday
		);
	END IF;	
END;
$$;

ALTER FUNCTION update_melody_artist(UUID, VARCHAR, VARCHAR, VARCHAR, VARCHAR, TEXT, TEXT, TIMESTAMP) OWNER TO postgres;

