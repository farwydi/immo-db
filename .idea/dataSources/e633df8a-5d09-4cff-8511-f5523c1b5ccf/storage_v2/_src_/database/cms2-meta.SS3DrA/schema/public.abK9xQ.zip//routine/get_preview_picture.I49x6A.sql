CREATE FUNCTION get_preview_picture(_schema text, _preview_type_id integer, _preview_watermark_id integer, _source_id uuid) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
	_res text;
begin

execute '
		select fat_name  from  ' || _schema || '.preview_relation 
				LEFT JOIN ' || _schema || '.preview_picture on preview_picture.preview_picture_id=preview_relation.preview_id
				where source_id=''' || _source_id || ''' and
					preview_type_id='||_preview_type_id ||' and preview_watermark_id='|| _preview_watermark_id ||' 
				order by fat_name desc limit 1' into _res;

return _res;
				
end;
$$;

ALTER FUNCTION get_preview_picture(TEXT, INTEGER, INTEGER, UUID) OWNER TO postgres;

