CREATE FUNCTION card_association_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('card_association', OLD.card_id, 'D', 'card_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.card_id =  OLD.card_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('card_association', NEW.card_id, 'U', 'card_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('card_association', NEW.card_id, 'I', 'card_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('card_association', OLD.card_id, 'D', 'card_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('card_association', NEW.card_id, 'I', 'card_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION card_association_change_log() OWNER TO postgres;

