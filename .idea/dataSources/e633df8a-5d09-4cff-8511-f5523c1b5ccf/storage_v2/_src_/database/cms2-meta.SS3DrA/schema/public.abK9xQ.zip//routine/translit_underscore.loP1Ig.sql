CREATE FUNCTION translit_underscore(p_string character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE sql
AS
$$
select translate(translit($1), ' ', '_');
$$;

ALTER FUNCTION translit_underscore(VARCHAR) OWNER TO postgres;

