CREATE FUNCTION update_prototype_search_card(_schema_meta text, _schema_proto text) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_sql_text1 text;
_card record;
_search_text text;
_s text;
_i integer;
_card_id uuid;
begin

	_sql_text = '
		select 
			count(*)
		from 
			information_schema.columns 
		where 
			table_schema = ''' || _schema_proto ||'''
		and
			table_name = ''content''
		and
			column_name = ''search_text''
	';

	EXECUTE _sql_text INTO _i;

	if(_i>0) then
		EXECUTE 'alter table '|| _schema_proto ||'.content drop search_text;';
	end if;

	EXECUTE 'alter table '|| _schema_proto ||'.content add column search_text text;';

	--_sql_text = 'select '||_schema_proto ||'.update_prototype_search_card_by_section('''|| _schema_meta ||''', '''|| _schema_proto ||''', -1)';

	_sql_text = '
		update 
			'|| _schema_proto ||'.content
		set
			search_text = '|| _schema_meta ||'.prototype_get_search_text_by_card('''|| _schema_meta ||''','''|| _schema_proto || ''',melody_card_id)
		where
			not(melody_card_id is null)
			
	';

	execute _sql_text;

	_sql_text = '
		select 
			count(*)
		from 
			information_schema.columns 
		where 
			table_schema = ''' || _schema_proto || '''
		and
			table_name = ''content''
		and
			column_name = ''fts''
	';

	EXECUTE _sql_text INTO _i;

	if(_i>0) then
		EXECUTE 'alter table '|| _schema_proto ||'.content drop fts;';
	end if;

	EXECUTE 'alter table '|| _schema_proto ||'.content add column fts tsvector;';	

	/*_sql_text = '
		ALTER TABLE '|| _schema_proto ||'.content DROP fts;
		ALTER TABLE '|| _schema_proto ||'.content ADD COLUMN fts tsvector;
		UPDATE '|| _schema_proto ||'.content SET fts = to_tsvector(''russian'', (coalesce(search_text,'''')));
		CREATE INDEX content_fts_idx ON '|| _schema_proto ||'.content USING gin(fts);
	';
	EXECUTE _sql_text;
*/
end;
$$;

ALTER FUNCTION update_prototype_search_card(TEXT, TEXT) OWNER TO postgres;

