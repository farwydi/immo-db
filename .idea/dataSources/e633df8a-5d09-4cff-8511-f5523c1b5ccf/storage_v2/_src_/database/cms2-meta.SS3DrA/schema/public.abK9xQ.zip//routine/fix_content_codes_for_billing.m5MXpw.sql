CREATE FUNCTION fix_content_codes_for_billing() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
_res record;
_temp record;
BEGIN

for _res in select * from content_code where (singer is null or registration_name is null) and (content_billing_id is null and content_code_billing_id is null) loop
select mc.*,ma.* into _temp from content_code cc
join file_content_code fcc on cc.content_code_id=fcc.content_code_id
join card_file cf on cf.file_id=fcc.file_id
join melody_card mc on mc.melody_card_id= cf.card_id
join melody_card_artist mca on mca.card_id=cf.card_id
join melody_artist ma on mca.artist_id=ma.melody_artist_id
where cc.content_code_id=_res.content_code_id limit 1;



update content_code set singer=trim(COALESCE(_temp.last_name,'')||' '||COALESCE(_temp.first_name,'')||' '||COALESCE(_temp.group,'')),registration_name= trim(COALESCE(_temp.last_name,'')||' '||COALESCE(_temp.first_name,'')||' '||COALESCE(_temp.group,''))||' - '||_temp.name where content_code.content_code_id=_res.content_code_id;

end loop;

END;
$$;

ALTER FUNCTION fix_content_codes_for_billing() OWNER TO postgres;

