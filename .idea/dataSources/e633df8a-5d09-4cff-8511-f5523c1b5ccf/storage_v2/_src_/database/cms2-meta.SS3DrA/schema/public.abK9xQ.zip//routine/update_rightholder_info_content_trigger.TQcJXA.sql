CREATE FUNCTION update_rightholder_info_content_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'UPDATE') THEN
                IF NEW.billing_modification_date <> OLD.billing_modification_date THEN
                        RETURN NEW;
                ELSIF NEW.modification_date <> OLD.modification_date THEN
                        RETURN NEW;
                END IF;
        END IF;
        NEW.modification_date := now();
    RETURN NEW;
END;
$$;

ALTER FUNCTION update_rightholder_info_content_trigger() OWNER TO postgres;

