CREATE FUNCTION delete_melody_composer(composer_id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM melody_composer WHERE melody_composer_id = composer_id;
END;
$$;

ALTER FUNCTION delete_melody_composer(UUID) OWNER TO postgres;

