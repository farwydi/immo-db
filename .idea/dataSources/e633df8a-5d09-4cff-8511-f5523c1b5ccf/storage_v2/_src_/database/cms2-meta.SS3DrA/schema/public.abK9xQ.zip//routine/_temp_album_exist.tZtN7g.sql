CREATE FUNCTION _temp_album_exist(_album_id uuid) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
begin
	select count(*) into _count from melody_album where melody_album_id=_album_id;

	return _count;
end;
$$;

ALTER FUNCTION _temp_album_exist(UUID) OWNER TO postgres;

