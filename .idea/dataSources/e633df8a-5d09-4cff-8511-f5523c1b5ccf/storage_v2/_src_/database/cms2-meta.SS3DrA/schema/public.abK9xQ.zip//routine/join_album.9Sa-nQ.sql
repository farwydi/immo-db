CREATE FUNCTION join_album(main_album uuid, album uuid) RETURNS uuid
	LANGUAGE plpgsql
AS
$$
declare
_res record;
_count integer;
_count1 integer;

_main_album uuid;
_album uuid;

_temp record;
BEGIN

select count(*) into _count from melody_album where melody_album.melody_album_id=main_album;
select count(*) into _count1 from melody_album where melody_album.melody_album_id=album;

if (_count=0 and _count1=0) then
return '00000000 -0000-0000-0000-000000000000 ';
end if;

if (_count=0 and _count1>0) then
return album;
end if;

if (_count>0 and _count1=0) then
return main_album;
end if;


select count(*) into _count from storefront.melody_album where melody_album.melody_album_id=main_album;
select count(*) into _count1 from storefront.melody_album where melody_album.melody_album_id=album;

--if (_count>0 and _count1>0) then
-- select * from storefront.join_album(main_album,album) into _temp ;
--end if;

select count(*) into _count from storefront.melody_album where melody_album.melody_album_id=main_album;
select count(*) into _count1 from storefront.melody_album where melody_album.melody_album_id=album;

_main_album=main_album;
_album=album;

if (_count=0 and _count1>0) then
_main_album=album;
_album=main_album;
end if;

--�������������
PERFORM join_recs(_main_album, _album);

/*album*/
SELECT
melody_album.melody_album_id,
COALESCE(melody_album.primary_artist_id, melody_album1.primary_artist_id) as primary_artist_id,
COALESCE(melody_album.name, melody_album1.name) as name,
COALESCE(melody_album.description, melody_album1.description) as description,
COALESCE(melody_album.released, melody_album1.released) as released,
COALESCE(melody_album.rightholder_id, melody_album1.rightholder_id) as rightholder_id,
COALESCE(melody_album.minimal_cost, melody_album1.minimal_cost) as minimal_cost,
COALESCE(melody_album.copyright, melody_album1.copyright) as copyright,
COALESCE(melody_album.is_collection, melody_album1.is_collection) as is_collection,
COALESCE(melody_album.creation_date, melody_album1.creation_date) as creation_date,
COALESCE(melody_album.modification_date, melody_album1.modification_date) as modification_date,
COALESCE(melody_album."billing modification_date", melody_album1."billing modification_date")

as "billing modification_date",
COALESCE(melody_album.album_billing_id, melody_album1.album_billing_id) as album_billing_id,
COALESCE(melody_album.album_code, melody_album1.album_code) as album_code into _res
FROM
melody_album,
melody_album melody_album1
WHERE
melody_album.melody_album_id=_main_album
and
melody_album1.melody_album_id=_album;

UPDATE melody_album
SET
primary_artist_id=_res.primary_artist_id,
name=_res.name,
description=_res.description,
released=_res.released,
rightholder_id=_res.rightholder_id,
minimal_cost=_res.minimal_cost,
copyright=_res.copyright,
is_collection=_res.is_collection,
creation_date=_res.creation_date,
modification_date=_res.modification_date,
"billing modification_date"=_res."billing modification_date",
album_billing_id=_res.album_billing_id,
album_code=_res.album_code
WHERE
melody_album_id=_main_album;


/*card*/
for _res in select * from melody_card_album where album_id=_album loop
select count(*) into _count from melody_card_album where album_id=_main_album and

card_id=_res.card_id;

if _count>0 then
delete from melody_card_album where album_id=_album and card_id=_res.card_id;
else
update melody_card_album SET album_id = _main_album
where album_id=_album and card_id=_res.card_id;
end if;

end loop;


/*preview*/
for _res in select * from preview_relation where source_id=_album loop
select count(*) into _count from preview_relation where source_id=_main_album and

preview_id=_res.preview_id;

if _count>0 then
delete from preview_relation where source_id=_album and review_id=_res.preview_id;
else
update preview_relation SET source_id = _main_album
where source_id=_album and preview_id=_res.preview_id;
end if;
end loop;

delete from melody_album where melody_album_id = _album;

update recycle set original_id=_main_album where original_id=_album;

insert into recycle
select _main_album,_album;


return _main_album;
END;
$$;

ALTER FUNCTION join_album(UUID, UUID) OWNER TO postgres;

