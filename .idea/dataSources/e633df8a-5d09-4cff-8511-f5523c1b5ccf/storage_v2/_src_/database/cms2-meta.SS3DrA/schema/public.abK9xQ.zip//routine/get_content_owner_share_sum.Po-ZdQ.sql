CREATE FUNCTION get_content_owner_share_sum(_storefront_id integer, _content_id integer, _region text, _is_allied_rights boolean, _date timestamp without time zone) RETURNS numeric
	LANGUAGE plpgsql
AS
$$
declare
_regions_array text[];
i integer;
min_sum numeric;
tmp_sum numeric;
BEGIN
min_sum = 100;
_regions_array:=string_to_array(_region, ','); 
for i in 1..array_upper( _regions_array, 1 ) loop
select * from get_content_owner_share_sum (_storefront_id, _content_id, _regions_array[i]::int, _is_allied_rights,_date) into tmp_sum;
if (tmp_sum is null)
then
tmp_sum :=0;
end if;
if ( tmp_sum<=min_sum)
then
min_sum=tmp_sum;
end if;
end loop;
return min_sum;
 
end;
$$;

ALTER FUNCTION get_content_owner_share_sum(INTEGER, INTEGER, TEXT, BOOLEAN, TIMESTAMP) OWNER TO postgres;

