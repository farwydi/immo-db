CREATE FUNCTION join_melody_card(main_card uuid, card uuid) RETURNS uuid
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_row_content_code record;
	_temp record;

	_count integer;
	_count1 integer;
	_count_rbt integer;

	_main_card uuid;
	_card uuid;
	_code1 record;
	_code2 record;
_main1 boolean;
_main2 boolean;
_card1 record;
_card2 record;

begin


select count(*) into _count from melody_card where melody_card.melody_card_id=main_card;
select count(*) into _count1 from melody_card where melody_card.melody_card_id=card;

if (_count=0 and _count1=0) then 
	return '00000000-0000-0000-0000-000000000000';
end if;

if (_count=0 and _count1>0) then 
	return card;
end if;

if (_count>0 and _count1=0) then 
	return main_card;
end if;



_main_card=main_card;
_card=card;

if (_count=0 and _count1>0) then
	_main_card=card;
	_card=main_card;
end if;




	SELECT
		melody_card.melody_card_id,
		COALESCE(melody_card.name,melody_card1.name) as name,
		COALESCE(melody_card.creation_date,melody_card1.creation_date) as creation_date,
		COALESCE(melody_card.modification_date,melody_card1.modification_date) as modification_date,
		COALESCE(melody_card.is_erotica,melody_card1.is_erotica) as is_erotica,
		COALESCE(melody_card.is_free,melody_card1.is_free) as is_free,
		COALESCE(melody_card.minimal_cost,melody_card1.minimal_cost) as minimal_cost,
		COALESCE(melody_card.lyrics,melody_card1.lyrics) as lyrics,
		COALESCE(melody_card.is_hit,melody_card1.is_hit) as is_hit into _row
	from 
		melody_card ,
		melody_card melody_card1 
	where 
		melody_card.melody_card_id=_main_card
	and 
		melody_card1.melody_card_id=_card;



	update melody_card
	set 
		"name"=_row.name,
		creation_date=_row.creation_date,
		modification_date= now(),
		is_erotica=_row.is_erotica,
		is_free=_row.is_free,
		minimal_cost=_row.minimal_cost,
		lyrics=_row.lyrics,
		is_hit=_row.is_hit
	where 	melody_card.melody_card_id=_main_card;


	/* привязываем файлы */ 

_main1 = false;
--для каждого юзер_формата
        for _row in select distinct(cc.delivery_type_id),ct.user_format_id from card_file cf
join melody_file mf on cf.file_id=mf.melody_file_id 
join content_type ct on ct.content_type_id=mf.content_type_id
join file_content_code fcc on fcc.file_id=mf.melody_file_id
join content_code cc on fcc.content_code_id=cc.content_code_id
 where card_id = _main_card loop


-- среди кодов файлов главной карточки выбираем любой главный код остальные помечаем как неглавные
	for _code1 in select distinct(cc.content_code_id),cc.is_main  from card_file cf
join melody_file mf on cf.file_id=mf.melody_file_id 
join content_type ct on ct.content_type_id=mf.content_type_id
join file_content_code fcc on fcc.file_id=mf.melody_file_id
join content_code cc on fcc.content_code_id=cc.content_code_id
where card_id = _main_card and cc.delivery_type_id=_row.delivery_type_id and ct.user_format_id=_row.user_format_id and cc.is_main=true 
loop

	if (_main1) THEN

	update content_code set is_main=false where content_code_id=_code1.content_code_id;

	else

	 _main1=true;
	end if;

end loop;

-- если еще нет главного кода ищем среди кодов для второй карточки первый главный код, остальные назначаем неглавными
	for _code2 in select distinct(cc.content_code_id),cc.is_main  from card_file cf
join melody_file mf on cf.file_id=mf.melody_file_id 
join content_type ct on ct.content_type_id=mf.content_type_id
join file_content_code fcc on fcc.file_id=mf.melody_file_id
join content_code cc on fcc.content_code_id=cc.content_code_id
where card_id = _card and cc.delivery_type_id=_row.delivery_type_id and ct.user_format_id=_row.user_format_id and cc.is_main=true 
loop

	if (_main1) THEN
	update content_code set is_main=false where content_code_id=_code2.content_code_id;
	else
	 _main1=true;
	end if;
end loop;
_main1 = false;
end loop;

	

-- для рбт-файлов
--для каждого юзер_формата
        for _row in select distinct(cc.delivery_type_id),ct.user_format_id from card_file cf
join rbt_file mf on cf.file_id=mf.rbt_file_id 
join content_type ct on ct.content_type_id=mf.content_type_id
join file_content_code fcc on fcc.file_id=mf.rbt_file_id
join content_code cc on fcc.content_code_id=cc.content_code_id
 where card_id = _main_card loop
_main1 = false;
-- среди кодов файлов главной карточки выбираем любой главный код остальные помечаем как неглавные
	for _code1 in select distinct (cc.content_code_id),cc.is_main  from card_file cf
join rbt_file mf on cf.file_id=mf.rbt_file_id 
join content_type ct on ct.content_type_id=mf.content_type_id
join file_content_code fcc on fcc.file_id=mf.rbt_file_id
join content_code cc on fcc.content_code_id=cc.content_code_id
where card_id = _main_card and cc.delivery_type_id=_row.delivery_type_id and ct.user_format_id=_row.user_format_id and cc.is_main=true 
loop
	if (_main1) THEN
	update content_code set is_main=false where content_code_id=_code1.content_code_id;
	else
	 _main1=true;
	end if;

end loop;

-- если еще нет главного кода ищем среди кодов для второй карточки первый главный код, остальные назначаем неглавными
	for _code2 in select distinct(cc.content_code_id),cc.is_main  from card_file cf
join rbt_file mf on cf.file_id=mf.rbt_file_id 
join content_type ct on ct.content_type_id=mf.content_type_id
join file_content_code fcc on fcc.file_id=mf.rbt_file_id
join content_code cc on fcc.content_code_id=cc.content_code_id
where card_id = _card and cc.delivery_type_id=_row.delivery_type_id and ct.user_format_id=_row.user_format_id and cc.is_main=true 
loop
	if (_main1) THEN
	update content_code set is_main=false where content_code_id=_code2.content_code_id;
	else
	 _main1=true;
	end if;
end loop;
_main1 = false;
end loop;



for _row in select * from card_file where card_id=_card loop
		select count(*) into _count from card_file  where card_id=_main_card and file_id=_row.file_id;


		if _count>0 then
			delete from card_file where card_id=_card and file_id=_row.file_id;
		else
			update card_file set card_id=_main_card where card_id=_card and file_id=_row.file_id;
		end if;
	end loop;



        
	delete from melody_card where melody_card.melody_card_id=_card;

	
	update recycle set original_id=_main_card where original_id=_card;

	insert into recycle
	select _main_card,_card;

	return _main_card;
		
end;

/*
declare 
	_row record;
	_row_content_code record;
	_temp record;

	_count integer;
	_count1 integer;

	_main_card uuid;
	_card uuid;

begin


select count(*) into _count from melody_card where melody_card.melody_card_id=main_card;
select count(*) into _count1 from melody_card where melody_card.melody_card_id=card;

if (_count=0 and _count1=0) then 
	return '00000000-0000-0000-0000-000000000000';
end if;

if (_count=0 and _count1>0) then 
	return card;
end if;

if (_count>0 and _count1=0) then 
	return main_card;
end if;


select count(*) into _count from storefront.content where card_id=main_card;
select count(*) into _count1 from storefront.content where card_id=card;

if (_count >0 and _count1>0) then
	select * from storefront.join_melody_card(main_card,card) into _temp ;
end if;

select count(*) into _count from storefront.content where card_id=main_card;
select count(*) into _count1 from storefront.content where card_id=card;


_main_card=main_card;
_card=card;

if (_count=0 and _count1>0) then
	_main_card=card;
	_card=main_card;
end if;




	SELECT
		melody_card.melody_card_id,
		COALESCE(melody_card.name,melody_card1.name) as name,
		COALESCE(melody_card.creation_date,melody_card1.creation_date) as creation_date,
		COALESCE(melody_card.modification_date,melody_card1.modification_date) as modification_date,
		COALESCE(melody_card.is_erotica,melody_card1.is_erotica) as is_erotica,
		COALESCE(melody_card.is_free,melody_card1.is_free) as is_free,
		COALESCE(melody_card.minimal_cost,melody_card1.minimal_cost) as minimal_cost,
		COALESCE(melody_card.lyrics,melody_card1.lyrics) as lyrics,
		COALESCE(melody_card.is_hit,melody_card1.is_hit) as is_hit into _row
	from 
		melody_card ,
		melody_card melody_card1 
	where 
		melody_card.melody_card_id=_main_card
	and 
		melody_card1.melody_card_id=_card;



	update melody_card
	set 
		"name"=_row.name,
		creation_date=_row.creation_date,
		modification_date=_row.modification_date,
		is_erotica=_row.is_erotica,
		is_free=_row.is_free,
		minimal_cost=_row.minimal_cost,
		lyrics=_row.lyrics,
		is_hit=_row.is_hit
	where 	melody_card.melody_card_id=_main_card;


	/* привязываем файлы */ 
/*
	for _row in select * from card_file where card_id=_card loop
		select count(*) into _count from card_file  where card_id=_main_card and file_id=_row.file_id;


		if _count>0 then
			delete from card_file where card_id=_card and file_id=_row.file_id;
		else
			update card_file set card_id=_main_card where card_id=_card and file_id=_row.file_id;
		end if;
	end loop;

	delete from melody_card where melody_card.melody_card_id=_card;

	update recycle set original_id=_main_card where original_id=_card;

	insert into recycle
	select _main_card,_card;

	return _main_card;

		
end; 
*/
	
$$;

ALTER FUNCTION join_melody_card(UUID, UUID) OWNER TO postgres;

