CREATE FUNCTION process_availability_content_code_changes() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        insert into availability.change_log(content_code_id) values(OLD.content_code_id);
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        insert into availability.change_log(content_code_id) values(OLD.content_code_id);
        insert into availability.change_log(content_code_id) values(NEW.content_code_id);
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        insert into availability.change_log(content_code_id) values(NEW.content_code_id);
        RETURN NEW;
    END IF;    
END;
$$;

ALTER FUNCTION process_availability_content_code_changes() OWNER TO postgres;

