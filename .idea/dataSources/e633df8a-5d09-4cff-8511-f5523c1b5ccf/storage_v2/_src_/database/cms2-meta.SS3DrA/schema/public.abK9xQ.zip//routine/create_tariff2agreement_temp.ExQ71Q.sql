CREATE FUNCTION create_tariff2agreement_temp() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
begin


SELECT  count(*) into _count
FROM 
	pg_class c
	JOIN pg_namespace ns ON (c.relnamespace = ns.oid) 
	WHERE
		relkind ='r' and nspname NOT IN ('pg_catalog', 'pg_toast','information_schema') and relname='tariff2agreement_new';
		

--RAISE EXCEPTION '%',_count;

IF (_count<>0) THEN
	DROP TABLE tariff2agreement_new;
END IF;		

CREATE TABLE tariff2agreement_new
(
  content_sale2point integer NOT NULL,
  agreement integer NOT NULL,
  uri character varying(500),
  device integer,
  tariff_code character varying(10)
);
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tariff2agreement_new TO inform;
EXECUTE 'COMMENT ON TABLE tariff2agreement_new IS ''creation date: ' || now()::varchar || '''';

end;
$$;

ALTER FUNCTION create_tariff2agreement_temp() OWNER TO postgres;

