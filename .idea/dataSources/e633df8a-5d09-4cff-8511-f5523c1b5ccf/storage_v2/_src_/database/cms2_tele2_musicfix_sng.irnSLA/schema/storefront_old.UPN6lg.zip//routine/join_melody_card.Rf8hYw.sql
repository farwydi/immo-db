CREATE FUNCTION join_melody_card(_main_card uuid, _card uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;_row_content_code record;_count integer;begin

	update content set card_id=_main_card where card_id=_card;update section_top_content set card_id=_main_card where card_id=_card;update section_daily_content set card_id=_main_card where card_id=_card;for _row in select distinct user_format_id from content where card_id=_main_card loop
		_count=0;for _row_content_code in select distinct content_code,content_code::int4 as code_int 
						from content 
						where card_id=_main_card and user_format_id=_row.user_format_id
						order by code_int desc loop
			if _count=0 then
				_count=_count+1;else
				delete from content where content_code=_row_content_code.content_code;end if;end loop;end loop;delete from melody_card_artist where  card_id=_card;delete from melody_card_album where  card_id=_card;delete from melody_card_author_lyrics where  card_id=_card;delete from melody_card_composer where  card_id=_card;end;
$$;

ALTER FUNCTION join_melody_card(UUID, UUID) OWNER TO postgres;

