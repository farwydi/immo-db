CREATE FUNCTION bit_length(text) RETURNS integer
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	COST 1
	LANGUAGE sql
AS
$$
select pg_catalog.octet_length($1) * 8
$$;

COMMENT ON FUNCTION bit_length(TEXT) IS 'length in bits';

ALTER FUNCTION bit_length(TEXT) OWNER TO postgres;

