CREATE FUNCTION date_part(text, abstime) RETURNS double precision
	STABLE
	STRICT
	PARALLEL SAFE
	COST 1
	LANGUAGE sql
AS
$$
select pg_catalog.date_part($1, cast($2 as timestamp with time zone))
$$;

COMMENT ON FUNCTION date_part(TEXT, ABSTIME) IS 'extract field from abstime';

ALTER FUNCTION date_part(TEXT, ABSTIME) OWNER TO postgres;

