CREATE FUNCTION conflicted_triggers(oid) RETURNS SETOF name
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT tgname FROM pg_trigger
 WHERE tgrelid = $1 AND tgname = 'repack_trigger'
 ORDER BY tgname;
$$;

ALTER FUNCTION conflicted_triggers(OID) OWNER TO postgres;

