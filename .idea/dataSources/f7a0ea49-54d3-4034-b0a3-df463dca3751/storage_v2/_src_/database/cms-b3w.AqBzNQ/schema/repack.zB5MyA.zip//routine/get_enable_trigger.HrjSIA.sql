CREATE FUNCTION get_enable_trigger(relid oid) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT 'ALTER TABLE ' || repack.oid2text($1) ||
    ' ENABLE ALWAYS TRIGGER repack_trigger';
$$;

ALTER FUNCTION get_enable_trigger(OID) OWNER TO postgres;

