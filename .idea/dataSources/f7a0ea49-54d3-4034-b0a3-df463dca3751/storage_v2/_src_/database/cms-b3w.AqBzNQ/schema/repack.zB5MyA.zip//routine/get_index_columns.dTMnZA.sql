CREATE FUNCTION get_index_columns(oid, text) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT array_to_string(repack.array_accum(quote_ident(attname)), $2)
    FROM pg_attribute,
         (SELECT indrelid,
                 indkey,
                 generate_series(0, indnatts-1) AS i
            FROM pg_index
           WHERE indexrelid = $1
         ) AS keys
   WHERE attrelid = indrelid
     AND attnum = indkey[i];
$$;

ALTER FUNCTION get_index_columns(OID, TEXT) OWNER TO postgres;

