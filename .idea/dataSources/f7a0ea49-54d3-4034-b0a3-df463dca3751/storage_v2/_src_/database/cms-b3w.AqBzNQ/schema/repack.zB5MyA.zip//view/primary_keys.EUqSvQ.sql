CREATE VIEW primary_keys(indrelid, indexrelid) AS
SELECT tmp.indrelid,
	   (repack.array_accum(tmp.indexrelid))[1] AS indexrelid
FROM (SELECT pg_index.indrelid,
			 pg_index.indexrelid
	  FROM pg_index
	  WHERE pg_index.indisunique
		AND pg_index.indisvalid
		AND pg_index.indpred IS NULL
		AND (0 <> ALL (pg_index.indkey::SMALLINT[]))
		AND NOT (EXISTS(SELECT 1
						FROM pg_attribute
						WHERE pg_attribute.attrelid = pg_index.indrelid
						  AND (pg_attribute.attnum = ANY (pg_index.indkey::SMALLINT[]))
						  AND NOT pg_attribute.attnotnull))
	  ORDER BY pg_index.indrelid, pg_index.indisprimary DESC, pg_index.indnatts, pg_index.indkey) tmp
GROUP BY tmp.indrelid;

ALTER TABLE primary_keys
	OWNER TO postgres;

