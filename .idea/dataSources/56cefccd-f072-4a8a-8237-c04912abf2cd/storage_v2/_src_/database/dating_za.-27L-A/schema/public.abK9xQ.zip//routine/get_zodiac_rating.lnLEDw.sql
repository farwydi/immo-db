CREATE FUNCTION get_zodiac_rating("personZodiac" integer, "partnerZodiac" integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
rate integer;
begin
select rating into rate 
from compratings 
where ((personid="personZodiac" and partnerid="partnerZodiac") or (partnerid="personZodiac" and personid="partnerZodiac"));
return rate;
end;
$$;

ALTER FUNCTION get_zodiac_rating(INTEGER, INTEGER) OWNER TO postgres;

