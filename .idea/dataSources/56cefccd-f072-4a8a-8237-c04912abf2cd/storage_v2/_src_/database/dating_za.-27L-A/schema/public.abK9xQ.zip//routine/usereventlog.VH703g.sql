CREATE FUNCTION usereventlog() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
    IF TG_TABLE_NAME = 'message' THEN
        INSERT INTO user_event_log (src_user_id, dst_user_id, "type") VALUES (new.user_from, new.user_to, 'message');
    END IF;
    RETURN NULL;
END;
$$;

ALTER FUNCTION usereventlog() OWNER TO postgres;

