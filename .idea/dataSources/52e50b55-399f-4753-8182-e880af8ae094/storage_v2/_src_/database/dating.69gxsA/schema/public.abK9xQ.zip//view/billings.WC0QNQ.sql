CREATE VIEW billings(msisdn, real_datetime) AS
(SELECT DISTINCT ON (billing.msisdn) billing.msisdn,
									 billing.real_datetime
 FROM billing
 WHERE billing.real_datetime >= (NOW()::DATE - '1 day'::INTERVAL)
 ORDER BY billing.msisdn, billing.real_datetime DESC)
UNION ALL
(SELECT DISTINCT ON (billing_velcom.msisdn) billing_velcom.msisdn,
											billing_velcom.real_datetime
 FROM billing_velcom
 WHERE billing_velcom.real_datetime >= (NOW()::DATE - '1 day'::INTERVAL)
 ORDER BY billing_velcom.msisdn, billing_velcom.real_datetime DESC)
UNION ALL
(SELECT DISTINCT ON (billing_history_life.msisdn) billing_history_life.msisdn,
												  billing_history_life.create_date AS real_datetime
 FROM billing_history_life
 WHERE billing_history_life.create_date >= (NOW()::DATE - '1 day'::INTERVAL)
 ORDER BY billing_history_life.msisdn, billing_history_life.create_date DESC);

ALTER TABLE billings
	OWNER TO postgres;

