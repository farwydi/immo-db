CREATE MATERIALIZED VIEW tele2_subs_preset_view AS
SELECT tele2_subs_preset.id,
	   tele2_subs_preset.record_date,
	   tele2_subs_preset.serviceid,
	   tele2_subs_preset.context,
	   tele2_subs_preset.new_ondate,
	   tele2_subs_preset.exit_ondate,
	   tele2_subs_preset.active_ondate,
	   tele2_subs_preset.activate_ondate,
	   tele2_subs_preset.deactivate_ondate,
	   tele2_subs_preset.prolong_ondate,
	   tele2_subs_preset.activated_total_ondate
FROM tele2_subs_preset
WHERE tele2_subs_preset.record_date >= (NOW() - '1 mon'::INTERVAL)::DATE;

ALTER MATERIALIZED VIEW tele2_subs_preset_view OWNER TO inform;

CREATE UNIQUE INDEX preset_view_idx
	ON tele2_subs_preset_view (id);

CREATE INDEX tele2_subs_preset_view_idx
	ON tele2_subs_preset_view (record_date, serviceid, context);

