CREATE VIEW ad_promo_partner_stat_old_view
			(stat_id, partner_id, service_id, action, msisdn, record_date, operator, click_params, fee, eup, currency,
			 click_id, status, lpcontext, event_datetime, external_id)
AS
SELECT ad_promo_partner_stat_arch.stat_id,
	   ad_promo_partner_stat_arch.partner_id,
	   ad_promo_partner_stat_arch.service_id,
	   ad_promo_partner_stat_arch.action,
	   ad_promo_partner_stat_arch.msisdn,
	   ad_promo_partner_stat_arch.record_date,
	   ad_promo_partner_stat_arch.operator,
	   ad_promo_partner_stat_arch.click_params,
	   ad_promo_partner_stat_arch.fee,
	   ad_promo_partner_stat_arch.eup,
	   ad_promo_partner_stat_arch.currency,
	   ad_promo_partner_stat_arch.click_id,
	   ad_promo_partner_stat_arch.status,
	   ad_promo_partner_stat_arch.lpcontext,
	   ad_promo_partner_stat_arch.event_datetime,
	   ad_promo_partner_stat_arch.external_id
FROM ad_promo_partner_stat_arch
UNION
SELECT ad_promo_partner_stat.stat_id,
	   ad_promo_partner_stat.partner_id,
	   ad_promo_partner_stat.service_id,
	   ad_promo_partner_stat.action,
	   ad_promo_partner_stat.msisdn,
	   ad_promo_partner_stat.record_date,
	   ad_promo_partner_stat.operator,
	   ad_promo_partner_stat.click_params,
	   ad_promo_partner_stat.fee,
	   ad_promo_partner_stat.eup,
	   ad_promo_partner_stat.currency,
	   ad_promo_partner_stat.click_id,
	   ad_promo_partner_stat.status,
	   ad_promo_partner_stat.lpcontext,
	   ad_promo_partner_stat.event_datetime,
	   ad_promo_partner_stat.external_id
FROM ad_promo_partner_stat;

ALTER TABLE ad_promo_partner_stat_old_view
	OWNER TO inform;

