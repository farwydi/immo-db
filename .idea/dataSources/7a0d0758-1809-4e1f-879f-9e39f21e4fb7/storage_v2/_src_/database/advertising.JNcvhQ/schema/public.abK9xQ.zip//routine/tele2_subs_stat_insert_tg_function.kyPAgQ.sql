CREATE FUNCTION tele2_subs_stat_insert_tg_function() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN 
    IF (NEW.status = 'new') THEN
        INSERT INTO tele2_subs_stat_new VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (NEW.status = 'exit') THEN
        INSERT INTO tele2_subs_stat_exit VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (NEW.status != 'prolong') THEN
        INSERT INTO tele2_subs_stat_other VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 1) THEN
        INSERT INTO tele2_subs_stat_prolong_1 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 2) THEN
        INSERT INTO tele2_subs_stat_prolong_2 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 3) THEN
        INSERT INTO tele2_subs_stat_prolong_3 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 4) THEN
        INSERT INTO tele2_subs_stat_prolong_4 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 5) THEN
        INSERT INTO tele2_subs_stat_prolong_5 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 6) THEN
        INSERT INTO tele2_subs_stat_prolong_6 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 7) THEN
        INSERT INTO tele2_subs_stat_prolong_7 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 8) THEN
        INSERT INTO tele2_subs_stat_prolong_8 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 9) THEN
        INSERT INTO tele2_subs_stat_prolong_9 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 10) THEN
        INSERT INTO tele2_subs_stat_prolong_10 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 11) THEN
        INSERT INTO tele2_subs_stat_prolong_11 VALUES(NEW.*);
        RETURN NULL;
    END IF;

    IF (date_part('month', NEW.record_date)::integer = 12) THEN
        INSERT INTO tele2_subs_stat_prolong_12 VALUES(NEW.*);
        RETURN NULL;
    END IF;
    
    RAISE EXCEPTION 'Wrong record_date';
END
$$;

ALTER FUNCTION tele2_subs_stat_insert_tg_function() OWNER TO inform;

