CREATE VIEW ad_promo_partner_stat_act_lastmonth_view
			(record_date, total, partner_name, name_new, operator_name, country, ptype) AS
SELECT p.record_date,
	   SUM(p.activated_total_ondate) AS total,
	   CASE
		   WHEN part.partner_name IS NULL THEN 'IMMO'::CHARACTER VARYING
		   ELSE part.partner_name
		   END                       AS partner_name,
	   s.name_new,
	   s.operator_name,
	   s.country,
	   part.ptype
FROM tele2_subs_preset_view p
		 JOIN tele2_subs_services s USING (serviceid)
		 LEFT JOIN ad_promo_partners_by_type_view part USING (context, serviceid)
WHERE p.record_date >= (DATE_TRUNC('week'::TEXT, NOW()::DATE::TIMESTAMP WITH TIME ZONE) - '1 mon'::INTERVAL)
GROUP BY p.record_date,
		 CASE
			 WHEN part.partner_name IS NULL THEN 'IMMO'::CHARACTER VARYING
			 ELSE part.partner_name
			 END, s.name_new, s.operator_name, s.country, part.ptype
HAVING SUM(p.activated_total_ondate) > 0::NUMERIC
ORDER BY p.record_date,
		 CASE
			 WHEN part.partner_name IS NULL THEN 'IMMO'::CHARACTER VARYING
			 ELSE part.partner_name
			 END, s.name_new, s.operator_name, s.country, part.ptype;

ALTER TABLE ad_promo_partner_stat_act_lastmonth_view
	OWNER TO inform;

