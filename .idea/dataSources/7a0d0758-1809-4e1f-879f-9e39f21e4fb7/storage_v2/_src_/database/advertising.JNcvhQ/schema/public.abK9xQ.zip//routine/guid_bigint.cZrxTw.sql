CREATE FUNCTION guid_bigint(text) RETURNS bigint
	LANGUAGE plpgsql
AS
$$
DECLARE
    guid bigint;
BEGIN
    guid = abs(('x' || substr(md5($1), 1, 16))::bit(64)::bigint);
    RETURN guid;
END;
$$;

ALTER FUNCTION guid_bigint(TEXT) OWNER TO postgres;

