CREATE VIEW ad_promo_partners_by_type_view(context, partner_id, serviceid, partner_name, ptype) AS
SELECT DISTINCT pdist.context,
				pdist.partner_id,
				pdist.serviceid,
				partners.name AS partner_name,
				pdist.ptype
FROM (SELECT DISTINCT ad_promo_partner_pilot_rules.context,
					  ad_promo_partner_pilot_rules.partner_id,
					  ad_promo_partner_pilot_rules.service_id AS serviceid,
					  'cpa'::TEXT                             AS ptype
	  FROM ad_promo_partner_pilot_rules
	  UNION
	  SELECT DISTINCT ad_promo_partner_services.lpcontext  AS context,
					  ad_promo_partner_services.partner_id,
					  ad_promo_partner_services.service_id AS serviceid,
					  'rebill'::TEXT                       AS ptype
	  FROM ad_promo_partner_services
	  WHERE ad_promo_partner_services.is_active = TRUE) pdist
		 LEFT JOIN ad_promo_partner partners USING (partner_id);

ALTER TABLE ad_promo_partners_by_type_view
	OWNER TO inform;

