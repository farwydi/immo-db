CREATE VIEW ad_promo_partner_pilot_2weeks_view(name, operator_name, week1, week2, acttotal) AS
SELECT t.name,
	   t.operator_name,
	   SUM(
			   CASE
				   WHEN t.weekn = DATE_PART('week'::TEXT,
											DATE_TRUNC('week'::TEXT, NOW()::DATE::TIMESTAMP WITH TIME ZONE) -
											'14 days'::INTERVAL) THEN t.total
				   ELSE 0::NUMERIC
				   END) AS week1,
	   SUM(
			   CASE
				   WHEN t.weekn = DATE_PART('week'::TEXT,
											DATE_TRUNC('week'::TEXT, NOW()::DATE::TIMESTAMP WITH TIME ZONE) -
											'7 days'::INTERVAL) THEN t.total
				   ELSE 0::NUMERIC
				   END) AS week2,
	   SUM(t.total)     AS acttotal
FROM (SELECT DATE_PART('week'::TEXT, tele2_subs_preset.record_date) AS weekn,
			 tele2_subs_preset.name_new,
			 tele2_subs_preset.operator_name,
			 tele2_subs_preset.partner_name                         AS name,
			 SUM(tele2_subs_preset.total)                           AS total
	  FROM ad_promo_partner_stat_act_last2weeks_view tele2_subs_preset
	  WHERE tele2_subs_preset.record_date >=
			(DATE_TRUNC('week'::TEXT, NOW()::DATE::TIMESTAMP WITH TIME ZONE) - '14 days'::INTERVAL)
		AND tele2_subs_preset.record_date < DATE_TRUNC('week'::TEXT, NOW())
	  GROUP BY DATE_PART('week'::TEXT, tele2_subs_preset.record_date), tele2_subs_preset.operator_name,
			   tele2_subs_preset.name_new, tele2_subs_preset.partner_name
	  ORDER BY DATE_PART('week'::TEXT, tele2_subs_preset.record_date), tele2_subs_preset.operator_name,
			   tele2_subs_preset.name_new, tele2_subs_preset.partner_name) t
GROUP BY t.name, t.operator_name
ORDER BY t.name, t.operator_name;

ALTER TABLE ad_promo_partner_pilot_2weeks_view
	OWNER TO inform;

