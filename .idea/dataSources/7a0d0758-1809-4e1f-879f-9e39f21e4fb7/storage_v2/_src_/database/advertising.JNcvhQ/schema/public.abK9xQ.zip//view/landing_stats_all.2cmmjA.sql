CREATE VIEW landing_stats_all
			(id, record_date, msisdn, key, context, profile_id, param1, action_id, params, param2, param3,
			 subscription_id, ref_site, os, browser, ad, lpid, upload_ch)
AS
SELECT landing_stats.id,
	   landing_stats.record_date,
	   landing_stats.msisdn,
	   landing_stats.key,
	   landing_stats.context,
	   landing_stats.profile_id,
	   landing_stats.param1,
	   landing_stats.action_id,
	   landing_stats.params,
	   landing_stats.param2,
	   landing_stats.param3,
	   landing_stats.subscription_id,
	   landing_stats.ref_site,
	   landing_stats.os,
	   landing_stats.browser,
	   landing_stats.ad,
	   landing_stats.lpid,
	   landing_stats.upload_ch
FROM landing_stats;

ALTER TABLE landing_stats_all
	OWNER TO inform;

