CREATE VIEW pg_policies (schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check) AS
SELECT n.nspname                                   AS schemaname,
	   c.relname                                   AS tablename,
	   pol.polname                                 AS policyname,
	   CASE
		   WHEN pol.polpermissive THEN 'PERMISSIVE'::TEXT
		   ELSE 'RESTRICTIVE'::TEXT
		   END                                     AS permissive,
	   CASE
		   WHEN pol.polroles = '{0}'::OID[] THEN STRING_TO_ARRAY('public'::TEXT, ''::TEXT)::NAME[]
		   ELSE ARRAY(SELECT pg_authid.rolname
					  FROM pg_authid
					  WHERE pg_authid.oid = ANY (pol.polroles)
					  ORDER BY pg_authid.rolname)
		   END                                     AS roles,
	   CASE pol.polcmd
		   WHEN 'r'::"char" THEN 'SELECT'::TEXT
		   WHEN 'a'::"char" THEN 'INSERT'::TEXT
		   WHEN 'w'::"char" THEN 'UPDATE'::TEXT
		   WHEN 'd'::"char" THEN 'DELETE'::TEXT
		   WHEN '*'::"char" THEN 'ALL'::TEXT
		   ELSE NULL::TEXT
		   END                                     AS cmd,
	   PG_GET_EXPR(pol.polqual, pol.polrelid)      AS qual,
	   PG_GET_EXPR(pol.polwithcheck, pol.polrelid) AS with_check
FROM pg_policy pol
		 JOIN pg_class c ON c.oid = pol.polrelid
		 LEFT JOIN pg_namespace n ON n.oid = c.relnamespace;

ALTER TABLE pg_policies
	OWNER TO postgres;

