CREATE FUNCTION pg_stat_repl() RETURNS SETOF pg_stat_replication
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
begin return query(select * from pg_catalog.pg_stat_replication); end
$$;

ALTER FUNCTION pg_stat_repl() OWNER TO postgres;

