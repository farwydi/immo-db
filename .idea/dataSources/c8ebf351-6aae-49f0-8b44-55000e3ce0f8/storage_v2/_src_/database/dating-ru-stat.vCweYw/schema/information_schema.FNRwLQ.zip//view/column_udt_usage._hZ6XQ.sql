CREATE VIEW column_udt_usage
			(udt_catalog, udt_schema, udt_name, table_catalog, table_schema, table_name, column_name) AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                AS udt_catalog,
	   COALESCE(nbt.nspname, nt.nspname)::information_schema.SQL_IDENTIFIER AS udt_schema,
	   COALESCE(bt.typname, t.typname)::information_schema.SQL_IDENTIFIER   AS udt_name,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                AS table_catalog,
	   nc.nspname::information_schema.SQL_IDENTIFIER                        AS table_schema,
	   c.relname::information_schema.SQL_IDENTIFIER                         AS table_name,
	   a.attname::information_schema.SQL_IDENTIFIER                         AS column_name
FROM pg_attribute a,
	 pg_class c,
	 pg_namespace nc,
	 pg_type t
		 JOIN pg_namespace nt ON t.typnamespace = nt.oid
		 LEFT JOIN (pg_type bt
		 JOIN pg_namespace nbt ON bt.typnamespace = nbt.oid) ON t.typtype = 'd'::"char" AND t.typbasetype = bt.oid
WHERE a.attrelid = c.oid
  AND a.atttypid = t.oid
  AND nc.oid = c.relnamespace
  AND a.attnum > 0
  AND NOT a.attisdropped
  AND (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  AND PG_HAS_ROLE(COALESCE(bt.typowner, t.typowner), 'USAGE'::TEXT);

ALTER TABLE column_udt_usage
	OWNER TO postgres;

