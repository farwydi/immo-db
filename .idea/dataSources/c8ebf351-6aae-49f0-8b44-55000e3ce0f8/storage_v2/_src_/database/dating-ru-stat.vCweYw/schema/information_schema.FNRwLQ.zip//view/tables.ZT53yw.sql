CREATE VIEW tables
			(table_catalog, table_schema, table_name, table_type, self_referencing_column_name, reference_generation,
			 user_defined_type_catalog, user_defined_type_schema, user_defined_type_name, is_insertable_into, is_typed,
			 commit_action)
AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER      AS table_catalog,
	   nc.nspname::information_schema.SQL_IDENTIFIER              AS table_schema,
	   c.relname::information_schema.SQL_IDENTIFIER               AS table_name,
	   CASE
		   WHEN nc.oid = PG_MY_TEMP_SCHEMA() THEN 'LOCAL TEMPORARY'::TEXT
		   WHEN c.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]) THEN 'BASE TABLE'::TEXT
		   WHEN c.relkind = 'v'::"char" THEN 'VIEW'::TEXT
		   WHEN c.relkind = 'f'::"char" THEN 'FOREIGN TABLE'::TEXT
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA                 AS table_type,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER AS self_referencing_column_name,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA AS reference_generation,
	   CASE
		   WHEN t.typname IS NOT NULL THEN CURRENT_DATABASE()
		   ELSE NULL::NAME
		   END::information_schema.SQL_IDENTIFIER                 AS user_defined_type_catalog,
	   nt.nspname::information_schema.SQL_IDENTIFIER              AS user_defined_type_schema,
	   t.typname::information_schema.SQL_IDENTIFIER               AS user_defined_type_name,
	   CASE
		   WHEN (c.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"])) OR
				(c.relkind = ANY (ARRAY ['v'::"char", 'f'::"char"])) AND
				(pg_relation_is_updatable(c.oid::REGCLASS, FALSE) & 8) = 8 THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                      AS is_insertable_into,
	   CASE
		   WHEN t.typname IS NOT NULL THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                      AS is_typed,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA AS commit_action
FROM pg_namespace nc
		 JOIN pg_class c ON nc.oid = c.relnamespace
		 LEFT JOIN (pg_type t
	JOIN pg_namespace nt ON t.typnamespace = nt.oid) ON c.reloftype = t.oid
WHERE (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  AND NOT PG_IS_OTHER_TEMP_SCHEMA(nc.oid)
  AND (PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT) OR
	   HAS_TABLE_PRIVILEGE(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
	   HAS_ANY_COLUMN_PRIVILEGE(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE tables
	OWNER TO postgres;

