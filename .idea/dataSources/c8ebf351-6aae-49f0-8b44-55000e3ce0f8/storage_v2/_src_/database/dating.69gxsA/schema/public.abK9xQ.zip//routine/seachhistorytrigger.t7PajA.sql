CREATE FUNCTION seachhistorytrigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE rec RECORD;
    DECLARE rec2 RECORD;
    DECLARE rec3 RECORD;
    DECLARE buf int[];
    BEGIN
    
        SELECT 1 as "cnt"  FROM search_interests 
        WHERE 	user_id = NEW.user_id 
		and sex = CASE WHEN NEW.sex='0000000000000000000000001' THEN 1 ELSE 2 END
		and city_id = NEW.city
		and age_from <= CASE WHEN NEW.birthday_right IS NULL THEN 0 ELSE extract(year from age(NEW.birthday_right)) END
		and age_to >= CASE WHEN NEW.birthday_left IS NULL THEN 100 ELSE extract(year from age(NEW.birthday_left)) END
        LIMIT 1 
		INTO rec;
        
	RAISE NOTICE 'Rows found: %i', (rec IS NOT NULL);

	IF (rec IS NULL) THEN
		SELECT MAX(COALESCE(birthday_right, current_date)) as birthday_right FROM "search" WHERE user_id = NEW.user_id
			INTO rec2;
		SELECT MIN(COALESCE(birthday_left, current_date - interval '100 year')) as birthday_left FROM "search" WHERE user_id = NEW.user_id
			INTO rec3;
		buf = Array[
			NEW.user_id, 
			extract(year from age(rec2.birthday_right)), 
			extract(year from age(rec3.birthday_left))
		];
	
		DELETE FROM search_interests WHERE user_id = NEW.user_id;
		INSERT INTO search_interests	
			SELECT buf[1], s1.sex, s2.city, buf[2], buf[3]
			FROM (
				SELECT CASE WHEN sex='0000000000000000000000001' THEN 1 ELSE 2 END as sex
				FROM "search" WHERE user_id = NEW.user_id
				GROUP BY sex
			) s1
			CROSS JOIN (
				SELECT city
				FROM "search" WHERE user_id = NEW.user_id
				GROUP BY city
			) s2;
	END IF;

    RETURN NULL;
END;
$$;

ALTER FUNCTION seachhistorytrigger() OWNER TO postgres;

