CREATE FUNCTION bittobool(bit) RETURNS boolean
	LANGUAGE sql
AS
$$
SELECT CASE WHEN $1::int = 0

THEN false

ELSE true

END;
$$;

ALTER FUNCTION bittobool(BIT) OWNER TO postgres;

