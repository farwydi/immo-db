CREATE FUNCTION birthdaymd(birthday date) RETURNS integer
	IMMUTABLE
	STRICT
	LANGUAGE plpgsql
AS
$$
BEGIN
 RETURN extract(month from (birthday))*100 + extract(day from (birthday));
END
$$;

ALTER FUNCTION birthdaymd(DATE) OWNER TO postgres;

