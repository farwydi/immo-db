CREATE FUNCTION get_assign(oid, text) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT '(' || array_to_string(repack.array_accum(quote_ident(attname)), ', ') ||
         ') = (' || $2 || '.' ||
         array_to_string(repack.array_accum(quote_ident(attname)), ', ' || $2 || '.') || ')'
    FROM (SELECT attname FROM pg_attribute
           WHERE attrelid = $1 AND attnum > 0 AND NOT attisdropped
           ORDER BY attnum) tmp;
$$;

ALTER FUNCTION get_assign(OID, TEXT) OWNER TO postgres;

