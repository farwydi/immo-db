CREATE VIEW replication_status
			(primary_node_id, standby_node_id, standby_name, node_type, active, last_monitor_time,
			 last_wal_primary_location, last_wal_standby_location, replication_lag, replication_time_lag, apply_lag,
			 communication_time_lag)
AS
SELECT m.primary_node_id,
	   m.standby_node_id,
	   n.node_name  AS standby_name,
	   n.type       AS node_type,
	   n.active,
	   m.last_monitor_time,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN m.last_wal_primary_location
		   ELSE NULL::PG_LSN
		   END      AS last_wal_primary_location,
	   m.last_wal_standby_location,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN PG_SIZE_PRETTY(m.replication_lag)
		   ELSE NULL::TEXT
		   END      AS replication_lag,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN
			   CASE
				   WHEN m.replication_lag > 0 THEN AGE(NOW(), m.last_apply_time)
				   ELSE '00:00:00'::INTERVAL
				   END
		   ELSE NULL::INTERVAL
		   END      AS replication_time_lag,
	   CASE
		   WHEN n.type = 'standby'::TEXT THEN PG_SIZE_PRETTY(m.apply_lag)
		   ELSE NULL::TEXT
		   END      AS apply_lag,
	   AGE(NOW(),
		   CASE
			   WHEN PG_IS_IN_RECOVERY() THEN repmgr.standby_get_last_updated()
			   ELSE m.last_monitor_time
			   END) AS communication_time_lag
FROM repmgr.monitoring_history m
		 JOIN repmgr.nodes n ON m.standby_node_id = n.node_id
WHERE ((m.standby_node_id, m.last_monitor_time) IN (SELECT m1.standby_node_id,
														   MAX(m1.last_monitor_time) AS max
													FROM repmgr.monitoring_history m1
													GROUP BY m1.standby_node_id));

ALTER TABLE replication_status
	OWNER TO repmgr_usr;

