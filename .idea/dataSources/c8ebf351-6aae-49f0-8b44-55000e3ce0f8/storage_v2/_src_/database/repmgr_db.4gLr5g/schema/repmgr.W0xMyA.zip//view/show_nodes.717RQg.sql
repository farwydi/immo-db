CREATE VIEW show_nodes (node_id, node_name, active, upstream_node_id, upstream_node_name, type, priority, conninfo) AS
SELECT n.node_id,
	   n.node_name,
	   n.active,
	   n.upstream_node_id,
	   un.node_name AS upstream_node_name,
	   n.type,
	   n.priority,
	   n.conninfo
FROM repmgr.nodes n
		 LEFT JOIN repmgr.nodes un ON un.node_id = n.upstream_node_id;

ALTER TABLE show_nodes
	OWNER TO repmgr_usr;

