CREATE RULE voting_term_delete AS
    ON DELETE TO repmgr.voting_term DO INSTEAD NOTHING;

