CREATE FUNCTION earth_radius() RETURNS integer
	LANGUAGE plpgsql
AS
$$
BEGIN
				RETURN 6371;
				END;

$$;

ALTER FUNCTION earth_radius() OWNER TO postgres;

