CREATE FUNCTION oid2text(oid) RETURNS text
	STABLE
	STRICT
	SET search_path = pg_catalog
	LANGUAGE sql
AS
$$
SELECT textin(regclassout($1));
$$;

ALTER FUNCTION oid2text(OID) OWNER TO postgres;

