CREATE VIEW constraint_table_usage
			(table_catalog, table_schema, table_name, constraint_catalog, constraint_schema, constraint_name) AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS table_catalog,
	   nr.nspname::information_schema.SQL_IDENTIFIER         AS table_schema,
	   r.relname::information_schema.SQL_IDENTIFIER          AS table_name,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
	   nc.nspname::information_schema.SQL_IDENTIFIER         AS constraint_schema,
	   c.conname::information_schema.SQL_IDENTIFIER          AS constraint_name
FROM pg_constraint c,
	 pg_namespace nc,
	 pg_class r,
	 pg_namespace nr
WHERE c.connamespace = nc.oid
  AND r.relnamespace = nr.oid
  AND (c.contype = 'f'::"char" AND c.confrelid = r.oid OR
	   (c.contype = ANY (ARRAY ['p'::"char", 'u'::"char"])) AND c.conrelid = r.oid)
  AND (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]))
  AND PG_HAS_ROLE(r.relowner, 'USAGE'::TEXT);

ALTER TABLE constraint_table_usage
	OWNER TO postgres;

