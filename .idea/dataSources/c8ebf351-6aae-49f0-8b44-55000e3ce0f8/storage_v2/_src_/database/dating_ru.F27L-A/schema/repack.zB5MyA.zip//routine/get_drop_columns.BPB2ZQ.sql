CREATE FUNCTION get_drop_columns(oid, text) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT
	'ALTER TABLE ' || $2 || ' ' || array_to_string(dropped_columns, ', ')
FROM (
	SELECT
		repack.array_accum('DROP COLUMN ' || quote_ident(attname)) AS dropped_columns
	FROM (
		SELECT * FROM pg_attribute
		WHERE attrelid = $1 AND attnum > 0 AND attisdropped
		ORDER BY attnum
	) T
) T
WHERE
	array_upper(dropped_columns, 1) > 0
$$;

ALTER FUNCTION get_drop_columns(OID, TEXT) OWNER TO postgres;

