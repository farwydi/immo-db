CREATE FUNCTION get_columns_for_create_as(oid) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT array_to_string(repack.array_accum(c), ',') FROM (SELECT
	CASE WHEN attisdropped
		THEN 'NULL::integer AS ' || quote_ident(attname)
		ELSE quote_ident(attname)
	END AS c
FROM pg_attribute
WHERE attrelid = $1 AND attnum > 0 ORDER BY attnum
) AS COL
$$;

ALTER FUNCTION get_columns_for_create_as(OID) OWNER TO postgres;

