CREATE FUNCTION get_create_index_type(oid, name) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
SELECT 'CREATE TYPE ' || $2 || ' AS (' ||
         array_to_string(repack.array_accum(quote_ident(attname) || ' ' ||
           pg_catalog.format_type(atttypid, atttypmod)), ', ') || ')'
    FROM pg_attribute,
         (SELECT indrelid,
                 indkey,
                 generate_series(0, indnatts-1) AS i
            FROM pg_index
           WHERE indexrelid = $1
         ) AS keys
   WHERE attrelid = indrelid
     AND attnum = indkey[i];
$$;

ALTER FUNCTION get_create_index_type(OID, NAME) OWNER TO postgres;

