CREATE FUNCTION distance_in_km(lat1 integer, lon1 integer, lat2 integer, lon2 integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
DECLARE
			    lat1_r FLOAT := radians(lat1::float / 10000);
			    lon1_r FLOAT := radians(lon1::float / 10000);
			    lat2_r FLOAT := radians(lat2::float / 10000);
			    lon2_r FLOAT := radians(lon2::float / 10000);
			BEGIN
			
				RETURN (earth_radius() * arc_heaver_sin(heaver_sin(abs(lat1_r-lat2_r)) + cos(lat1_r)*cos(lat2_r)*heaver_sin(abs(lon1_r - lon2_r))))::integer;
				END;

$$;

ALTER FUNCTION distance_in_km(INTEGER, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

