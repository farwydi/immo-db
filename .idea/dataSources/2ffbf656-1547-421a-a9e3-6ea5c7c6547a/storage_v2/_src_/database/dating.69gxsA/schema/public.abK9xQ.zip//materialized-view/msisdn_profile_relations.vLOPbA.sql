CREATE MATERIALIZED VIEW msisdn_profile_relations AS
SELECT t1.msisdn,
	   t1.profile_id,
	   t1.rule_name,
	   t1.date_create
FROM dblink('host=vps2621.by.immo dbname=runiverse_by_node user=inform password=l!j@cneg'::TEXT, 'SELECT "user".msisdn,subscription.profile_id, rule_name, date_create FROM subscription INNER JOIN "user" on subscription.user_id = "user".user_id 
   INNER JOIN rule on subscription.rule_id = rule.rule_id WHERE subscription.profile_id IN (19,20,21,31,42)'::TEXT) t1(msisdn BIGINT,
																													   profile_id INTEGER,
																													   rule_name CHARACTER VARYING(100),
																													   date_create TIMESTAMP WITHOUT TIME ZONE);

ALTER MATERIALIZED VIEW msisdn_profile_relations OWNER TO inform;

CREATE INDEX msisdn_profile_relations_msisdn_idx
	ON msisdn_profile_relations (msisdn);

