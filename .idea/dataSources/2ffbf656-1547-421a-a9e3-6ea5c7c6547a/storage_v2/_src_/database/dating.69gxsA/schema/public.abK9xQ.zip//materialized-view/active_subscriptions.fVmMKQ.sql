CREATE MATERIALIZED VIEW active_subscriptions AS
SELECT t1.tel
FROM dblink('host=vps2621.by.immo dbname=runiverse_by_node user=inform password=l!j@cneg'::TEXT,
			'SELECT DISTINCT "user".msisdn FROM subscription inner join "user" on subscription.user_id = "user".user_id WHERE subscription.profile_id IN (19,20,21) AND subscription.subscription_status = 2'::TEXT) t1(tel BIGINT);

ALTER MATERIALIZED VIEW active_subscriptions OWNER TO inform;

CREATE UNIQUE INDEX active_subscriptions_tel_idx
	ON active_subscriptions (tel);

