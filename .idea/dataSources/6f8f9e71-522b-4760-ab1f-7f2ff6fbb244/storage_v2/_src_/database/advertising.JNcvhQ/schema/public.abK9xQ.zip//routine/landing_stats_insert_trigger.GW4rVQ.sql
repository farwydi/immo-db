CREATE FUNCTION landing_stats_insert_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	if NEW.record_date is not null and NEW.record_date >= '2017-02-01 00:00:00' then
	 EXECUTE 'insert into landing_stats_'
		|| date_part( 'year', NEW.record_date) || '_'
		|| date_part( 'month', NEW.record_date)
		|| ' select $1.*' using NEW;
	else
	EXECUTE 'insert into landing_stats_other select $1.*' using NEW;
	end if;
	RETURN NULL;
END;
$$;

ALTER FUNCTION landing_stats_insert_trigger() OWNER TO postgres;

