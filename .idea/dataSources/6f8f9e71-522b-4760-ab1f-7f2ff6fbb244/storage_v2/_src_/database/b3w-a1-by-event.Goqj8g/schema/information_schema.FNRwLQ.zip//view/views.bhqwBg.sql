CREATE VIEW views
			(table_catalog, table_schema, table_name, view_definition, check_option, is_updatable, is_insertable_into,
			 is_trigger_updatable, is_trigger_deletable, is_trigger_insertable_into)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER        AS table_catalog,
	   nc.nspname::information_schema.SQL_IDENTIFIER                AS table_schema,
	   c.relname::information_schema.SQL_IDENTIFIER                 AS table_name,
	   CASE
		   WHEN pg_has_role(c.relowner, 'USAGE'::TEXT) THEN pg_get_viewdef(c.oid)
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA                   AS view_definition,
	   'NONE'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS check_option,
	   CASE
		   WHEN (EXISTS(SELECT 1
						FROM pg_rewrite
						WHERE pg_rewrite.ev_class = c.oid
						  AND pg_rewrite.ev_type = '2'::"char"
						  AND pg_rewrite.is_instead)) AND (EXISTS(SELECT 1
																  FROM pg_rewrite
																  WHERE pg_rewrite.ev_class = c.oid
																	AND pg_rewrite.ev_type = '4'::"char"
																	AND pg_rewrite.is_instead)) THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                        AS is_updatable,
	   CASE
		   WHEN (EXISTS(SELECT 1
						FROM pg_rewrite
						WHERE pg_rewrite.ev_class = c.oid
						  AND pg_rewrite.ev_type = '3'::"char"
						  AND pg_rewrite.is_instead)) THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                        AS is_insertable_into,
	   CASE
		   WHEN (EXISTS(SELECT 1
						FROM pg_trigger
						WHERE pg_trigger.tgrelid = c.oid
						  AND (pg_trigger.tgtype::INTEGER & 81) = 81)) THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                        AS is_trigger_updatable,
	   CASE
		   WHEN (EXISTS(SELECT 1
						FROM pg_trigger
						WHERE pg_trigger.tgrelid = c.oid
						  AND (pg_trigger.tgtype::INTEGER & 73) = 73)) THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                        AS is_trigger_deletable,
	   CASE
		   WHEN (EXISTS(SELECT 1
						FROM pg_trigger
						WHERE pg_trigger.tgrelid = c.oid
						  AND (pg_trigger.tgtype::INTEGER & 69) = 69)) THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                        AS is_trigger_insertable_into
FROM pg_namespace nc,
	 pg_class c
WHERE c.relnamespace = nc.oid
  AND c.relkind = 'v'::"char"
  AND NOT pg_is_other_temp_schema(nc.oid)
  AND (pg_has_role(c.relowner, 'USAGE'::TEXT) OR
	   has_table_privilege(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
	   has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE views
	OWNER TO postgres;

