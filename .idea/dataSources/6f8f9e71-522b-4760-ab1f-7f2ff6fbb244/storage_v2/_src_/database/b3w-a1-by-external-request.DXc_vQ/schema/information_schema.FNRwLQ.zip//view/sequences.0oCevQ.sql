CREATE VIEW sequences
			(sequence_catalog, sequence_schema, sequence_name, data_type, numeric_precision, numeric_precision_radix,
			 numeric_scale, start_value, minimum_value, maximum_value, increment, cycle_option)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER                            AS sequence_catalog,
	   nc.nspname::information_schema.SQL_IDENTIFIER                                    AS sequence_schema,
	   c.relname::information_schema.SQL_IDENTIFIER                                     AS sequence_name,
	   'bigint'::CHARACTER VARYING::information_schema.CHARACTER_DATA                   AS data_type,
	   64::information_schema.CARDINAL_NUMBER                                           AS numeric_precision,
	   2::information_schema.CARDINAL_NUMBER                                            AS numeric_precision_radix,
	   0::information_schema.CARDINAL_NUMBER                                            AS numeric_scale,
	   (pg_sequence_parameters(c.oid)).start_value::information_schema.CHARACTER_DATA   AS start_value,
	   (pg_sequence_parameters(c.oid)).minimum_value::information_schema.CHARACTER_DATA AS minimum_value,
	   (pg_sequence_parameters(c.oid)).maximum_value::information_schema.CHARACTER_DATA AS maximum_value,
	   (pg_sequence_parameters(c.oid)).increment::information_schema.CHARACTER_DATA     AS increment,
	   CASE
		   WHEN (pg_sequence_parameters(c.oid)).cycle_option THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                                            AS cycle_option
FROM pg_namespace nc,
	 pg_class c
WHERE c.relnamespace = nc.oid
  AND c.relkind = 'S'::"char"
  AND NOT pg_is_other_temp_schema(nc.oid)
  AND (pg_has_role(c.relowner, 'USAGE'::TEXT) OR has_sequence_privilege(c.oid, 'SELECT, UPDATE, USAGE'::TEXT));

ALTER TABLE sequences
	OWNER TO postgres;

