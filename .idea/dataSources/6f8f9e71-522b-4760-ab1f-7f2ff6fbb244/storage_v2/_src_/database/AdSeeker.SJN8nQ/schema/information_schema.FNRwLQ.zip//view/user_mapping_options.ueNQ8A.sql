CREATE VIEW user_mapping_options
			(authorization_identifier, foreign_server_catalog, foreign_server_name, option_name, option_value) AS
SELECT um.authorization_identifier,
	   um.foreign_server_catalog,
	   um.foreign_server_name,
	   (pg_options_to_table(um.umoptions)).option_name::information_schema.SQL_IDENTIFIER AS option_name,
	   CASE
		   WHEN um.umuser <> 0::OID AND um.authorization_identifier::NAME = "current_user"() OR
				um.umuser = 0::OID AND pg_has_role(um.srvowner::NAME, 'USAGE'::TEXT) OR (SELECT pg_authid.rolsuper
																						 FROM pg_authid
																						 WHERE pg_authid.rolname = "current_user"())
			   THEN (pg_options_to_table(um.umoptions)).option_value
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA                                         AS option_value
FROM information_schema._pg_user_mappings um;

ALTER TABLE user_mapping_options
	OWNER TO postgres;

