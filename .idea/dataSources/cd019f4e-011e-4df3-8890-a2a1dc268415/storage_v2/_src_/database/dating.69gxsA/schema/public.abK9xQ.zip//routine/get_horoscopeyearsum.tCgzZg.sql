CREATE FUNCTION get_horoscopeyearsum(birthday date) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare 
 birthyear varchar := cast(extract(year from birthday) as varchar) || cast(extract(month from birthday) as varchar) || cast(extract(day from birthday) as varchar);
 calcyear integer := 0;
 ident integer;
begin
while char_length(birthyear)>1 loop 
 --raise notice 'birthyear = %s',birthyear;
 ident := char_length(birthyear); 
 --raise notice 'ident = %s',ident;
 calcyear := 0;
 while (ident > 0) loop
  --raise notice 'char = %',substring(birthyear,ident,1);  
  calcyear := calcyear + cast(substring(birthyear,ident,1) as integer);
  --raise notice 'calcyear = %s',calcyear;
  ident := ident - 1;
  --raise notice 'ident = %s',ident;
 end loop;
 birthyear := cast(calcyear as integer);
end loop;
return birthyear;
end;
$$;

ALTER FUNCTION get_horoscopeyearsum(DATE) OWNER TO postgres;

