CREATE FUNCTION private_notice(start_date timestamp without time zone, end_date timestamp without time zone) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
BEGIN
 /**
  во временную таблицу выбираются пользователи, 
  которые отправляли сообщения за прошедшие сутки
  (считаем их "отправителями")
 */
 create temp table _from as 
 select user_from, user_to, min(date) as date
 from message
 where date >= start_date and date < end_date
 group by user_from, user_to; 

 /**
  во временную таблицу выбираются пользователи, 
  которые начиная с 00 часов вчерашнего дня получали сообщения
  (считаем их "получателями")
 */
 create temp table _to as 
 select user_from, user_to, max(date) as date
 from message
 where date >= start_date
 group by user_from, user_to; 


 
 /**
  * во временную таблицу получаем список "отправителей",
  * которым не ответили на приваты 
  */
 create temp table _user_list as 


 select _from.user_from, _from.user_to
 from _from
 inner join 
 (

  select _from.user_from, min(_from.date) as date
  from _from
  left join _to on _from.user_from = _to.user_to 
   and _from.user_to = _to.user_from
   and _from.date < _to.date
  where _to.date is null
  group by _from.user_from 
 ) as t
 on _from.user_from = t.user_from and _from.date = t.date;

 drop table _from;

 /**
  * забираем инфу (телефон, ник, пол, город)
  * о "отправителях" и "получателях"
  * и отсеиваем не мтс "отправителей" (основываясь на намбер пулах)
  * !!делаем иннер с таблицей намбер_пулы, т.к. считаем, что там лежат только хорошие данные!!
  * Данные по пользователям беруться из таблицы users для отправителей и получателей
  */
 create temp table _details_user_list as 
 select 
  user_from.user_id as from_user_id, 
  user_from.nick as from_nick, 
  user_from.tel as from_tel, 
  user_from.city as from_city, 
  user_from.sex as from_sex, 
  number_pool.time_disp as from_time_disp,
  user_to.user_id as to_user_id, 
  user_to.nick as to_nick, 
  user_to.tel as to_tel, 
  user_to.city as to_city, 
  user_to.sex as to_sex
 from _user_list
 inner join "user" user_from on _user_list.user_from = user_from.user_id
 inner join "user" user_to on _user_list.user_to = user_to.user_id
 inner join number_pool on (number_pool.from_number <= user_from.tel and user_from.tel <= number_pool.to_number);

 drop table _user_list;
 
 /**
  * подбираем каждому "отправителю" двух новых "получателей" из списка "отправителей" по критериям "получателя"
  */
 create temp table _send_list as 

 select  
  from_list.from_user_id, 
  max(to_list.from_user_id) as user_id_1, 
  min(to_list.from_user_id) as user_id_2
  
 from _details_user_list from_list

 inner join _details_user_list to_list 
  on from_list.to_city = to_list.from_city
  and from_list.to_sex = to_list.from_sex

 left join _to 
   on from_list.from_user_id = _to.user_from 
  and to_list.from_user_id = _to.user_to

 left join private_notice 
  on private_notice.to_user_id_1=to_list.from_user_id
  
 left join private_notice as private_notice2 
  on private_notice2.to_user_id_2=to_list.from_user_id
  
 where 
  private_notice2.private_notice_id is null 
  and  private_notice.private_notice_id is null
  and _to.user_to is null
  
 group by from_list.from_user_id;


 drop table _to;

 /**
  * достаем всю необходимую инфу об "отправителях" и "получателях"
  */
 insert into private_notice 
 (
  from_user_id,
  from_tel,
  from_nick,
  from_time_disp,
  to_sex,
  to_city,
  to_user_id_1,
  to_nick_1,
  to_user_id_2,
  to_nick_2
 )
 select 
  from_user.from_user_id, 
  from_user.from_tel,
  from_user.to_nick, 
  from_user.from_time_disp, 
  
  user_1.from_sex,
  user_1.from_city,
  user_1.from_user_id, 
  user_1.from_nick,
  user_2.from_user_id, 
  user_2.from_nick
  
 from _send_list
 inner join _details_user_list as from_user on _send_list.from_user_id = from_user.from_user_id
 inner join _details_user_list as user_1 on _send_list.user_id_1 = user_1.from_user_id
 inner join _details_user_list as user_2 on _send_list.user_id_2 = user_2.from_user_id

 
 left join private_notice on private_notice.from_user_id = from_user.from_user_id
  and (private_notice.send_date is null or send_date > now() - interval '1 day')
 where private_notice.private_notice_id is null;


 drop table _details_user_list;
 drop table _send_list;


END;
$$;

ALTER FUNCTION private_notice(TIMESTAMP, TIMESTAMP) OWNER TO postgres;

