CREATE FUNCTION get_zodiac(birthdate date) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
 stat_birth_day integer := extract(day from birthdate);
 stat_birth_month integer := extract(month from birthdate);
 new_date date;
 zodiak integer;
 datestr varchar;
begin 
 zodiak := CASE
 WHEN (stat_birth_month=3 AND stat_birth_day>20) OR (stat_birth_month=4 AND stat_birth_day<21) THEN 1
 WHEN (stat_birth_month=4 AND stat_birth_day>20) OR (stat_birth_month=5 AND stat_birth_day<22) THEN 2
 WHEN (stat_birth_month=5 AND stat_birth_day>21) OR (stat_birth_month=6 AND stat_birth_day<22) THEN 3
 WHEN (stat_birth_month=6 AND stat_birth_day>21) OR (stat_birth_month=7 AND stat_birth_day<23) THEN 4
 WHEN (stat_birth_month=7 AND stat_birth_day>22) OR (stat_birth_month=8 AND stat_birth_day<24) THEN 5
 WHEN (stat_birth_month=8 AND stat_birth_day>23) OR (stat_birth_month=9 AND stat_birth_day<24) THEN 6
 WHEN (stat_birth_month=9 AND stat_birth_day>23) OR (stat_birth_month=10 AND stat_birth_day<24) THEN 7
 WHEN (stat_birth_month=10 AND stat_birth_day>23) OR (stat_birth_month=11 AND stat_birth_day<23) THEN 8
 WHEN (stat_birth_month=11 AND stat_birth_day>22) OR (stat_birth_month=12 AND stat_birth_day<22) THEN 9
 WHEN (stat_birth_month=12 AND stat_birth_day>21) OR (stat_birth_month=1 AND stat_birth_day<21) THEN 10
 WHEN (stat_birth_month=1 AND stat_birth_day>20) OR (stat_birth_month=2 AND stat_birth_day<19) THEN 11
 WHEN (stat_birth_month=2 AND stat_birth_day>18) OR (stat_birth_month=3 AND stat_birth_day<21) THEN 12
 END;
 --return (select id from zodiacperiods where date ('2000' || substring(cast(birthdate as varchar),5,10)) between since and till);
 return zodiak;
end;
$$;

ALTER FUNCTION get_zodiac(DATE) OWNER TO postgres;

