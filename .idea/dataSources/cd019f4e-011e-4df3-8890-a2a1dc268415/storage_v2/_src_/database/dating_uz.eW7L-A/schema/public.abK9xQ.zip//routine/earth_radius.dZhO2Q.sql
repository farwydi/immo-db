CREATE FUNCTION earth_radius(lat double precision) RETURNS double precision
	LANGUAGE plpgsql
AS
$$
DECLARE
			        rad_equatorial FLOAT := 6378.137;
			        rad_polar FLOAT := 6356.752;
			    BEGIN
			    RETURN sqrt(power(rad_equatorial, 2) * power(cos(lat), 2) + power(rad_polar, 2)* power(sin(lat), 2)/rad_equatorial*power(cos(lat), 2) + rad_polar*power(sin(lat), 2));
			    END;

$$;

ALTER FUNCTION earth_radius(DOUBLE PRECISION) OWNER TO postgres;

