CREATE FUNCTION syncsearchprecomp() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            INSERT INTO search_precomp_update_queue VALUES(old.user_id, 'delete');
        ELSIF (TG_OP = 'UPDATE') THEN
            INSERT INTO search_precomp_update_queue VALUES(old.user_id, 'update');
        ELSIF (TG_OP = 'INSERT') THEN
            INSERT INTO search_precomp_update_queue VALUES(new.user_id, 'insert');
        END IF;
    RETURN NULL;
END;
$$;

ALTER FUNCTION syncsearchprecomp() OWNER TO postgres;

