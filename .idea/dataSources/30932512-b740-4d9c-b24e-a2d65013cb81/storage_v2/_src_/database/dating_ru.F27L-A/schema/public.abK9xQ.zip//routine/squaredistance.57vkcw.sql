CREATE FUNCTION squaredistance(x1 integer, y1 integer, x2 integer, y2 integer, squaresize integer) RETURNS integer
	LANGUAGE plpgsql
AS
$$
BEGIN
	RETURN  (sqrt( pow(x1-x2, 2)+pow(y1-y2, 2) )*squareSize)::integer;
END;
$$;

ALTER FUNCTION squaredistance(INTEGER, INTEGER, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

