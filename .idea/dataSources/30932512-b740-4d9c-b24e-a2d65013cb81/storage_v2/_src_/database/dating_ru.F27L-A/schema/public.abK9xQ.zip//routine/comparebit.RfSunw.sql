CREATE FUNCTION comparebit(personbit bit, partnerbit bit) RETURNS integer
	COST 1
	LANGUAGE plpgsql
AS
$$
declare
 comp bit(25) := personbit & partnerbit;
begin
 return (select count(*) from (select regexp_matches(comp::varchar,'1','ig')) t);
end;
$$;

ALTER FUNCTION comparebit(BIT, BIT) OWNER TO postgres;

