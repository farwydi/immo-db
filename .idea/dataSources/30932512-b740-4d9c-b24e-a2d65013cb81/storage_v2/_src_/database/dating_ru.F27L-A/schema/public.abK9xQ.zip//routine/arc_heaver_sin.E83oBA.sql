CREATE FUNCTION arc_heaver_sin(double precision) RETURNS double precision
	LANGUAGE sql
AS
$$
SELECT 2.0*asin(sqrt($1));

$$;

ALTER FUNCTION arc_heaver_sin(DOUBLE PRECISION) OWNER TO postgres;

