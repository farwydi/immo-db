CREATE VIEW pg_sequences
			(schemaname, sequencename, sequenceowner, data_type, start_value, min_value, max_value, increment_by, cycle,
			 cache_size, last_value)
AS
SELECT n.nspname                   AS schemaname,
	   c.relname                   AS sequencename,
	   PG_GET_USERBYID(c.relowner) AS sequenceowner,
	   s.seqtypid::REGTYPE         AS data_type,
	   s.seqstart                  AS start_value,
	   s.seqmin                    AS min_value,
	   s.seqmax                    AS max_value,
	   s.seqincrement              AS increment_by,
	   s.seqcycle                  AS cycle,
	   s.seqcache                  AS cache_size,
	   CASE
		   WHEN HAS_SEQUENCE_PRIVILEGE(c.oid, 'SELECT,USAGE'::TEXT) THEN pg_sequence_last_value(c.oid::REGCLASS)
		   ELSE NULL::BIGINT
		   END                     AS last_value
FROM pg_sequence s
		 JOIN pg_class c ON c.oid = s.seqrelid
		 LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE NOT PG_IS_OTHER_TEMP_SCHEMA(n.oid)
  AND c.relkind = 'S'::"char";

ALTER TABLE pg_sequences
	OWNER TO postgres;

GRANT SELECT ON pg_sequences TO PUBLIC;

