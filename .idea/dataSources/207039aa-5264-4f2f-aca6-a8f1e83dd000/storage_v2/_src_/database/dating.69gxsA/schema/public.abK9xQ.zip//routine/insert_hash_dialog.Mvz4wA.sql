CREATE FUNCTION insert_hash_dialog() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	IF NEW.dialogue_hash IS NULL THEN
		NEW.dialogue_hash := hash_array(sort(ARRAY [NEW.from_user_id, NEW.to_user_id]));
	END IF;
	RETURN new;
END;
$$;

ALTER FUNCTION insert_hash_dialog() OWNER TO postgres;

