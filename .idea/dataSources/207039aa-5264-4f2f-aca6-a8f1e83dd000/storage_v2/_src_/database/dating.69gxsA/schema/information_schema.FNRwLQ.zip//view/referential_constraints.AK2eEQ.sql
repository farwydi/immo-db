CREATE VIEW referential_constraints
			(constraint_catalog, constraint_schema, constraint_name, unique_constraint_catalog,
			 unique_constraint_schema, unique_constraint_name, match_option, update_rule, delete_rule)
AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
	   ncon.nspname::information_schema.SQL_IDENTIFIER       AS constraint_schema,
	   con.conname::information_schema.SQL_IDENTIFIER        AS constraint_name,
	   CASE
		   WHEN npkc.nspname IS NULL THEN NULL::NAME
		   ELSE CURRENT_DATABASE()
		   END::information_schema.SQL_IDENTIFIER            AS unique_constraint_catalog,
	   npkc.nspname::information_schema.SQL_IDENTIFIER       AS unique_constraint_schema,
	   pkc.conname::information_schema.SQL_IDENTIFIER        AS unique_constraint_name,
	   CASE con.confmatchtype
		   WHEN 'f'::"char" THEN 'FULL'::TEXT
		   WHEN 'p'::"char" THEN 'PARTIAL'::TEXT
		   WHEN 's'::"char" THEN 'NONE'::TEXT
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA            AS match_option,
	   CASE con.confupdtype
		   WHEN 'c'::"char" THEN 'CASCADE'::TEXT
		   WHEN 'n'::"char" THEN 'SET NULL'::TEXT
		   WHEN 'd'::"char" THEN 'SET DEFAULT'::TEXT
		   WHEN 'r'::"char" THEN 'RESTRICT'::TEXT
		   WHEN 'a'::"char" THEN 'NO ACTION'::TEXT
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA            AS update_rule,
	   CASE con.confdeltype
		   WHEN 'c'::"char" THEN 'CASCADE'::TEXT
		   WHEN 'n'::"char" THEN 'SET NULL'::TEXT
		   WHEN 'd'::"char" THEN 'SET DEFAULT'::TEXT
		   WHEN 'r'::"char" THEN 'RESTRICT'::TEXT
		   WHEN 'a'::"char" THEN 'NO ACTION'::TEXT
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA            AS delete_rule
FROM pg_namespace ncon
		 JOIN pg_constraint con ON ncon.oid = con.connamespace
		 JOIN pg_class c ON con.conrelid = c.oid AND con.contype = 'f'::"char"
		 LEFT JOIN pg_depend d1 ON d1.objid = con.oid AND d1.classid = 'pg_constraint'::REGCLASS::OID AND
								   d1.refclassid = 'pg_class'::REGCLASS::OID AND d1.refobjsubid = 0
		 LEFT JOIN pg_depend d2
				   ON d2.refclassid = 'pg_constraint'::REGCLASS::OID AND d2.classid = 'pg_class'::REGCLASS::OID AND
					  d2.objid = d1.refobjid AND d2.objsubid = 0 AND d2.deptype = 'i'::"char"
		 LEFT JOIN pg_constraint pkc
				   ON pkc.oid = d2.refobjid AND (pkc.contype = ANY (ARRAY ['p'::"char", 'u'::"char"])) AND
					  pkc.conrelid = con.confrelid
		 LEFT JOIN pg_namespace npkc ON pkc.connamespace = npkc.oid
WHERE PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT)
   OR HAS_TABLE_PRIVILEGE(c.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT)
   OR HAS_ANY_COLUMN_PRIVILEGE(c.oid, 'INSERT, UPDATE, REFERENCES'::TEXT);

ALTER TABLE referential_constraints
	OWNER TO postgres;

GRANT SELECT ON referential_constraints TO PUBLIC;

