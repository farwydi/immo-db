CREATE VIEW view_table_usage (view_catalog, view_schema, view_name, table_catalog, table_schema, table_name) AS
SELECT DISTINCT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS view_catalog,
				nv.nspname::information_schema.SQL_IDENTIFIER         AS view_schema,
				v.relname::information_schema.SQL_IDENTIFIER          AS view_name,
				CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS table_catalog,
				nt.nspname::information_schema.SQL_IDENTIFIER         AS table_schema,
				t.relname::information_schema.SQL_IDENTIFIER          AS table_name
FROM pg_namespace nv,
	 pg_class v,
	 pg_depend dv,
	 pg_depend dt,
	 pg_class t,
	 pg_namespace nt
WHERE nv.oid = v.relnamespace
  AND v.relkind = 'v'::"char"
  AND v.oid = dv.refobjid
  AND dv.refclassid = 'pg_class'::REGCLASS::OID
  AND dv.classid = 'pg_rewrite'::REGCLASS::OID
  AND dv.deptype = 'i'::"char"
  AND dv.objid = dt.objid
  AND dv.refobjid <> dt.refobjid
  AND dt.classid = 'pg_rewrite'::REGCLASS::OID
  AND dt.refclassid = 'pg_class'::REGCLASS::OID
  AND dt.refobjid = t.oid
  AND t.relnamespace = nt.oid
  AND (t.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  AND PG_HAS_ROLE(t.relowner, 'USAGE'::TEXT);

ALTER TABLE view_table_usage
	OWNER TO postgres;

GRANT SELECT ON view_table_usage TO PUBLIC;

