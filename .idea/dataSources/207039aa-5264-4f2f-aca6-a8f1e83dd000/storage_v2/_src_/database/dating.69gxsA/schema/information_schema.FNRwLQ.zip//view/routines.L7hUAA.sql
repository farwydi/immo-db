CREATE VIEW routines
			(specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema, routine_name,
			 routine_type, module_catalog, module_schema, module_name, udt_catalog, udt_schema, udt_name, data_type,
			 character_maximum_length, character_octet_length, character_set_catalog, character_set_schema,
			 character_set_name, collation_catalog, collation_schema, collation_name, numeric_precision,
			 numeric_precision_radix, numeric_scale, datetime_precision, interval_type, interval_precision,
			 type_udt_catalog, type_udt_schema, type_udt_name, scope_catalog, scope_schema, scope_name,
			 maximum_cardinality, dtd_identifier, routine_body, routine_definition, external_name, external_language,
			 parameter_style, is_deterministic, sql_data_access, is_null_call, sql_path, schema_level_routine,
			 max_dynamic_result_sets, is_user_defined_cast, is_implicitly_invocable, security_type,
			 to_sql_specific_catalog, to_sql_specific_schema, to_sql_specific_name, as_locator, created, last_altered,
			 new_savepoint_level, is_udt_dependent, result_cast_from_data_type, result_cast_as_locator,
			 result_cast_char_max_length, result_cast_char_octet_length, result_cast_char_set_catalog,
			 result_cast_char_set_schema, result_cast_char_set_name, result_cast_collation_catalog,
			 result_cast_collation_schema, result_cast_collation_name, result_cast_numeric_precision,
			 result_cast_numeric_precision_radix, result_cast_numeric_scale, result_cast_datetime_precision,
			 result_cast_interval_type, result_cast_interval_precision, result_cast_type_udt_catalog,
			 result_cast_type_udt_schema, result_cast_type_udt_name, result_cast_scope_catalog,
			 result_cast_scope_schema, result_cast_scope_name, result_cast_maximum_cardinality,
			 result_cast_dtd_identifier)
AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                              AS specific_catalog,
	   n.nspname::information_schema.SQL_IDENTIFIER                                       AS specific_schema,
	   ((p.proname::TEXT || '_'::TEXT) || p.oid::TEXT)::information_schema.SQL_IDENTIFIER AS specific_name,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                              AS routine_catalog,
	   n.nspname::information_schema.SQL_IDENTIFIER                                       AS routine_schema,
	   p.proname::information_schema.SQL_IDENTIFIER                                       AS routine_name,
	   'FUNCTION'::CHARACTER VARYING::information_schema.CHARACTER_DATA                   AS routine_type,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS module_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS module_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS module_name,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS udt_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS udt_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS udt_name,
	   CASE
		   WHEN t.typelem <> 0::OID AND t.typlen = '-1'::INTEGER THEN 'ARRAY'::TEXT
		   WHEN nt.nspname = 'pg_catalog'::NAME THEN FORMAT_TYPE(t.oid, NULL::INTEGER)
		   ELSE 'USER-DEFINED'::TEXT
		   END::information_schema.CHARACTER_DATA                                         AS data_type,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS character_maximum_length,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS character_octet_length,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS character_set_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS character_set_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS character_set_name,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS collation_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS collation_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS collation_name,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS numeric_precision,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS numeric_precision_radix,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS numeric_scale,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS datetime_precision,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA                         AS interval_type,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS interval_precision,
	   CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                              AS type_udt_catalog,
	   nt.nspname::information_schema.SQL_IDENTIFIER                                      AS type_udt_schema,
	   t.typname::information_schema.SQL_IDENTIFIER                                       AS type_udt_name,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS scope_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS scope_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS scope_name,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS maximum_cardinality,
	   0::information_schema.SQL_IDENTIFIER                                               AS dtd_identifier,
	   CASE
		   WHEN l.lanname = 'sql'::NAME THEN 'SQL'::TEXT
		   ELSE 'EXTERNAL'::TEXT
		   END::information_schema.CHARACTER_DATA                                         AS routine_body,
	   CASE
		   WHEN PG_HAS_ROLE(p.proowner, 'USAGE'::TEXT) THEN p.prosrc
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA                                         AS routine_definition,
	   CASE
		   WHEN l.lanname = 'c'::NAME THEN p.prosrc
		   ELSE NULL::TEXT
		   END::information_schema.CHARACTER_DATA                                         AS external_name,
	   UPPER(l.lanname::TEXT)::information_schema.CHARACTER_DATA                          AS external_language,
	   'GENERAL'::CHARACTER VARYING::information_schema.CHARACTER_DATA                    AS parameter_style,
	   CASE
		   WHEN p.provolatile = 'i'::"char" THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                                              AS is_deterministic,
	   'MODIFIES'::CHARACTER VARYING::information_schema.CHARACTER_DATA                   AS sql_data_access,
	   CASE
		   WHEN p.proisstrict THEN 'YES'::TEXT
		   ELSE 'NO'::TEXT
		   END::information_schema.YES_OR_NO                                              AS is_null_call,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA                         AS sql_path,
	   'YES'::CHARACTER VARYING::information_schema.YES_OR_NO                             AS schema_level_routine,
	   0::information_schema.CARDINAL_NUMBER                                              AS max_dynamic_result_sets,
	   NULL::CHARACTER VARYING::information_schema.YES_OR_NO                              AS is_user_defined_cast,
	   NULL::CHARACTER VARYING::information_schema.YES_OR_NO                              AS is_implicitly_invocable,
	   CASE
		   WHEN p.prosecdef THEN 'DEFINER'::TEXT
		   ELSE 'INVOKER'::TEXT
		   END::information_schema.CHARACTER_DATA                                         AS security_type,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS to_sql_specific_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS to_sql_specific_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS to_sql_specific_name,
	   'NO'::CHARACTER VARYING::information_schema.YES_OR_NO                              AS as_locator,
	   NULL::TIMESTAMP WITH TIME ZONE::information_schema.TIME_STAMP                      AS created,
	   NULL::TIMESTAMP WITH TIME ZONE::information_schema.TIME_STAMP                      AS last_altered,
	   NULL::CHARACTER VARYING::information_schema.YES_OR_NO                              AS new_savepoint_level,
	   'NO'::CHARACTER VARYING::information_schema.YES_OR_NO                              AS is_udt_dependent,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA                         AS result_cast_from_data_type,
	   NULL::CHARACTER VARYING::information_schema.YES_OR_NO                              AS result_cast_as_locator,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_char_max_length,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_char_octet_length,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_char_set_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_char_set_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_char_set_name,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_collation_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_collation_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_collation_name,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_numeric_precision,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_numeric_precision_radix,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_numeric_scale,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_datetime_precision,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA                         AS result_cast_interval_type,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_interval_precision,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_type_udt_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_type_udt_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_type_udt_name,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_scope_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_scope_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_scope_name,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                                  AS result_cast_maximum_cardinality,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER                         AS result_cast_dtd_identifier
FROM pg_namespace n,
	 pg_proc p,
	 pg_language l,
	 pg_type t,
	 pg_namespace nt
WHERE n.oid = p.pronamespace
  AND p.prolang = l.oid
  AND p.prorettype = t.oid
  AND t.typnamespace = nt.oid
  AND (PG_HAS_ROLE(p.proowner, 'USAGE'::TEXT) OR HAS_FUNCTION_PRIVILEGE(p.oid, 'EXECUTE'::TEXT));

ALTER TABLE routines
	OWNER TO postgres;

GRANT SELECT ON routines TO PUBLIC;

