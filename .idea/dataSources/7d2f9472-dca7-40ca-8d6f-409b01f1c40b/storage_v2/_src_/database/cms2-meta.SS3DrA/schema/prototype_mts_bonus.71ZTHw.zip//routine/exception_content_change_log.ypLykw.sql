CREATE FUNCTION exception_content_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_mts_bonus.change_log(table_name, object_str_id, "action", "key") VALUES ('exception_content', OLD.content_code, 'D', 'content_code');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.content_code =  OLD.content_code) THEN
				INSERT INTO prototype_mts_bonus.change_log(table_name, object_str_id, "action", "key") VALUES ('exception_content', NEW.content_code, 'U', 'content_code');
			    ELSE
				INSERT INTO prototype_mts_bonus.change_log(table_name, object_str_id, "action", "key") VALUES ('exception_content', NEW.content_code, 'I', 'content_code');
				INSERT INTO prototype_mts_bonus.change_log(table_name, object_str_id, "action", "key") VALUES ('exception_content', OLD.content_code, 'D', 'content_code');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_mts_bonus.change_log(table_name, object_str_id, "action", "key") VALUES ('exception_content', NEW.content_code, 'I', 'content_code');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION exception_content_change_log() OWNER TO inform;

