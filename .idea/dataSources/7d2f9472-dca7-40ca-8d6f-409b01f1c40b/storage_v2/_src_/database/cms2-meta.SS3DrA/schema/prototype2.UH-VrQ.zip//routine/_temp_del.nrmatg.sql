CREATE FUNCTION _temp_del() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	_section_id integer;
	_content_code text;
	_content_id integer;
begin
_section_id=-1;
_content_code='';

for _row in select section_id,content_code from prototype2.content group by section_id,content_code having count(*)>1 limit 10000 loop

	select content_id into _content_id from prototype2.content where section_id=_row.section_id and content_code=_row.content_code limit 1;
	delete from prototype2.content where content_id=_content_id;


end loop;

end;
$$;

ALTER FUNCTION _temp_del() OWNER TO inform;

