CREATE FUNCTION update_melody_artist_relation(artistid uuid, parents uuid[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	parentId uuid;
	real_id uuid;
BEGIN
real_id=(SELECT(get_main_from_recycle(artistid)));
	DELETE FROM melody_artist_relation WHERE artist_id = real_id;
	
	FOR i IN COALESCE(array_lower(parents,1),0) .. COALESCE(array_upper(parents,1),-1) LOOP
	parentId:=(SELECT(get_main_from_recycle(parents[i])));
	INSERT INTO melody_artist_relation (artist_id, parent_artist_id) VALUES (real_id, parentId);

	END LOOP;
	return;
END;
$$;

ALTER FUNCTION update_melody_artist_relation(UUID, UUID[]) OWNER TO postgres;

