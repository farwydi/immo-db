CREATE FUNCTION join_artist_list() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_l text;
	_main_artist uuid;	
	_res record;
begin

_l='';
	for _row in select *, lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ','')) as l from melody_artist where lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ','')) in (
				select lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ',''))   from melody_artist
				group by lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ',''))
				having count(*)>1)
				and 
				lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ','')) not ilike '%�%' 
				and 
				lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ','')) <> ''
				order by l, description_short
			loop

		if (_row.l<>_l) then
			--следующий артист, инициализируем переменные
			_l=_row.l;
			_main_artist=_row.melody_artist_id;
		else
			--клеим
			select * from join_artist(_main_artist,_row.melody_artist_id) into _res;
		end if;
		
	end loop;

end;
$$;

ALTER FUNCTION join_artist_list() OWNER TO postgres;

