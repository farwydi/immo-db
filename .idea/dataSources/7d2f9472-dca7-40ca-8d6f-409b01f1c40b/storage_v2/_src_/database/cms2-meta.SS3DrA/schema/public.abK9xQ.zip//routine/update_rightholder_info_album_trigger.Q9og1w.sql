CREATE FUNCTION update_rightholder_info_album_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
					NEW.modification_date := now();
							RETURN NEW;
							END;

$$;

ALTER FUNCTION update_rightholder_info_album_trigger() OWNER TO postgres;

