CREATE FUNCTION drop_storefront_agreement() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
begin

DROP VIEW availability.storefront_agreement;

end;
$$;

ALTER FUNCTION drop_storefront_agreement() OWNER TO postgres;

