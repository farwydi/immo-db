CREATE FUNCTION get_artist2section(prototype text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare 
	_section record;
	_where text;
	_sql_text text;
	_sql_text1 text;
	_row_res record;
	
begin
_sql_text1 = 'select * from '|| prototype ||'.section where section_type_id = 1';

for _section in execute(_sql_text1) loop
if(_section.filter_id is not null) THEN
--RAISE NOTICE '%',_section;
	EXECUTE 'select * from get_query_by_filter_artist('||_section.filter_id||')' into _where;

--RAISE NOTICE '"%"',_where;

	--select * from get_query_by_artist(_section.filter_id)
	if coalesce(_where,'')<>'' THEN
		_sql_text = 'select distinct (mca.artist_id),'||_section.section_id||' from '|| prototype ||'.content c
		join melody_card_artist mca on mca.card_id = c.melody_card_id
		join melody_artist_genre on melody_artist_genre.artist_id = mca.artist_id
		where section_id ='||_section.section_id ||' and '||_where;
		FOR _row_res IN EXECUTE _sql_text LOOP
--RAISE NOTICE '"%"',_row_res;
			RETURN NEXT _row_res;
		END LOOP;	
	END IF;
	END IF;
END LOOP;
end;
$$;

ALTER FUNCTION get_artist2section(TEXT) OWNER TO postgres;

