CREATE FUNCTION update_java_genre(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE java_genre SET name = _name WHERE java_genre_id = id;
	IF NOT FOUND THEN
	INSERT INTO java_genre (java_genre_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_java_genre(INTEGER, VARCHAR) OWNER TO postgres;

