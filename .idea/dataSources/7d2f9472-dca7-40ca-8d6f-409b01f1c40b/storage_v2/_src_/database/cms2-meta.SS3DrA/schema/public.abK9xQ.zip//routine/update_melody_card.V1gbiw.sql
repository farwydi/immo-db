CREATE FUNCTION update_melody_card(_melody_card_id uuid, _name character varying, _is_erotica boolean, _is_free boolean, _minimal_cost double precision, albumids uuid[], artistids uuid[], authorlyricsids uuid[], composerids uuid[], categoryids integer[], _lyrics text, _is_hit boolean, associations integer[], _copyright character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
    albumId uuid;
    artistId uuid;
    authorLyricsId uuid;
    composerId uuid;
    categoryId integer;
    associationId integer;
    real_melody_card_id uuid;
    artist_i integer;
    _c integer;
    _sql varchar;
BEGIN
real_melody_card_id=(SELECT(get_main_from_recycle(_melody_card_id)));
    UPDATE melody_card SET
        name = _name,
        modification_date = NOW(),
        is_erotica = _is_erotica,
        is_free = _is_free,
        minimal_cost = _minimal_cost,
        lyrics = _lyrics,
        is_hit = _is_hit, 
        copyright = _copyright
    WHERE
        melody_card_id = real_melody_card_id;
    IF NOT FOUND THEN
    INSERT INTO melody_card
    (
        melody_card_id,
        name,
        creation_date,
        modification_date,
        is_erotica,
        is_free,
        minimal_cost,
        lyrics,
        is_hit, 
        copyright
    )
    VALUES
    (
        real_melody_card_id,
        _name,
        NOW(),
        NOW(),
        _is_erotica,
        _is_free,
        _minimal_cost,
        _lyrics,
        _is_hit,
        _copyright
    );
    END IF;

    --album
    FOR i IN COALESCE(array_lower(albumIds,1),0) .. COALESCE(array_upper(albumIds,1),-1) LOOP
        albumId := (SELECT(get_main_from_recycle(albumIds[i])));
        SELECT INTO _c count(*) FROM melody_card_album WHERE card_id = real_melody_card_id and album_id = albumId;
        IF (_c = 0) THEN
            INSERT INTO melody_card_album (card_id, album_id) VALUES (real_melody_card_id, albumId);
        END IF;
    END LOOP;

    --artist
    _sql = 'DELETE FROM melody_card_artist WHERE card_id = ' || quote_literal(real_melody_card_id);
    IF (array_upper(artistIds,1) > 0) THEN
        _sql = _sql || ' AND artist_id not in (' || array_uuid_to_string(artistIds) || ')';
    END IF;
    EXECUTE _sql;    
    artist_i=0;
    FOR i IN COALESCE(array_lower(artistIds,1),0) .. COALESCE(array_upper(artistIds,1),-1) LOOP
        artistId := (SELECT(get_main_from_recycle(artistIds[i])));
        SELECT INTO _c count(*) FROM melody_card_artist WHERE card_id = real_melody_card_id AND artist_id = artistId;
        IF (_c = 0) THEN
            IF (artist_i=0) THEN
                INSERT INTO melody_card_artist (card_id, artist_id,is_dominant) VALUES (real_melody_card_id, artistId,true);
            ELSE
                INSERT INTO melody_card_artist (card_id, artist_id,is_dominant) VALUES (real_melody_card_id, artistId, false);
            END IF;
        END IF;
        artist_i=artist_i+1;
    END LOOP;

    --author_lyrics
    _sql = 'DELETE FROM melody_card_author_lyrics WHERE card_id = ' || quote_literal(real_melody_card_id);
    IF (array_upper(authorLyricsIds,1) > 0) THEN
        _sql = _sql || ' AND author_lyrics_id not in (' || array_uuid_to_string(authorLyricsIds) || ')';
    END IF;
    EXECUTE _sql;        
    FOR i IN COALESCE(array_lower(authorLyricsIds,1),0) .. COALESCE(array_upper(authorLyricsIds,1),-1) LOOP        
        authorLyricsId := authorLyricsIds[i];
        SELECT INTO _c count(*) from melody_card_author_lyrics WHERE card_id = real_melody_card_id AND author_lyrics_id = authorLyricsId;
        IF (_c = 0) THEN
            INSERT INTO melody_card_author_lyrics (card_id, author_lyrics_id) VALUES (real_melody_card_id, authorLyricsId);
        END IF;
    END LOOP;

    --composer
    _sql = 'DELETE FROM melody_card_composer WHERE card_id = ' || quote_literal(real_melody_card_id);
    IF (array_upper(composerIds,1) > 0) THEN
        _sql = _sql || ' AND composer_id not in (' || array_uuid_to_string(composerIds) || ')';
    END IF;
    EXECUTE _sql;    
    FOR i IN COALESCE(array_lower(composerIds,1),0) .. COALESCE(array_upper(composerIds,1),-1) LOOP
        composerId := composerIds[i];
        SELECT INTO _c count(*) from melody_card_composer WHERE card_id = real_melody_card_id AND composer_id = composerId;
        IF (_c = 0) THEN
            INSERT INTO melody_card_composer (card_id, composer_id) VALUES (real_melody_card_id, composerId);
        END IF;
    END LOOP;

    --category
    IF (categoryIds IS NOT NULL) THEN
        _sql = 'DELETE FROM card_content_category WHERE card_id = ' || quote_literal(real_melody_card_id);
        IF (array_upper(categoryIds,1) > 0) THEN
            _sql = sql || ' AND category_id not in (' || array_uuid_to_string(categoryIds) || ')';
        END IF;
        EXECUTE _sql;
        FOR i IN COALESCE(array_lower(categoryIds,1),0) .. COALESCE(array_upper(categoryIds,1),-1) LOOP
            categoryId := categoryIds[i];
            SELECT INTO _c count(*) from card_content_category WHERE card_id = real_melody_card_id AND category_id = categoryId;
            IF (c = 0) THEN
                INSERT INTO card_content_category (card_id, category_id) VALUES (real_melody_card_id, categoryId);
            END IF;            
        END LOOP;
    END IF;

    --association
    IF (associations IS NOT NULL) THEN
        _sql = 'DELETE FROM card_association WHERE card_id = ' || quote_literal(real_melody_card_id);
        IF (array_upper(categoryIds,1) > 0) THEN
            _sql = sql || ' AND association_id not in (' || array_uuid_to_string(associations) || ')';
        END IF;
        EXECUTE _sql;    
        FOR i IN COALESCE(array_lower(associations,1),0) .. COALESCE(array_upper(associations,1),-1) LOOP
            associationId := associations[i];
            SELECT INTO _c count(*) from card_association WHERE card_id = real_melody_card_id AND association_id = associationId;
            IF (c = 0) THEN            
                INSERT INTO card_association (card_id, association_id) VALUES (real_melody_card_id, associationId);
            END IF;
        END LOOP;
    END IF;

END;
$$;

ALTER FUNCTION update_melody_card(UUID, VARCHAR, BOOLEAN, BOOLEAN, DOUBLE PRECISION, UUID[], UUID[], UUID[], UUID[], INTEGER[], TEXT, BOOLEAN, INTEGER[], VARCHAR) OWNER TO postgres;

