CREATE FUNCTION delete_preview_video(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM preview_video WHERE preview_video_id = id;
	DELETE FROM preview_relation WHERE preview_id = id;
END;
$$;

ALTER FUNCTION delete_preview_video(UUID) OWNER TO postgres;

