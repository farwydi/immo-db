CREATE FUNCTION update_ebook_author_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
		                NEW.modification_date := now();
						                RETURN NEW;
										END;

$$;

ALTER FUNCTION update_ebook_author_trigger() OWNER TO postgres;

