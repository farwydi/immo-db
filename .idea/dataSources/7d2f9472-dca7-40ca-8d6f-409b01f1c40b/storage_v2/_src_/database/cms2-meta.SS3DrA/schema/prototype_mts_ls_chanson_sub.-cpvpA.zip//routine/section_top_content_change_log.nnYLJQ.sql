CREATE FUNCTION section_top_content_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_mts_ls_chanson_sub.change_log(table_name, object_id, "action", "key") VALUES ('section_top_content', OLD.card_id, 'D', 'card_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.card_id =  OLD.card_id) THEN
				INSERT INTO prototype_mts_ls_chanson_sub.change_log(table_name, object_id, "action", "key") VALUES ('section_top_content', NEW.card_id, 'U', 'card_id');
			    ELSE
				INSERT INTO prototype_mts_ls_chanson_sub.change_log(table_name, object_id, "action", "key") VALUES ('section_top_content', NEW.card_id, 'I', 'card_id');
				INSERT INTO prototype_mts_ls_chanson_sub.change_log(table_name, object_id, "action", "key") VALUES ('section_top_content', OLD.card_id, 'D', 'card_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_mts_ls_chanson_sub.change_log(table_name, object_id, "action", "key") VALUES ('section_top_content', NEW.card_id, 'I', 'card_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION section_top_content_change_log() OWNER TO inform;

