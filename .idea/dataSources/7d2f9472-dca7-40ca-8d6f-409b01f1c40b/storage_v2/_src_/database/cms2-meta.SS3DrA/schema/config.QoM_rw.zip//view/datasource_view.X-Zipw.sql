CREATE VIEW datasource_view(storefront_name, datasource_type, datasource_name, prototype_schema) AS
SELECT s.name  AS storefront_name,
	   dt.name AS datasource_type,
	   d.name  AS datasource_name,
	   s.prototype_schema
FROM config.storefront_datasource sd
		 JOIN config.storefront s ON sd.storefront_id = s.storefront_id
		 JOIN config.datasource d ON d.datasource_id = sd.datasource_id
		 JOIN config.datasource_type dt ON dt.datasource_type_id = sd.datasource_type_id
ORDER BY s.storefront_id, dt.datasource_type_id;

ALTER TABLE datasource_view
	OWNER TO postgres;

