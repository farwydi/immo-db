CREATE FUNCTION _temp_content_tariff() RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare 
	_row_file record;
	_row_user_category record;
	_row_price_category record;

begin
for _row_file IN select distinct content_code from storefront.content loop
	for _row_user_category in select * from storefront.user_category loop
		for _row_price_category IN select * from storefront.price_category order by random() limit 1 loop
			insert into storefront.content_tariff 
					(user_category_id,			tariff_id,		content_code) 
				values   (_row_user_category.user_category_id,	_row_price_category.tariff_id,	_row_file.content_code);
		end loop;
	end loop;
end loop;

return 1;
end;
$$;

ALTER FUNCTION _temp_content_tariff() OWNER TO postgres;

