CREATE FUNCTION java_series_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_series', OLD.java_series_id, 'D', 'java_series_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.java_series_id =  OLD.java_series_id) THEN
																																					INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_series', NEW.java_series_id, 'U', 'java_series_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_series', NEW.java_series_id, 'I', 'java_series_id');
																																																	INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_series', OLD.java_series_id, 'D', 'java_series_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('java_series', NEW.java_series_id, 'I', 'java_series_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION java_series_change_log() OWNER TO postgres;

