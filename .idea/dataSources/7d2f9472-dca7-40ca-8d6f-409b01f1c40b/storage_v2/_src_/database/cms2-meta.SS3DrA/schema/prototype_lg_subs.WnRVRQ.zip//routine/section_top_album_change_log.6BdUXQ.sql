CREATE FUNCTION section_top_album_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', OLD.album_id, 'D', 'album_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', NEW.album_id, 'U', 'album_id');
			    RETURN NEW;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', NEW.album_id, 'I', 'album_id');
			    RETURN NEW;
			END IF;    
		    END;

$$;

ALTER FUNCTION section_top_album_change_log() OWNER TO inform;

