CREATE FUNCTION update_video_genre(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE video_genre SET name = _name WHERE video_genre_id = id;
	IF NOT FOUND THEN
	INSERT INTO video_genre (video_genre_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_video_genre(INTEGER, VARCHAR) OWNER TO postgres;

