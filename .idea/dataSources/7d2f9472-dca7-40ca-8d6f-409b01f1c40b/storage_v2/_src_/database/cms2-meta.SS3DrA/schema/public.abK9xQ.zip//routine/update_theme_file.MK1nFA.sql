CREATE FUNCTION update_theme_file(_theme_file_id uuid, _content_type_id integer, _fat_name character varying, _rightholder_name character varying, _rightholder_id character varying, _card_id uuid, _codeid integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE theme_file SET		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		rightholder_name = _rightholder_name,
		rightholder_id = _rightholder_id
	WHERE
		theme_file_id = _theme_file_id;
	IF NOT FOUND THEN
	INSERT INTO theme_file
	(
		theme_file_id,
		content_type_id,
		fat_name,
		rightholder_name,
		rightholder_id
	)
	VALUES
	(
		_theme_file_id,
		_content_type_id,
		_fat_name,
		_rightholder_name,
		_rightholder_id
	);
	END IF;

	DELETE FROM card_file WHERE file_id = _theme_file_id;
	INSERT INTO card_file (card_id, file_id) VALUES (_card_id, _theme_file_id);

	DELETE FROM file_content_code WHERE file_id = _theme_file_id;
	INSERT INTO file_content_code (file_id, content_code_id, content_type_id, fat_name)
		SELECT _theme_file_id, content_code_id, _content_type_id, _fat_name FROM content_code WHERE cms_content_code_lookup_id = _codeid;	

	
END;
$$;

ALTER FUNCTION update_theme_file(UUID, INTEGER, VARCHAR, VARCHAR, VARCHAR, UUID, INTEGER) OWNER TO postgres;

