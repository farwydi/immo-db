CREATE FUNCTION section_top_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype2.change_log(table_name, object_id, "action", "key") VALUES ('section_top', OLD.section_top_id, 'D', 'section_top_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.section_top_id =  OLD.section_top_id) THEN
				INSERT INTO prototype2.change_log(table_name, object_id, "action", "key") VALUES ('section_top', NEW.section_top_id, 'U', 'section_top_id');
			    ELSE
				INSERT INTO prototype2.change_log(table_name, object_id, "action", "key") VALUES ('section_top', NEW.section_top_id, 'I', 'section_top_id');
				INSERT INTO prototype2.change_log(table_name, object_id, "action", "key") VALUES ('section_top', OLD.section_top_id, 'D', 'section_top_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype2.change_log(table_name, object_id, "action", "key") VALUES ('section_top', NEW.section_top_id, 'I', 'section_top_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION section_top_change_log() OWNER TO inform;

