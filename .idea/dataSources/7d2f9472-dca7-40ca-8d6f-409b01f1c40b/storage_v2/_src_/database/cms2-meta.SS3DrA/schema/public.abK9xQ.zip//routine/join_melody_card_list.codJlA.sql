CREATE FUNCTION join_melody_card_list() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_name text;
	_album_id uuid;
	_main_melody_card_id uuid;	
	_res record;

	_artist_id uuid;
begin

_name='';
_album_id='00000000-0000-0000-0000-000000000000'; 

_artist_id='00000000-0000-0000-0000-000000000000'; 
	
		
	for _row in 
		select 
			t1.melody_card_id,
			t1.artist_id,
			lower(t1.name) as name,
			tt.album_id 
		from 
		(
			select distinct 
				melody_card_id,
				artist_id,
				name,
				coalesce(album_id,'00000000-0000-0000-0000-000000000000')::uuid as album_id
			from 
				melody_card 
			inner join 
				melody_card_artist on melody_card_id=melody_card_artist.card_id
			left join
				melody_card_album
			on
				melody_card_album.card_id = melody_card_id
		) t1
		inner join
		(
			select 
				artist_id,
				name, 
				album_id,
				count(*) as c 
			from 
			(
				select distinct 
					melody_card_id,
					artist_id,
					coalesce(album_id,'00000000-0000-0000-0000-000000000000')::uuid as album_id,
					lower(name) as name 
				from 
					melody_card 
				inner join 
					melody_card_artist 
				on 
					melody_card_id=melody_card_artist.card_id 
				left join
					melody_card_album
				on
					melody_card_album.card_id = melody_card_id			
			) t
			group by 
				artist_id,
				name,
				album_id
			having count(*)>1
			order by c desc
		) tt 
		on 
			t1.artist_id=tt.artist_id 
		and 
			lower(t1.name)=lower(tt.name)
		and
			t1.album_id = tt.album_id
		order by 
			t1.artist_id,
			t1.name,
			t1.album_id
	loop
		if (_row.artist_id=_artist_id and _row.name=_name and _row.album_id = _album_id) then
			select * from join_melody_card(_main_melody_card_id,_row.melody_card_id) into _res;
		else
			_name=_row.name;
			_artist_id=_row.artist_id;
			_main_melody_card_id=_row.melody_card_id;
			_album_id = _row.album_id;
		
		end if;
	end loop;



end;
$$;

ALTER FUNCTION join_melody_card_list() OWNER TO postgres;

