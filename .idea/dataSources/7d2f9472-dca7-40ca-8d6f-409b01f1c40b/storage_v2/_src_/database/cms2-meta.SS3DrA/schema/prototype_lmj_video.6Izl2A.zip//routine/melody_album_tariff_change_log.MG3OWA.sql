CREATE FUNCTION melody_album_tariff_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lmj_video.change_log(table_name, object_id, "action", "key") VALUES ('melody_album_tariff', OLD.album_id, 'D', 'album_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.album_id =  OLD.album_id) THEN
				INSERT INTO prototype_lmj_video.change_log(table_name, object_id, "action", "key") VALUES ('melody_album_tariff', NEW.album_id, 'U', 'album_id');
			    ELSE
				INSERT INTO prototype_lmj_video.change_log(table_name, object_id, "action", "key") VALUES ('melody_album_tariff', NEW.album_id, 'I', 'album_id');
				INSERT INTO prototype_lmj_video.change_log(table_name, object_id, "action", "key") VALUES ('melody_album_tariff', OLD.album_id, 'D', 'album_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lmj_video.change_log(table_name, object_id, "action", "key") VALUES ('melody_album_tariff', NEW.album_id, 'I', 'album_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION melody_album_tariff_change_log() OWNER TO inform;

