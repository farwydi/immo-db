CREATE FUNCTION get_preview_picture_list(_schema text, _preview_type_id integer, _preview_watermark_id integer, _source_id uuid) RETURNS SETOF text
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
begin

for _row in execute '
		select fat_name  from  ' || _schema || '.preview_relation 
				LEFT JOIN ' || _schema || '.preview_picture on preview_picture.preview_picture_id=preview_relation.preview_id
				where source_id=''' || _source_id || ''' and
					preview_type_id='||_preview_type_id ||' and preview_watermark_id='|| _preview_watermark_id ||' 
				' 
		loop
	return next _row.fat_name;

end loop;


				
end;
$$;

ALTER FUNCTION get_preview_picture_list(TEXT, INTEGER, INTEGER, UUID) OWNER TO postgres;

