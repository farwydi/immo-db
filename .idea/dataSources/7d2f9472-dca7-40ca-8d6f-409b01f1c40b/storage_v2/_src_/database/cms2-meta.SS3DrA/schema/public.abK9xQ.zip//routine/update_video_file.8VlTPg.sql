CREATE FUNCTION update_video_file(_video_file_id uuid, _content_type_id integer, _fat_name character varying, _rightholder_name character varying, _rightholder_id character varying, _card_id uuid, _duration character varying, _format character varying, _coding character varying, _codeid integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE video_file SET		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		rightholder_name = _rightholder_name,
		rightholder_id = _rightholder_id,
		duration = _duration,
		format = _format,
		coding = _coding		
	WHERE
		video_file_id = _video_file_id;
	IF NOT FOUND THEN
	INSERT INTO video_file
	(
		video_file_id,
		content_type_id,
		fat_name,
		rightholder_name,
		rightholder_id,
		duration,
		format,
		coding		
	)
	VALUES
	(
		_video_file_id,
		_content_type_id,
		_fat_name,
		_rightholder_name,
		_rightholder_id,
		_duration,
		_format,
		_coding		
	);
	END IF;

	DELETE FROM card_file WHERE file_id = _video_file_id;
	INSERT INTO card_file (card_id, file_id) VALUES (_card_id, _video_file_id);

	DELETE FROM file_content_code WHERE file_id = _video_file_id;
	INSERT INTO file_content_code (file_id, content_code_id, content_type_id, fat_name)
		SELECT _video_file_id, content_code_id, _content_type_id, _fat_name FROM content_code WHERE cms_content_code_lookup_id = _codeid;	

END;
$$;

ALTER FUNCTION update_video_file(UUID, INTEGER, VARCHAR, VARCHAR, VARCHAR, UUID, VARCHAR, VARCHAR, VARCHAR, INTEGER) OWNER TO postgres;

