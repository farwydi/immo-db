CREATE FUNCTION melody_artist_relation_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_artist_relation', OLD.artist_id, 'D', 'artist_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.artist_id =  OLD.artist_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_artist_relation', NEW.artist_id, 'U', 'artist_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_artist_relation', NEW.artist_id, 'I', 'artist_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_artist_relation', OLD.artist_id, 'D', 'artist_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('melody_artist_relation', NEW.artist_id, 'I', 'artist_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION melody_artist_relation_change_log() OWNER TO postgres;

