CREATE FUNCTION update_melody_file_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
  NEW.modification_date := now();
  RETURN NEW;
END;
$$;

ALTER FUNCTION update_melody_file_trigger() OWNER TO postgres;

