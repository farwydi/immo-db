CREATE FUNCTION news_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_rambler_music.change_log(table_name, object_id, "action", "key") VALUES ('news', OLD.news_id, 'D', 'news_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.news_id =  OLD.news_id) THEN
				INSERT INTO prototype_rambler_music.change_log(table_name, object_id, "action", "key") VALUES ('news', NEW.news_id, 'U', 'news_id');
			    ELSE
				INSERT INTO prototype_rambler_music.change_log(table_name, object_id, "action", "key") VALUES ('news', NEW.news_id, 'I', 'news_id');
				INSERT INTO prototype_rambler_music.change_log(table_name, object_id, "action", "key") VALUES ('news', OLD.news_id, 'D', 'news_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_rambler_music.change_log(table_name, object_id, "action", "key") VALUES ('news', NEW.news_id, 'I', 'news_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION news_change_log() OWNER TO inform;

