CREATE FUNCTION insert_contragent_rc_storefront_contragent() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
    contragent int;
    BEGIN
        IF (TG_OP = 'INSERT') THEN
	RETURN NEW;
	    update export.rc_storefront_contragent rc set contragent = cms.contragent
            from 
            contragent cms where cms.name = new.name_contragent;
        ELSE
                RETURN NULL;
        END IF;
    END;
$$;

ALTER FUNCTION insert_contragent_rc_storefront_contragent() OWNER TO inform;

