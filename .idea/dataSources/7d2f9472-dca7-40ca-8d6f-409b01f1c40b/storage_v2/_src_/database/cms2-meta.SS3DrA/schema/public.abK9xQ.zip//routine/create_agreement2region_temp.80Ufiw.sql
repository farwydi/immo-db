CREATE FUNCTION create_agreement2region_temp() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
begin


SELECT  count(*) into _count
FROM 
	pg_class c
	JOIN pg_namespace ns ON (c.relnamespace = ns.oid) 
	WHERE
		relkind ='r' and nspname NOT IN ('pg_catalog', 'pg_toast','information_schema') and relname='agreement2region_new';
		

--RAISE EXCEPTION '%',_count;

IF (_count<>0) THEN
	DROP TABLE agreement2region_new;
END IF;		

CREATE TABLE agreement2region_new
(
  agreement2region integer NOT NULL,
  agreement integer NOT NULL,
  region integer NOT NULL
);
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE agreement2region_new TO inform;
EXECUTE 'COMMENT ON TABLE agreement2region_new IS ''creation date: ' || now()::varchar || '''';

end;
$$;

ALTER FUNCTION create_agreement2region_temp() OWNER TO postgres;

