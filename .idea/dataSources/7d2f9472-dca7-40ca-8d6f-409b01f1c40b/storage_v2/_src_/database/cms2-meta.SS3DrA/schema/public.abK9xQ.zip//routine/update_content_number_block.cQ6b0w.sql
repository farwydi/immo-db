CREATE FUNCTION update_content_number_block(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE content_number_block SET name = _name WHERE content_number_block_id = id;
	IF NOT FOUND THEN
	INSERT INTO content_number_block (content_number_block_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_content_number_block(INTEGER, VARCHAR) OWNER TO postgres;

