CREATE FUNCTION delete_card_previews(_card_id uuid, _preview_type_id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM preview_picture WHERE preview_picture_id IN (select preview_id from preview_relation where source_id = _card_id and preview_type_id = _preview_type_id);
	DELETE FROM preview_video WHERE preview_video_id IN (select preview_id from preview_relation where source_id = _card_id and preview_type_id = _preview_type_id);
	DELETE FROM preview_melody WHERE preview_melody_id IN (select preview_id from preview_relation where source_id = _card_id and preview_type_id = _preview_type_id);
	DELETE FROM preview_relation WHERE source_id = _card_id and preview_type_id = _preview_type_id;
END;
$$;

ALTER FUNCTION delete_card_previews(UUID, INTEGER) OWNER TO postgres;

