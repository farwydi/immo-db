CREATE FUNCTION update_content_type(_id integer, _file_extension character varying, _file_extension_pattern character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE content_type SET file_extension = _file_extension, file_extension_pattern = _file_extension_pattern WHERE content_type_id = _id;	
END;
$$;

ALTER FUNCTION update_content_type(INTEGER, VARCHAR, VARCHAR) OWNER TO postgres;

