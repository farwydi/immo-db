CREATE FUNCTION user_category_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category', OLD.user_category_id, 'D', 'user_category_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category', NEW.user_category_id, 'U', 'user_category_id');
			    RETURN NEW;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category', NEW.user_category_id, 'I', 'user_category_id');
			    RETURN NEW;
			END IF;    
		    END;

$$;

ALTER FUNCTION user_category_change_log() OWNER TO inform;

