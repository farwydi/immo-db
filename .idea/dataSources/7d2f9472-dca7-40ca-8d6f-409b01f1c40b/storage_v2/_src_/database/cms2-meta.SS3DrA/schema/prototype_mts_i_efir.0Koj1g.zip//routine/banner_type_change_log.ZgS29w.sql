CREATE FUNCTION banner_type_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_mts_i_efir.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_type', OLD.banner_type_id, 'D', 'banner_type_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.banner_type_id =  OLD.banner_type_id) THEN
				INSERT INTO prototype_mts_i_efir.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_type', NEW.banner_type_id, 'U', 'banner_type_id');
			    ELSE
				INSERT INTO prototype_mts_i_efir.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_type', NEW.banner_type_id, 'I', 'banner_type_id');
				INSERT INTO prototype_mts_i_efir.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_type', OLD.banner_type_id, 'D', 'banner_type_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_mts_i_efir.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_type', NEW.banner_type_id, 'I', 'banner_type_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION banner_type_change_log() OWNER TO inform;

