CREATE FUNCTION update_content_code(_code_id integer, _content_code_billing_id integer, _content_billing_id integer, _cms_is_lmj_reserved boolean) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE content_code SET
		content_code_billing_id = _content_code_billing_id,
		content_billing_id = _content_billing_id,
		cms_is_lmj_reserved = _cms_is_lmj_reserved
	WHERE
		cms_content_code_lookup_id = _code_id;
END;
$$;

ALTER FUNCTION update_content_code(INTEGER, INTEGER, INTEGER, BOOLEAN) OWNER TO postgres;

