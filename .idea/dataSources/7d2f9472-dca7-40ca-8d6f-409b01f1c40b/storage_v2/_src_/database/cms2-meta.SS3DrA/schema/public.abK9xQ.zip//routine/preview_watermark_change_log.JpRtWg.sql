CREATE FUNCTION preview_watermark_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('preview_watermark', OLD.preview_watermark_id, 'D', 'preview_watermark_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.preview_watermark_id =  OLD.preview_watermark_id) THEN
																																					INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('preview_watermark', NEW.preview_watermark_id, 'U', 'preview_watermark_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('preview_watermark', NEW.preview_watermark_id, 'I', 'preview_watermark_id');
																																																	INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('preview_watermark', OLD.preview_watermark_id, 'D', 'preview_watermark_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_int_id, "action", "key") VALUES ('preview_watermark', NEW.preview_watermark_id, 'I', 'preview_watermark_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION preview_watermark_change_log() OWNER TO postgres;

