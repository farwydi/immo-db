CREATE FUNCTION _temp_content_code_file() RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	_row_files record;
	_content_code integer;
begin

for _row in select card_id, user_format.user_format_id from (
			select melody_file_id as file_id, content_type_id from melody_file
			union
			select video_file_id, content_type_id from video_file
			union 
			select java_file_id, content_type_id from java_file
			union
			select picture_file_id, content_type_id from picture_file
			union
			select theme_file_id, content_type_id from theme_file
			) files inner join card_file on  files.file_id= card_file.file_id
			inner join content_type on files.content_type_id=content_type.content_type_id
			inner join user_format on user_format.user_format_id=content_type.user_format_id
			group by card_id, user_format.user_format_id 
		loop

select content_code.content_code_id into _content_code from content_code left join file_content_code on content_code.content_code_id=file_content_code.content_code_id
where file_id is null order by random() limit 1;

	for _row_files in select distinct files.file_id, user_format.user_format_id,content_type.content_type_id,fat_name from (
						select melody_file_id as file_id, content_type_id,fat_name from melody_file
						union
						select video_file_id, content_type_id,fat_name from video_file
						union 
						select java_file_id, content_type_id,fat_name from java_file
						union
						select picture_file_id, content_type_id,fat_name from picture_file
						union
						select theme_file_id, content_type_id,fat_name from theme_file
						) files inner join card_file on  files.file_id= card_file.file_id
						inner join content_type on files.content_type_id=content_type.content_type_id
						inner join user_format on user_format.user_format_id=content_type.user_format_id
						where card_id=_row.card_id and user_format.user_format_id=_row.user_format_id
				loop

					insert into file_content_code
					(file_id,content_code_id,content_type_id,fat_name)
					values
					(_row_files.file_id,_content_code,_row_files.content_type_id,_row_files.fat_name);
				end loop;



end loop;


return 1;
end;
$$;

ALTER FUNCTION _temp_content_code_file() OWNER TO postgres;

