CREATE FUNCTION update_rc_rightholder_info_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
  NEW.modification_date := now();
  RETURN NEW;
END;
$$;

ALTER FUNCTION update_rc_rightholder_info_trigger() OWNER TO inform;

