CREATE FUNCTION delete_melody_card(id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
  DELETE FROM melody_card WHERE melody_card_id = id;
  DELETE FROM card_file WHERE card_id = id;
  DELETE FROM preview_relation WHERE source_id = id;
  DELETE FROM card_content_category WHERE card_id = id;
  DELETE FROM card_association WHERE card_id = id;
  DELETE FROM availability WHERE source_id = id;
  END;
$$;

ALTER FUNCTION delete_melody_card(UUID) OWNER TO postgres;

