CREATE FUNCTION prototype_update_user_format(_schema text) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_row RECORD;
BEGIN
	FOR _row IN EXECUTE 'SELECT uf.* from user_format uf 
						LEFT JOIN '|| _schema || '.user_format ON uf.user_format_id=user_format.user_format_id
				WHERE  user_format.user_format_id is null'
			LOOP

		EXECUTE 'INSERT INTO '|| _schema || '.user_format (user_format_id,"name") VALUES ('|| _row.user_format_id ||',''' || _row.name ||''')';
			
	END LOOP;

END;
$$;

ALTER FUNCTION prototype_update_user_format(TEXT) OWNER TO postgres;

