CREATE VIEW access_point
			(access_point_id, apn_type_id, operator_id, ip_range, hostname, port, name, "desc", has_msisdn,
			 msisdn_pattern) AS
SELECT ai.apn_ip_id                 AS access_point_id,
	   apn.apn_type_id,
	   apn.operator_id,
	   ai.cidr                      AS ip_range,
	   NULL::CHARACTER VARYING(250) AS hostname,
	   NULL::SMALLINT               AS port,
	   apn.name,
	   apn.description              AS "desc",
	   NULL::BOOLEAN                AS has_msisdn,
	   NULL::CHARACTER VARYING(250) AS msisdn_pattern
FROM apn
		 JOIN apn_ip ai ON ai.apn_id = apn.apn_id;

ALTER TABLE access_point
	OWNER TO postgres;

