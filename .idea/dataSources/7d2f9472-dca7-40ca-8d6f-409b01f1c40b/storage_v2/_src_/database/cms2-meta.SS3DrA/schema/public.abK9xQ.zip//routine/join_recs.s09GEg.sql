CREATE FUNCTION join_recs(main_card uuid, card uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare _row record;
_count int;
-- ������������
begin
for _row in select source_id, rec_object_id, weight from recommendation
where source_id = card loop
	select count(*) into _count from recommendation where source_id = main_card and rec_object_id = _row.rec_object_id;
	if(_count = 0 and _row.rec_object_id != main_card) then
		update recommendation set source_id=main_card where source_id = _row.source_id and rec_object_id = _row.rec_object_id;
	end if;
end loop;
for _row in select source_id, rec_object_id, weight from recommendation
where rec_object_id = card loop
	select count(*) into _count from recommendation where rec_object_id = main_card and source_id = _row.source_id;
	if(_count = 0  and _row.source_id != main_card) then
		update recommendation set rec_object_id=main_card where source_id = _row.source_id and rec_object_id = _row.rec_object_id;
	end if;
end loop;
delete from recommendation where source_id = card OR rec_object_id = card;
end;
$$;

ALTER FUNCTION join_recs(UUID, UUID) OWNER TO postgres;

