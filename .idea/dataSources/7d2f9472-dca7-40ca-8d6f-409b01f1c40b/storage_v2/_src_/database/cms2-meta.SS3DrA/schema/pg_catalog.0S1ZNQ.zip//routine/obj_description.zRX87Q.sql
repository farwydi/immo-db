CREATE FUNCTION obj_description(oid) RETURNS text
	STABLE
	STRICT
	LANGUAGE sql
AS
$$
select description from pg_catalog.pg_description where objoid = $1 and objsubid = 0
$$;

COMMENT ON FUNCTION obj_description(OID) IS 'deprecated, use two-argument form instead';

ALTER FUNCTION obj_description(OID) OWNER TO postgres;

