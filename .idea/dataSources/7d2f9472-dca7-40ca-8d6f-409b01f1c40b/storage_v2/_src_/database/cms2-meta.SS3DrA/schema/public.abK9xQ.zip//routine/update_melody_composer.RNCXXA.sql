CREATE FUNCTION update_melody_composer(composer_id uuid, composer_name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE melody_composer SET name = composer_name WHERE melody_composer_id = composer_id;
	
	IF NOT FOUND
		THEN
		INSERT INTO melody_composer (melody_composer_id, name) VALUES (composer_id, composer_name);
	END IF;
END;
$$;

ALTER FUNCTION update_melody_composer(UUID, VARCHAR) OWNER TO postgres;

