CREATE FUNCTION update_preview_melody(_preview_melody_id uuid, _preview_type_id integer, _content_type_id integer, _source_id uuid, _fat_name character varying, _duration character varying, _format character varying, _coding character varying, _is_mono boolean, _sampling_rate integer, _bit_rate integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE preview_melody SET		
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		duration = _duration,
		format = _format,
		coding = _coding,
		is_mono = _is_mono,
		sampling_rate = _sampling_rate,
		bit_rate = _bit_rate		
	WHERE
		preview_melody_id = _preview_melody_id;
	IF NOT FOUND THEN
	INSERT INTO preview_melody
	(
		preview_melody_id,		
		content_type_id,
		fat_name,
		duration,
		format,
		coding,
		is_mono,
		sampling_rate,
		bit_rate			
	)
	VALUES
	(
		_preview_melody_id,		
		_content_type_id,
		_fat_name,
		_duration,
		_format,
		_coding,
		_is_mono,
		_sampling_rate,
		_bit_rate			
	);
	END IF;
	
	UPDATE preview_relation SET 
		preview_id=_preview_melody_id,
		source_id=_source_id,
		preview_type_id=_preview_type_id
	WHERE preview_id=_preview_melody_id AND source_id=_source_id;

	IF NOT FOUND THEN
		INSERT INTO preview_relation 
		(
			preview_id,
			source_id,
			preview_type_id
		)
		VALUES
		(
			_preview_melody_id,
			_source_id,
			_preview_type_id
		);
	END IF;	
	
	
END;
$$;

ALTER FUNCTION update_preview_melody(UUID, INTEGER, INTEGER, UUID, VARCHAR, VARCHAR, VARCHAR, VARCHAR, BOOLEAN, INTEGER, INTEGER) OWNER TO postgres;

