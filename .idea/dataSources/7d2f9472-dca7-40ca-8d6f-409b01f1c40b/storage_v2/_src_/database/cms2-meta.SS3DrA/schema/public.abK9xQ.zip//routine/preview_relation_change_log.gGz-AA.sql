CREATE FUNCTION preview_relation_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
																		IF (TG_OP = 'DELETE') THEN
																					    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_relation', OLD.preview_id, 'D', 'preview_id');
																									    RETURN OLD;
																													ELSIF (TG_OP = 'UPDATE') THEN
																																    IF (NEW.preview_id =  OLD.preview_id) THEN
																																					INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_relation', NEW.preview_id, 'U', 'preview_id');
																																								    ELSE
																																													INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_relation', NEW.preview_id, 'I', 'preview_id');
																																																	INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_relation', OLD.preview_id, 'D', 'preview_id');
																																																				    END IF;
																																																								ELSIF (TG_OP = 'INSERT') THEN
																																																											    INSERT INTO public.change_log(table_name, object_id, "action", "key") VALUES ('preview_relation', NEW.preview_id, 'I', 'preview_id');
																																																															END IF;    
																																																																		RETURN NEW;
																																																																				    END;

$$;

ALTER FUNCTION preview_relation_change_log() OWNER TO postgres;

