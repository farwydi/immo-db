CREATE FUNCTION section_artist_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', OLD.section_id, 'D', 'section_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.section_id =  OLD.section_id) THEN
				INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', NEW.section_id, 'U', 'section_id');
			    ELSE
				INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', NEW.section_id, 'I', 'section_id');
				INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', OLD.section_id, 'D', 'section_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', NEW.section_id, 'I', 'section_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION section_artist_change_log() OWNER TO inform;

