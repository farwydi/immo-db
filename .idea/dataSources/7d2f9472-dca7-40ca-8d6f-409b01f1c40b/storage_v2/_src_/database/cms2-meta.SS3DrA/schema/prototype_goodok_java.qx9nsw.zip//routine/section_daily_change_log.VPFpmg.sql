CREATE FUNCTION section_daily_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_goodok_java.change_log(table_name, object_id, "action", "key") VALUES ('section_daily', OLD.section_daily_id, 'D', 'section_daily_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.section_daily_id =  OLD.section_daily_id) THEN
				INSERT INTO prototype_goodok_java.change_log(table_name, object_id, "action", "key") VALUES ('section_daily', NEW.section_daily_id, 'U', 'section_daily_id');
			    ELSE
				INSERT INTO prototype_goodok_java.change_log(table_name, object_id, "action", "key") VALUES ('section_daily', NEW.section_daily_id, 'I', 'section_daily_id');
				INSERT INTO prototype_goodok_java.change_log(table_name, object_id, "action", "key") VALUES ('section_daily', OLD.section_daily_id, 'D', 'section_daily_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_goodok_java.change_log(table_name, object_id, "action", "key") VALUES ('section_daily', NEW.section_daily_id, 'I', 'section_daily_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION section_daily_change_log() OWNER TO inform;

