CREATE FUNCTION delete_melody_artist(artistid uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM melody_artist WHERE melody_artist_id = artistId;
END;
$$;

ALTER FUNCTION delete_melody_artist(UUID) OWNER TO postgres;

