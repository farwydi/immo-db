CREATE VIEW storefront_agreement_list_type(storefront_id, list_type) AS
SELECT foo.storefront_id,
	   CASE
		   WHEN foo.is_black THEN 'black'::availability.AGREEMENT_LIST_TYPE
		   ELSE 'white'::availability.AGREEMENT_LIST_TYPE
		   END AS list_type
FROM (SELECT s.storefront_id,
			 ((SELECT count(*) AS count
			   FROM storefront_contragent sc
			   WHERE s.storefront_id = sc.storefront_id
				 AND NOT sc.is_blacklist)) > 0 OR ((SELECT count(*) AS count
													FROM storefront_agreement sc
													WHERE s.storefront_id = sc.storefront_id
													  AND NOT sc.is_blacklist)) > 0 AS is_white,
			 ((SELECT count(*) AS count
			   FROM storefront_contragent sc
			   WHERE s.storefront_id = sc.storefront_id
				 AND sc.is_blacklist)) > 0 OR ((SELECT count(*) AS count
												FROM storefront_agreement sc
												WHERE s.storefront_id = sc.storefront_id
												  AND sc.is_blacklist)) > 0         AS is_black
	  FROM config.storefront s
	  ORDER BY s.storefront_id) foo
WHERE foo.is_white = TRUE AND foo.is_black = FALSE
   OR foo.is_white = FALSE AND foo.is_black = TRUE;

ALTER TABLE storefront_agreement_list_type
	OWNER TO postgres;

