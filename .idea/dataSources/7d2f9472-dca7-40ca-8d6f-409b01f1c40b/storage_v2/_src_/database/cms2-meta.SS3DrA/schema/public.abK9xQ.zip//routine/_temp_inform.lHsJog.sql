CREATE FUNCTION _temp_inform() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
begin

--For TABLES
for _row in 
		select 'REVOKE ALL on '||schemaname||'.'||tablename||' FROM inform;' as t
		from pg_tables
		where schemaname not in ('pg_catalog','information_schema','_cms2_meta')
		order by schemaname, tablename
		loop

	execute _row.t;
	
end loop;	


for _row in 
		select 'GRANT SELECT, UPDATE, INSERT, DELETE on '||schemaname||'.'||tablename||' to inform;' as t
		from pg_tables
		where schemaname not in ('pg_catalog','information_schema','_cms2_meta')
		order by schemaname, tablename
		loop

	execute _row.t;
	
end loop;	
 

---For FUNCTIONS
for _row in 
		select 'REVOKE ALL on function
		'||n.nspname||'."'||p.proname||'"('||oidvectortypes(p.proargtypes)||') FROM
		public;' as t
		from pg_proc p, pg_namespace n
		where n.oid = p.pronamespace
		and n.nspname not in ('pg_catalog','information_schema','_cms2_meta')
		order by n.nspname, p.proname
		loop
	execute _row.t;
	
end loop;


for _row in 
		select 'GRANT EXECUTE on function
		'||n.nspname||'."'||p.proname||'"('||oidvectortypes(p.proargtypes)||') to
		inform;' as t
		from pg_proc p, pg_namespace n
		where n.oid = p.pronamespace
		and n.nspname not in ('pg_catalog','information_schema','_cms2_meta')
		order by n.nspname, p.proname
		loop
	execute _row.t;
	
end loop;


--For SEQUENCES 

for _row in 
		select 'REVOKE ALL ON SEQUENCE '||n.nspname||'.'||c.relname||' FROM inform;' as t
		from pg_class c, pg_namespace n
		where n.oid = c.relnamespace
		and c.relkind IN ('S')
		and n.nspname not in ('pg_catalog','information_schema','_cms2_meta')
	loop
execute _row.t;


for _row in 
		select 'GRANT SELECT, UPDATE ON SEQUENCE  '||n.nspname||'.'||c.relname||' to inform;' as t
		from pg_class c, pg_namespace n
		where n.oid = c.relnamespace
		and c.relkind IN ('S')
		and n.nspname not in ('pg_catalog','information_schema','_cms2_meta')
	loop
execute _row.t;
	
end loop;

	
end loop;

end;
$$;

ALTER FUNCTION _temp_inform() OWNER TO postgres;

