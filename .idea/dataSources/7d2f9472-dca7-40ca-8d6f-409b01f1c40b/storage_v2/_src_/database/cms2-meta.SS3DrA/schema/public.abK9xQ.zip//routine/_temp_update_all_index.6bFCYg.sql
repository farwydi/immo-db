CREATE FUNCTION _temp_update_all_index() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
begin

/*артисты*/
--DROP INDEX storefront.melody_artist_fts_idx;
ALTER TABLE storefront.melody_artist DROP COLUMN fts; 


ALTER TABLE storefront.melody_artist ADD COLUMN fts tsvector;
UPDATE storefront.melody_artist SET fts = to_tsvector('russian', (coalesce(search_text,'')));
CREATE INDEX melody_artist_fts_idx ON storefront.melody_artist USING gin(fts);

delete from storefront.melody_artist_user_format;
insert into storefront.melody_artist_user_format 
	select distinct artist_id, user_format_id  
	from storefront.content inner join storefront.melody_card_artist on content.card_id=melody_card_artist.card_id;

delete from storefront.melody_artist_section;
insert into storefront.melody_artist_section 
	select distinct section_id,artist_id  
	from storefront.content 
	inner join storefront.melody_card_artist on content.card_id=melody_card_artist.card_id;

update storefront.melody_artist
set first_letter_first_name=first_letter_last_name
where first_letter_first_name is null;

update storefront.melody_artist
set first_letter_last_name=first_letter_first_name
where first_letter_last_name is null;



/*альбомы*/

--DROP INDEX storefront.melody_album_fts_idx;
ALTER TABLE storefront.melody_album DROP COLUMN fts;

ALTER TABLE storefront.melody_album ADD COLUMN fts tsvector;
UPDATE storefront.melody_album SET fts = to_tsvector('russian', (coalesce(search_text,'')));
CREATE INDEX melody_album_fts_idx ON storefront.melody_album USING gin(fts);


select storefront.update_album_count_track('storefront') into _row ;

delete from storefront.melody_album_user_format ;
insert into storefront.melody_album_user_format 
	select distinct album_id, user_format_id  
	from storefront.content inner join storefront.melody_card_album on content.card_id=melody_card_album.card_id;

/*контент*/
--DROP INDEX storefront.content_fts_idx;
ALTER TABLE storefront."content" DROP COLUMN fts;


ALTER TABLE storefront.content ADD COLUMN fts tsvector;
UPDATE storefront.content SET fts = to_tsvector('russian', (coalesce(search_text,'')));
CREATE INDEX content_fts_idx ON storefront.content USING gin(fts);



--DROP INDEX storefront.content_fts_lyrics_idx;
ALTER TABLE storefront."content" DROP COLUMN fts_lyrics;

ALTER TABLE storefront.content ADD COLUMN fts_lyrics tsvector;
UPDATE storefront.content SET fts_lyrics = to_tsvector('russian', (coalesce(search_text_lyrics,'')));
CREATE INDEX content_fts_lyrics_idx ON storefront.content USING gin(fts_lyrics);



end;
$$;

ALTER FUNCTION _temp_update_all_index() OWNER TO postgres;

