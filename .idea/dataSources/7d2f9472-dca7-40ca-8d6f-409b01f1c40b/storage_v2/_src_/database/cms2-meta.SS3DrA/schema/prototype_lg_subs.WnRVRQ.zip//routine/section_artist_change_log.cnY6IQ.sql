CREATE FUNCTION section_artist_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', OLD.section_id, 'D', 'section_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', NEW.section_id, 'U', 'section_id');
			    RETURN NEW;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('section_artist', NEW.section_id, 'I', 'section_id');
			    RETURN NEW;
			END IF;    
		    END;

$$;

ALTER FUNCTION section_artist_change_log() OWNER TO inform;

