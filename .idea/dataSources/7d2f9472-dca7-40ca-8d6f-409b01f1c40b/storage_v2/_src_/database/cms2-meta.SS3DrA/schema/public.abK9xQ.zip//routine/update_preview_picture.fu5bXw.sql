CREATE FUNCTION update_preview_picture(_preview_picture_id uuid, _preview_type_id integer, _content_type_id integer, _source_id uuid, _parent_id uuid, _preview_watermark_id integer, _fat_name character varying, _height integer, _width integer, _color_depth integer, _horisontal_resolution integer, _vertical_resolution integer, _frame_rate integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE preview_picture SET
		content_type_id = _content_type_id,
		fat_name = _fat_name,
		preview_watermark_id=_preview_watermark_id,
		height = _height, 
		width = _width,
		color_depth = _color_depth,
		horisontal_resolution = _horisontal_resolution,
		vertical_resolution = _vertical_resolution,
		frame_rate = _frame_rate,
		parent_id=_parent_id		
	WHERE
		preview_picture_id = _preview_picture_id;

	IF NOT FOUND THEN
	INSERT INTO preview_picture
	(
		preview_picture_id,
		content_type_id,
		fat_name,
		height, 
		width,
		color_depth,
		horisontal_resolution,
		vertical_resolution,
		frame_rate,
		parent_id,
		preview_watermark_id
	)
	VALUES
	(
		_preview_picture_id,
		_content_type_id,
		_fat_name,
		_height, 
		_width,
		_color_depth,
		_horisontal_resolution,
		_vertical_resolution,
		_frame_rate,
		_parent_id,
		_preview_watermark_id			
	);
	END IF;


	UPDATE preview_relation SET 
		preview_id=_preview_picture_id,
		source_id=_source_id,
		preview_type_id=_preview_type_id
	WHERE preview_id=_preview_picture_id AND source_id=_source_id;

	IF NOT FOUND THEN
		INSERT INTO preview_relation 
		(
			preview_id,
			source_id,
			preview_type_id
		)
		VALUES
		(
			_preview_picture_id,
			_source_id,
			_preview_type_id
		);
	END IF; 
	
		
END;
$$;

ALTER FUNCTION update_preview_picture(UUID, INTEGER, INTEGER, UUID, UUID, INTEGER, VARCHAR, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER) OWNER TO postgres;

