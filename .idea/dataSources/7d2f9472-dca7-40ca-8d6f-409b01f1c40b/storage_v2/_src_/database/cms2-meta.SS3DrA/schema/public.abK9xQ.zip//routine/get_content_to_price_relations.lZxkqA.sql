CREATE FUNCTION get_content_to_price_relations(_agreement_id integer, _user_category_id integer, _section_id integer, _show_good boolean, _show_bad boolean, _schema_meta text, _schema_proto text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_sql_text_before text;
_sql_text_after text;
_sql_text text;
_sql_text1 text;
_row_res record;
_row_res1 record;
_row_res2 record;
begin

_sql_text_before = '
	select 
		c.content_code,
		c.melody_card_id, 
		mc.name,
		ct.tariff_id,
		c.section_id
	from 
		'|| _schema_proto ||'.content as c
	inner join
		'|| _schema_meta ||'.content_code as cc
	on
		cc.content_code = c.content_code	
	inner join
		'|| _schema_meta ||'.melody_card as mc
	on
		mc.melody_card_id = c.melody_card_id
	left join
		'|| _schema_proto ||'.content_tariff as ct	
	on
		c.content_code = ct.content_code
		and	
		ct.user_category_id = ' || _user_category_id ||'	
	where	
		cc.content_billing_id 
		in
		(
			select 
				content
			from
				'|| _schema_meta ||'.agreement2content
			where
				agreement = ' || _agreement_id || '
		)
';

_sql_text_after = '';

IF _show_good = true AND _show_bad = false THEN
	_sql_text_after = '
		and not(ct.tariff_id is null)
	';
END IF;

IF _show_good = false AND _show_bad = true THEN
	_sql_text_after = '
		and (ct.tariff_id is null)
	';
END IF;

_sql_text = _sql_text_before || ' and c.section_id=' || _section_id || _sql_text_after || ' limit 4000';

FOR _row_res IN EXECUTE _sql_text LOOP
	_sql_text1 = '
		select
			coalesce (ma.last_name || chr(32) || ma.first_name, ma.group,ma.last_name,ma.group)::text
		from
			'|| _schema_meta ||'.melody_card_artist as mca
		inner join
			'|| _schema_meta ||'.melody_artist as ma
		on
			ma.melody_artist_id = mca.artist_id
		where
			mca.card_id = ''' || _row_res.melody_card_id || '''
	';
	FOR _row_res1 IN EXECUTE _sql_text1 LOOP
		select 
			_row_res.content_code::text,
			_row_res.melody_card_id::uuid, 
			_row_res.name::text,
			_row_res1::text,
			_row_res.tariff_id::integer,
			_row_res.section_id::integer
		into _row_res2;
		RETURN next _row_res2;		
	END LOOP;
END LOOP;
IF NOT FOUND THEN

	_sql_text = _sql_text_before || ' and
		(
			c.section_id in
			(select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')
		or c.section_id in
			(select section_id from '|| _schema_proto ||'.section where parent_id 
			 in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||'))
		or c.section_id in
			(select section_id from '|| _schema_proto ||'.section where parent_id 
			 in (select section_id from '|| _schema_proto ||'.section where parent_id 
			  in (select section_id from '|| _schema_proto ||'.section where parent_id = '|| _section_id ||')))
		)
		' || _sql_text_after || ' limit 4000';

	FOR _row_res IN EXECUTE _sql_text LOOP
		_sql_text1 = '
			select
				coalesce (ma.last_name || chr(32) || ma.first_name, ma.group,ma.last_name,ma.group)::text
			from
				'|| _schema_meta ||'.melody_card_artist as mca
			inner join
				'|| _schema_meta ||'.melody_artist as ma
			on
				ma.melody_artist_id = mca.artist_id
			where
				mca.card_id = ''' || _row_res.melody_card_id || '''
			limit 1
		';
		FOR _row_res1 IN EXECUTE _sql_text1 LOOP
			select 
				_row_res.content_code::text,
				_row_res.melody_card_id::uuid, 
				_row_res.name::text,
				_row_res1::text,
				_row_res.tariff_id::integer,
				_row_res.section_id::integer
			into _row_res2;
			RETURN next _row_res2;		
		END LOOP;
	END LOOP;		

END IF;

end;
$$;

ALTER FUNCTION get_content_to_price_relations(INTEGER, INTEGER, INTEGER, BOOLEAN, BOOLEAN, TEXT, TEXT) OWNER TO postgres;

