CREATE FUNCTION create_region_temp() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
begin


SELECT  count(*) into _count
FROM 
	pg_class c
	JOIN pg_namespace ns ON (c.relnamespace = ns.oid) 
	WHERE
		relkind ='r' and nspname NOT IN ('pg_catalog', 'pg_toast','information_schema') and relname='region_new';
		

--RAISE EXCEPTION '%',_count;

IF (_count<>0) THEN
	DROP TABLE region_new;
END IF;		

CREATE TABLE region_new
(
  region integer NOT NULL,
  parent integer,
  "name" character varying(255) NOT NULL,
  ext_id integer
);
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE region_new TO inform;
EXECUTE 'COMMENT ON TABLE region_new IS ''creation date: ' || now()::varchar || '''';

end;
$$;

ALTER FUNCTION create_region_temp() OWNER TO postgres;

