CREATE FUNCTION update_file_compatibility(_file_id uuid, _supperted_phone_models integer[], _unsupported_phone_models integer[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_phone_model_id int;
	_count int;
BEGIN
	DELETE FROM supported_model WHERE file_id = _file_id;
	FOR i IN COALESCE(array_lower(_supperted_phone_models,1),0) .. COALESCE(array_upper(_supperted_phone_models,1),-1) LOOP
		_phone_model_id := _supperted_phone_models[i];
		SELECT COUNT(*) INTO _count FROM supported_model WHERE file_id = _file_id AND phone_model_id = _phone_model_id;
		IF (_count = 0) THEN
			INSERT INTO supported_model (file_id, phone_model_id) VALUES (_file_id, _phone_model_id);				
		END IF;
	END LOOP;

	DELETE FROM unsupported_model WHERE file_id = _file_id;
	FOR i IN COALESCE(array_lower(_unsupported_phone_models,1),0) .. COALESCE(array_upper(_unsupported_phone_models,1),-1) LOOP
		_phone_model_id := _unsupported_phone_models[i];
		SELECT COUNT(*) INTO _count FROM unsupported_model WHERE file_id = _file_id AND phone_model_id = _phone_model_id;
		IF (_count = 0) THEN
			INSERT INTO unsupported_model (file_id, phone_model_id) VALUES (_file_id, _phone_model_id);
		END IF;
	END LOOP;
	
END;
$$;

ALTER FUNCTION update_file_compatibility(UUID, INTEGER[], INTEGER[]) OWNER TO postgres;

