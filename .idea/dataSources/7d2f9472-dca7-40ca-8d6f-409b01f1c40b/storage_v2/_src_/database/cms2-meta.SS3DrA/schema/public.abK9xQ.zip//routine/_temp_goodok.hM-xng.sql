CREATE FUNCTION _temp_goodok() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	
	_row_goodok record;
	_card_id uuid;
	
begin


for _row in select distinct s.* from (select name,artist_id  from storefront.content
		inner join
			storefront.melody_card_artist on content.card_id= melody_card_artist.card_id) s
		inner join (
			select name,artist_id from melody_card inner join melody_card_artist on melody_card.melody_card_id= melody_card_artist.card_id ) m
		on s.name =m.name and s.artist_id=m.artist_id
	loop

	select content.card_id into _card_id from storefront.content 
		inner join storefront.melody_card_artist on content.card_id= melody_card_artist.card_id
	where content.name =_row.name and _row.artist_id=melody_card_artist.artist_id limit 1;


		for _row_goodok in 
			select distinct melody_card_artist.card_id from melody_card inner join melody_card_artist on melody_card.melody_card_id=melody_card_artist.card_id
				inner join card_goodok on melody_card_artist.card_id=card_goodok.card_id
			where name=_row.name and artist_id=_row.artist_id 
			limit 1  loop

			update 	card_goodok set card_id=_card_id where card_id=_row_goodok.card_id;

		 end loop;
	

end loop;




end;
$$;

ALTER FUNCTION _temp_goodok() OWNER TO postgres;

