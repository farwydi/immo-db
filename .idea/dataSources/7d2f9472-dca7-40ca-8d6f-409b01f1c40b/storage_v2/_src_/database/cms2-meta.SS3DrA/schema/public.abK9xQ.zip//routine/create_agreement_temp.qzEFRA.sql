CREATE FUNCTION create_agreement_temp() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
declare
	_count integer;
begin


SELECT  count(*) into _count
FROM 
	pg_class c
	JOIN pg_namespace ns ON (c.relnamespace = ns.oid) 
	WHERE
		relkind ='r' and nspname NOT IN ('pg_catalog', 'pg_toast','information_schema') and relname='agreement_new';
		

--RAISE EXCEPTION '%',_count;

IF (_count<>0) THEN
	DROP TABLE agreement_new;
END IF;		
CREATE TABLE agreement_new
(
  agreement integer NOT NULL,
  contragent integer NOT NULL,
  start_date timestamp without time zone NOT NULL,
  end_date timestamp without time zone NOT NULL,
  "no" character varying(100) NOT NULL,
  is_allied_rights boolean NOT NULL DEFAULT false
);
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE agreement_new TO inform;
EXECUTE 'COMMENT ON TABLE agreement_new IS ''creation date: ' || now()::varchar || '''';

end;
$$;

ALTER FUNCTION create_agreement_temp() OWNER TO postgres;

