CREATE FUNCTION prototype_remove_dublicate_cards(_schema_proto text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_dublicate record;
_total integer;
_count1 integer;
_count2 integer;
_sql_text text;
_sql_text1 text;
begin
_total = 0;
_sql_text = '
	select 
		c1.content_code::text,
		c1.card_id as card1,
		c2.card_id as card2,
		c1.content_id as content_id1,
		c2.content_id as content_id2
	from
		'||_schema_proto||'.content c1
	inner join
		'||_schema_proto||'.content c2 
	on
		c2.content_id > c1.content_id
	and
		c1.content_code = c2.content_code
	and
		c1.section_id = c2.section_id
	
';

for _dublicate in execute _sql_text
loop	
	raise notice '%', _dublicate.content_code;
	_sql_text1 = '
		select
			count(*)
		from
			'||_schema_proto||'.content
		where
			content_id = ' || _dublicate.content_id1 || ';
	';
	execute _sql_text1 into _count1;

	_sql_text1 = '
		select
			count(*)
		from
			'||_schema_proto||'.content
		where
			content_id = ' || _dublicate.content_id2 || ';
	';
	execute _sql_text1 into _count2;
	
	if _count1 > 0 and _count2 > 0 then

		_sql_text1 = '
			delete from 
				'||_schema_proto||'.content
			where
				content_id = ' || _dublicate.content_id1 || ';
		';
		
		execute _sql_text1;

		return next _dublicate;
		raise notice '%',_sql_text1;
		_total = _total + 1;			
					
	end if;
end loop;
raise info 'total: %',_total;
end;
$$;

ALTER FUNCTION prototype_remove_dublicate_cards(TEXT) OWNER TO postgres;

