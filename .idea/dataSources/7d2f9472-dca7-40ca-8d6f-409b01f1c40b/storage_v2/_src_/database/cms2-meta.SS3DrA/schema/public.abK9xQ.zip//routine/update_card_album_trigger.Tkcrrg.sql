CREATE FUNCTION update_card_album_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
DECLARE
    mod_date timestamp without time zone;
BEGIN
	mod_date := now();
		IF (TG_OP = 'DELETE') THEN

				update melody_card set modification_date=mod_date where melody_card_id=OLD.card_id;
				update melody_album set modification_date=mod_date where melody_album_id=OLD.album_id;

		ELSE
				update melody_card set modification_date=mod_date where melody_card_id=NEW.card_id;
				update melody_album set modification_date=mod_date where melody_album_id=NEW.album_id;

		END IF;


		RETURN null;
END;
$$;

ALTER FUNCTION update_card_album_trigger() OWNER TO postgres;

