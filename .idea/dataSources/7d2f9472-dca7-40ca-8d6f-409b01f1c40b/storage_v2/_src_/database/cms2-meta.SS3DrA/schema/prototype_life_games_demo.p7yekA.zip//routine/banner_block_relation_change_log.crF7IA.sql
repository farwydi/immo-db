CREATE FUNCTION banner_block_relation_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_life_games_demo.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', OLD.banner_id, 'D', 'banner_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.banner_id =  OLD.banner_id) THEN
				INSERT INTO prototype_life_games_demo.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', NEW.banner_id, 'U', 'banner_id');
			    ELSE
				INSERT INTO prototype_life_games_demo.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', NEW.banner_id, 'I', 'banner_id');
				INSERT INTO prototype_life_games_demo.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', OLD.banner_id, 'D', 'banner_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_life_games_demo.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', NEW.banner_id, 'I', 'banner_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION banner_block_relation_change_log() OWNER TO inform;

