CREATE FUNCTION banner_block_relation_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', OLD.banner_id, 'D', 'banner_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', NEW.banner_id, 'U', 'banner_id');
			    RETURN NEW;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_int_id, "action", "key") VALUES ('banner_block_relation', NEW.banner_id, 'I', 'banner_id');
			    RETURN NEW;
			END IF;    
		    END;

$$;

ALTER FUNCTION banner_block_relation_change_log() OWNER TO inform;

