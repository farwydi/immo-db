CREATE FUNCTION reindex_index(_index text) RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
begin
execute 'reindex index ' || _index;
end;
$$;

ALTER FUNCTION reindex_index(TEXT) OWNER TO postgres;

