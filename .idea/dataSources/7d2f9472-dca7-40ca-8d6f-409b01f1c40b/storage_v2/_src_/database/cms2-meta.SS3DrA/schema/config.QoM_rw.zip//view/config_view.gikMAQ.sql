CREATE VIEW config_view(storefront_id, storefront, key, def, params) AS
SELECT s.storefront_id,
	   s.name                                               AS storefront,
	   (cpt.name::TEXT || '_'::TEXT) || cp.short_name::TEXT AS key,
	   scp.is_use_default                                   AS def,
	   CASE
		   WHEN scp.is_use_default IS FALSE THEN array_to_string(ARRAY(SELECT scp2.value
																	   FROM config.storefront_configuration_parameter scp2
																	   WHERE scp2.configuration_parameter_id = cp.configuration_parameter_id
																		 AND s.storefront_id = scp2.storefront_id),
																 ', '::TEXT)
		   WHEN scp.is_use_default IS TRUE THEN array_to_string(ARRAY(SELECT scp3.value
																	  FROM config.storefront_configuration_parameter scp3
																	  WHERE scp3.configuration_parameter_id = cp.configuration_parameter_id
																		AND scp3.storefront_id IS NULL), ', '::TEXT)
		   ELSE NULL::TEXT
		   END                                              AS params
FROM config.storefront s
		 JOIN config.storefront_configuration_parameter scp ON s.storefront_id = scp.storefront_id
		 JOIN config.configuration_parameter cp ON cp.configuration_parameter_id = scp.configuration_parameter_id
		 JOIN config.configuration_parameter_type cpt
			  ON cpt.configuration_parameter_type_id = cp.configuration_parameter_type_id
GROUP BY s.storefront_id, cpt.name, cp.short_name, s.name, scp.is_use_default, cp.configuration_parameter_id
ORDER BY s.storefront_id, cpt.name, cp.short_name;

ALTER TABLE config_view
	OWNER TO postgres;

