CREATE FUNCTION create_change_log_trigger(_scheme text, _change_log_table text, _table text, _key text, _type text) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_query text;
	_id_col text;
begin
	select case _type when 'uuid' then 'object_id' when 'integer' then 'object_int_id' when 'string' then 'object_str_id' end into _id_col;
	if _id_col is null then
		raise exception 'Bad type provided';
	end if;
	_query := 'CREATE OR REPLACE FUNCTION ' || _scheme || '.' || _table || '_change_log()
		  RETURNS trigger AS
		$FOO$
		    BEGIN
			IF (TG_OP = ''DELETE'') THEN
			    INSERT INTO ' || _scheme || '.' || _change_log_table || '(table_name, ' || _id_col || ', "action", "key") VALUES (''' || _table || ''', OLD.' || _key || ', ''D'', ''' || _key || ''');
			    RETURN OLD;
			ELSIF (TG_OP = ''UPDATE'') THEN
			    IF (NEW.' || _key || ' =  OLD.' || _key || ') THEN
				INSERT INTO ' || _scheme || '.' || _change_log_table || '(table_name, ' || _id_col || ', "action", "key") VALUES (''' || _table || ''', NEW.' || _key || ', ''U'', ''' || _key || ''');
			    ELSE
				INSERT INTO ' || _scheme || '.' || _change_log_table || '(table_name, ' || _id_col || ', "action", "key") VALUES (''' || _table || ''', NEW.' || _key || ', ''I'', ''' || _key || ''');
				INSERT INTO ' || _scheme || '.' || _change_log_table || '(table_name, ' || _id_col || ', "action", "key") VALUES (''' || _table || ''', OLD.' || _key || ', ''D'', ''' || _key || ''');
			    END IF;
			ELSIF (TG_OP = ''INSERT'') THEN
			    INSERT INTO ' || _scheme || '.' || _change_log_table || '(table_name, ' || _id_col || ', "action", "key") VALUES (''' || _table || ''', NEW.' || _key || ', ''I'', ''' || _key || ''');
			END IF;    
			RETURN NEW;
		    END;
		$FOO$
		  LANGUAGE plpgsql VOLATILE
		  COST 100;

		DROP TRIGGER IF EXISTS change_log ON ' || _scheme || '.' || _table || ' CASCADE;
		
		CREATE TRIGGER change_log
		  AFTER INSERT OR UPDATE OR DELETE
		  ON ' || _scheme || '.' || _table || '
		  FOR EACH ROW
		  EXECUTE PROCEDURE ' || _scheme || '.' || _table || '_change_log();';
	EXECUTE _query;
end;
$$;

ALTER FUNCTION create_change_log_trigger(TEXT, TEXT, TEXT, TEXT, TEXT) OWNER TO postgres;

