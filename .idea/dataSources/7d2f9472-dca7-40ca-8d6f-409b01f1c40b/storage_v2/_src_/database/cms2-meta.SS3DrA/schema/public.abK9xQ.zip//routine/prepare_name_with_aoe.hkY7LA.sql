CREATE FUNCTION prepare_name_with_aoe(arg character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE plpgsql
AS
$$
DECLARE


BEGIN
    

RETURN translate (
public.prepare_name(arg),
'ÀÁÂÃÄÅÒÓÔÕÖÈÉÊËЁ',
'AAAAAAOOOOOEEEEЕ'); -- последняя - кириллица ё на е


END


$$;

ALTER FUNCTION prepare_name_with_aoe(VARCHAR) OWNER TO postgres;

