CREATE FUNCTION escape_name(arg character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE plpgsql
AS
$$
DECLARE
    
BEGIN

    RETURN replace(replace(replace(replace(arg,'>','&gt;'),'<','&lt;'),'&','&amp;'),'"','&quot;');
    
END
$$;

ALTER FUNCTION escape_name(VARCHAR) OWNER TO inform;

