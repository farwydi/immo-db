CREATE FUNCTION add_top_content_by_content_code(_content_code text, _section_id integer, _top_type text, _schema_proto text) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_row_res record;
_card_id uuid;
_section_top_id uuid;
_founded integer;
_r1 text;
_r2 text;
begin
	_sql_text = '
		select
			card_id
		from
			'|| _schema_proto ||'.content
		where
			content_code=\'' || _content_code ||'\'
		limit 1
	';
	EXECUTE _sql_text into _card_id;

	_sql_text = '
		select
			section_' || _top_type ||'_id
		from
			'|| _schema_proto ||'.section_' || _top_type ||'
		where
			section_id = '|| _section_id ||' 
		limit 1
	';	
	EXECUTE _sql_text into _section_top_id;

	if(not(_card_id is null) and not(_section_top_id is null)) THEN
		RAISE NOTICE '%',_card_id;
		RAISE NOTICE '%',_section_top_id;
		_sql_text = '
			select
				count(*)
			from
				'|| _schema_proto ||'.section_' || _top_type ||'_content
			where
				section_' || _top_type ||'_id = \'' || _section_top_id || '\'
			and
				card_id = \'' || _card_id || '\'				
		';
		EXECUTE _sql_text into _founded;
		RAISE NOTICE 'founded:%',_founded;
		if _founded = 0 then
			_r1 = '';
			_r2 = '';
			if _top_type='top' then
				_r1 = ',rating,rating_old';
				_r2 = ',1,1';
			end if;
			
			_sql_text = '
				INSERT INTO 
					'|| _schema_proto ||'.section_' || _top_type ||'_content
					(
						section_' || _top_type ||'_id, 
						card_id
						'|| _r1 ||'
					)
				VALUES 
				(
					\'' || _section_top_id || '\', 
					\'' || _card_id || '\'
					'|| _r2 ||'
				);
			';
			RAISE NOTICE '%',_sql_text;
			EXECUTE _sql_text;
		end if;	
		return true;	
	ELSE
		return false;
	END IF;
end;
$$;

ALTER FUNCTION add_top_content_by_content_code(TEXT, INTEGER, TEXT, TEXT) OWNER TO postgres;

