CREATE FUNCTION prototype_add_top_content(_card_id uuid, _section_id integer, _schema_proto text) RETURNS boolean
	LANGUAGE plpgsql
AS
$$
declare
_sql_text text;
_row_res record;
_founded integer;
begin
	_sql_text = '
		select 
			count(*)
		from 
			'|| _schema_proto ||'.section_top 
		where 
			section_id = '|| _section_id ||'
	';	
	EXECUTE _sql_text into _founded;
	IF (_founded = 0) THEN
	return false;
	END IF;
	
	_sql_text = '
		select 
			count(*) as c
		from
			'|| _schema_proto ||'.section_top_content as sta
		where
			section_top_id = 
			(
				select 
					section_top_id 
				from 
					'|| _schema_proto ||'.section_top 
				where 
					section_id = '|| _section_id ||'
					limit 1
			)
		and
			card_id = ''' || _card_id || '''
	';
	EXECUTE _sql_text into _founded;

	IF (_founded = 0) THEN
		_sql_text = '
			INSERT INTO '|| _schema_proto ||'.section_top_content(
				    section_top_id, card_id, rating, rating_old)
			    VALUES (
				(select 
					section_top_id 
				from 
					'|| _schema_proto ||'.section_top 
				where 
					section_id = '|| _section_id ||' limit 1
				), 
			    ''' || _card_id || ''', 
			    1, 
			    1);
		';
		EXECUTE _sql_text;
		return true;
	ELSE
		return false;
	END IF;

end;
$$;

ALTER FUNCTION prototype_add_top_content(UUID, INTEGER, TEXT) OWNER TO postgres;

