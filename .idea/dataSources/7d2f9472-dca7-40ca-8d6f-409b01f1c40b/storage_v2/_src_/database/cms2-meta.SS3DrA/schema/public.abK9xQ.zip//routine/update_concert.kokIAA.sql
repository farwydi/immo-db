CREATE FUNCTION update_concert(id uuid, _title character varying, _body text, _display_start_date timestamp without time zone, _expiration_date timestamp without time zone, _start_date timestamp without time zone, _end_date timestamp without time zone, _location character varying, _artistids uuid[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	_news_type_id int;
	artistId uuid;
BEGIN
	_news_type_id := 3;	
	UPDATE news_type SET "name" = 'Концерты', display_name = 'Концерты' WHERE news_type_id = _news_type_id;
	IF NOT FOUND THEN
	INSERT INTO news_type (news_type_id, "name", display_name) VALUES (_news_type_id, 'Концерты', 'Концерты');
	END IF;

	UPDATE news SET 
		news_type_id = _news_type_id,
		title = _title,
		body = _body,
		display_start_date = _display_start_date,
		expiration_date = _expiration_date,
		start_date = _start_date,
		end_date = _end_date,
		location = _location
	WHERE
		news_id = id;
	IF NOT FOUND THEN
	INSERT INTO news
	(
		news_id,
		news_type_id,
		title,
		body,
		display_start_date,
		expiration_date,
		start_date,
		end_date,
		location	
	)
	VALUES
	(
		id,
		_news_type_id,
		_title,
		_body,
		_display_start_date,
		_expiration_date,
		_start_date,
		_end_date,
		_location
	);
	END IF;

	DELETE FROM news_album WHERE news_id = id;
	
	FOR i IN COALESCE(array_lower(_artistids,1),0) .. COALESCE(array_upper(_artistids,1),-1) LOOP
	artistId:=_artistids[i];
	INSERT INTO news_album (news_id, artist_id) VALUES (id, artistId);

	END LOOP;
	
END;
$$;

ALTER FUNCTION update_concert(UUID, VARCHAR, TEXT, TIMESTAMP, TIMESTAMP, TIMESTAMP, TIMESTAMP, VARCHAR, UUID[]) OWNER TO postgres;

