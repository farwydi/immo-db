CREATE FUNCTION update_melody_artist_genre_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
		update melody_artist set modification_date=now() where melody_artist_id=OLD.artist_id;
        ELSE
		update melody_artist set modification_date=now() where melody_artist_id=NEW.artist_id;
        END IF;
        
        RETURN null;
    END;
$$;

ALTER FUNCTION update_melody_artist_genre_trigger() OWNER TO postgres;

