CREATE VIEW storefront_region(storefront_id, region_id) AS
SELECT foo.storefront_id,
	   COALESCE(scp.value, foo.value)::INTEGER AS region_id
FROM (SELECT s.storefront_id,
			 scp_1.value,
			 cp.configuration_parameter_id,
			 scp_1.is_use_default
	  FROM config.storefront s
			   JOIN config.storefront_configuration_parameter scp_1 ON s.storefront_id = scp_1.storefront_id
			   JOIN config.configuration_parameter cp
					ON cp.configuration_parameter_id = scp_1.configuration_parameter_id
			   JOIN config.configuration_parameter_type cpt
					ON cpt.configuration_parameter_type_id = cp.configuration_parameter_type_id
	  WHERE cp.short_name::TEXT = 'region'::TEXT) foo
		 LEFT JOIN config.storefront_configuration_parameter scp
				   ON scp.storefront_id IS NULL AND scp.configuration_parameter_id = foo.configuration_parameter_id AND
					  foo.is_use_default IS TRUE
ORDER BY foo.storefront_id;

ALTER TABLE storefront_region
	OWNER TO postgres;

