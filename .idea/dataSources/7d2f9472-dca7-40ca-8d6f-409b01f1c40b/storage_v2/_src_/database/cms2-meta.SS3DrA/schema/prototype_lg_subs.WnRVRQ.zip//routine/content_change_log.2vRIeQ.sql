CREATE FUNCTION content_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_str_id, "action", "key") VALUES ('content', OLD.content_code, 'D', 'content_code');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_str_id, "action", "key") VALUES ('content', NEW.content_code, 'U', 'content_code');
			    RETURN NEW;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lg_subs.change_log(table_name, object_str_id, "action", "key") VALUES ('content', NEW.content_code, 'I', 'content_code');
			    RETURN NEW;
			END IF;    
		    END;

$$;

ALTER FUNCTION content_change_log() OWNER TO inform;

