CREATE FUNCTION delete_new_theme_card(card_id uuid) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
                --delete user relations
                DELETE FROM user_new_content WHERE new_source_id IN
                (
                               SELECT card_id
                               union
                               SELECT new_file_id from new_card_file where new_card_id = card_id
                               union
                               SELECT new_preview_id from new_preview_relation where source_id = card_id
                );
 
                --delete new theme files
                DELETE FROM new_supported_model where new_file_id in (SELECT new_file_id from new_card_file where new_card_id = card_id);
                DELETE FROM new_unsupported_model where new_file_id in (SELECT new_file_id from new_card_file where new_card_id = card_id);
                DELETE FROM new_theme_file WHERE new_theme_file_id in (SELECT new_file_id from new_card_file where new_card_id = card_id);
                DELETE FROM new_card_file WHERE new_card_id = card_id;
 
                --delete previews
                DELETE FROM new_preview_picture WHERE new_preview_picture_id in (SELECT new_preview_id from new_preview_relation where source_id = card_id);
                DELETE FROM new_preview_relation WHERE source_id = card_id;
 
                --delete tags relations
                delete from new_theme_card_tag where new_card_id = card_id;
 
                --delete genre relations
                delete from new_theme_card_genre where new_card_id = card_id;
 
                --delete new theme card
                DELETE FROM new_theme_card WHERE new_theme_card_id = card_id;
 
END;
$$;

ALTER FUNCTION delete_new_theme_card(UUID) OWNER TO postgres;

