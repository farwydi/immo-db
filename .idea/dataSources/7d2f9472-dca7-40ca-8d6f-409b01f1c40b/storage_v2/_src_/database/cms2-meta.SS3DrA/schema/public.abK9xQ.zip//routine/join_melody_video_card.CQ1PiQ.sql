CREATE FUNCTION join_melody_video_card(main_card uuid, card uuid) RETURNS uuid
	LANGUAGE plpgsql
AS
$$
declare 
 _count integer;
 _count1 integer;
 
begin
 
select count(*) into _count from melody_card where melody_card.melody_card_id = main_card;
select count(*) into _count1 from video_card where video_card.video_card_id = card;
 
if (_count=0 and _count1=0) then 
 return '00000000-0000-0000-0000-000000000000';
end if;
 
if (_count > 0 and _count1 = 0) then 
 return main_card;
end if;
 
update card_file set card_id = main_card where card_id = card;
update preview_relation set source_id = main_card where source_id = card;
 
delete from video_card where video_card_id = card;
 
update recycle set original_id = main_card where original_id = card;
insert into recycle (original_id, deleted_id) select main_card, card;
 
return main_card;
end;
$$;

ALTER FUNCTION join_melody_video_card(UUID, UUID) OWNER TO postgres;

