CREATE FUNCTION get_card_by_filter(_filter_id integer, _table text) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare 
                _row record;
                _where text;
                _sql text;
begin
_where = '';
for 
                _row 
in 
                select 
                               "table", 
                               "column", 
                               filter_operation.value as operation, 
                               filter_condition.value,
                               is_union,
                               coalesce(is_melody,false) as is_melody,
                               coalesce(is_video,false) as is_video,  
                               coalesce(is_java,false) as is_java,
                               coalesce(is_picture,false) as is_picture,
                               coalesce(is_theme,false) as is_theme
                from 
                               filter 
                inner join filter_condition on filter_condition.filter_id=filter.filter_id
                inner join filter_operation on filter_condition.filter_operation_id=filter_operation.filter_operation_id
                inner join filter_column on filter_condition.filter_column_id=filter_column.filter_column_id
                where filter.filter_id=_filter_id
loop
                if 
                               _row.is_melody  and _table = 'melody_card'  or
                               _row.is_video   and _table = 'video_card'   or
                               _row.is_java    and _table = 'java_card'    or
                               _row.is_picture and _table = 'picture_card' or
                               _row.is_theme   and _table = 'theme_card'
                then

                               if (_where <> '') THEN
                                               if (_row.is_union) THEN
                                                               _where = _where || ' or ';
                                               ELSE
                                                               _where = _where || ' and ';
                                               END IF;
                               ELSE
                                               _where=' where ';
                               END IF;
                               _where = _where || _row.table || '.' || _row.column || _row.operation || _row.value;

                end if;
end loop;

_sql = '';

if _where <> '' and _table='melody_card' then
                _sql = 'select distinct melody_card.melody_card_id from melody_card 
                               inner join melody_card_artist on melody_card.melody_card_id=melody_card_artist.card_id
                               inner join melody_artist_genre on melody_artist_genre.artist_id=melody_card_artist.artist_id
                               inner join card_file on melody_card.melody_card_id = card_file.card_id
                               left join rbt_code on rbt_code.file_id = card_file.file_id '
                                || _where;
end if;

if _where <> '' and _table = 'video_card' then
                _sql = _sql || 'select distinct video_card_id from video_card 
                               inner join video_card_genre on video_card.video_card_id=video_card_genre.card_id' || _where;
end if;

if _where <> '' and _table = 'java_card' then
                _sql = _sql || 'select distinct java_card.java_card_id from java_card 
                               left join java_card_tag on java_card_tag.java_card_id = java_card.java_card_id' || _where;                  
end if;

if _where <> '' and _table = 'picture_card' then
                _sql = _sql || 'select distinct picture_card.picture_card_id from picture_card
                               left join picture_card_genre on picture_card_genre.card_id = picture_card.picture_card_id' || _where;                               
end if;

if _where <> '' and _table = 'theme_card' then
                _sql = _sql || 'select distinct theme_card.theme_card_id from theme_card
                               left join theme_card_genre on theme_card_genre.card_id = theme_card.theme_card_id' || _where;                               
end if;

if _sql <> '' then
                
                for _row in execute _sql loop
                               return next _row;
                end loop;
end if;


end;
$$;

ALTER FUNCTION get_card_by_filter(INTEGER, TEXT) OWNER TO postgres;

