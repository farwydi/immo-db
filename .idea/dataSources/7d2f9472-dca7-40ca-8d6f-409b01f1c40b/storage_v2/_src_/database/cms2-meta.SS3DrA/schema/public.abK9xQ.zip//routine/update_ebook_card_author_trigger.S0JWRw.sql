CREATE FUNCTION update_ebook_card_author_trigger() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN

		        IF (TG_OP = 'DELETE') THEN
				                update ebook_card set modification_date=now() where ebook_card_id=OLD.card_id;
								                update ebook_author set modification_date=now() where ebook_author_id=OLD.author_id;
												        ELSE
														                update ebook_card set modification_date=now() where ebook_card_id=NEW.card_id;
																		                update ebook_author set modification_date=now() where ebook_author_id=NEW.author_id;
																						        END IF;

																								        RETURN null;
																										END;

$$;

ALTER FUNCTION update_ebook_card_author_trigger() OWNER TO postgres;

