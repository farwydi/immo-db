CREATE FUNCTION user_category_access_point_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category_access_point', OLD.user_category_id, 'D', 'user_category_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.user_category_id =  OLD.user_category_id) THEN
				INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category_access_point', NEW.user_category_id, 'U', 'user_category_id');
			    ELSE
				INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category_access_point', NEW.user_category_id, 'I', 'user_category_id');
				INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category_access_point', OLD.user_category_id, 'D', 'user_category_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lmj_picture.change_log(table_name, object_int_id, "action", "key") VALUES ('user_category_access_point', NEW.user_category_id, 'I', 'user_category_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION user_category_access_point_change_log() OWNER TO inform;

