CREATE FUNCTION user_format_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lmj_geo.change_log(table_name, object_int_id, "action", "key") VALUES ('user_format', OLD.user_format_id, 'D', 'user_format_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.user_format_id =  OLD.user_format_id) THEN
				INSERT INTO prototype_lmj_geo.change_log(table_name, object_int_id, "action", "key") VALUES ('user_format', NEW.user_format_id, 'U', 'user_format_id');
			    ELSE
				INSERT INTO prototype_lmj_geo.change_log(table_name, object_int_id, "action", "key") VALUES ('user_format', NEW.user_format_id, 'I', 'user_format_id');
				INSERT INTO prototype_lmj_geo.change_log(table_name, object_int_id, "action", "key") VALUES ('user_format', OLD.user_format_id, 'D', 'user_format_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lmj_geo.change_log(table_name, object_int_id, "action", "key") VALUES ('user_format', NEW.user_format_id, 'I', 'user_format_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION user_format_change_log() OWNER TO inform;

