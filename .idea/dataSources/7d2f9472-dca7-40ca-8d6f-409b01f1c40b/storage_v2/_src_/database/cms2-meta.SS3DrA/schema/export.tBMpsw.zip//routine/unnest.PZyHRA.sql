CREATE FUNCTION unnest(anyarray) RETURNS SETOF anyelement
	IMMUTABLE
	LANGUAGE sql
AS
$$
SELECT $1[i] FROM
    generate_series(array_lower($1,1),
                    array_upper($1,1)) i;
$$;

ALTER FUNCTION unnest(ANYARRAY) OWNER TO inform;

