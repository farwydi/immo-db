CREATE FUNCTION swap_agreement2region() RETURNS void
	LANGUAGE sql
AS
$$
	ALTER TABLE agreement2region RENAME TO agreement2region_old;

ALTER TABLE agreement2region_temp RENAME TO agreement2region;

DROP TABLE agreement2region_old CASCADE;

ALTER TABLE agreement2region
  ADD CONSTRAINT pk_agreement2region PRIMARY KEY(agreement2region);

CREATE INDEX ix_agreement2region_agreement
  ON agreement2region
  USING btree
  (agreement);

CREATE INDEX ix_agreement2region_region
  ON agreement2region
  USING btree
  (region);

	$$;

ALTER FUNCTION swap_agreement2region() OWNER TO postgres;

