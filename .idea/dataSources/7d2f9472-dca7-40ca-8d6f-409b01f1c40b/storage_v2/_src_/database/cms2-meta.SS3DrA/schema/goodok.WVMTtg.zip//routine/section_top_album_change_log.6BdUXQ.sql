CREATE FUNCTION section_top_album_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO goodok.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', OLD.album_id, 'D', 'album_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.album_id =  OLD.album_id) THEN
				INSERT INTO goodok.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', NEW.album_id, 'U', 'album_id');
			    ELSE
				INSERT INTO goodok.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', NEW.album_id, 'I', 'album_id');
				INSERT INTO goodok.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', OLD.album_id, 'D', 'album_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO goodok.change_log(table_name, object_id, "action", "key") VALUES ('section_top_album', NEW.album_id, 'I', 'album_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION section_top_album_change_log() OWNER TO inform;

