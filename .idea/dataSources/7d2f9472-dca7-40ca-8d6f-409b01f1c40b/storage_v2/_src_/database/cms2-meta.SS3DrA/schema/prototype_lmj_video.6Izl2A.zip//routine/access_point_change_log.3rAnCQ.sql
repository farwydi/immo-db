CREATE FUNCTION access_point_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO prototype_lmj_video.change_log(table_name, object_int_id, "action", "key") VALUES ('access_point', OLD.access_point_id, 'D', 'access_point_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.access_point_id =  OLD.access_point_id) THEN
				INSERT INTO prototype_lmj_video.change_log(table_name, object_int_id, "action", "key") VALUES ('access_point', NEW.access_point_id, 'U', 'access_point_id');
			    ELSE
				INSERT INTO prototype_lmj_video.change_log(table_name, object_int_id, "action", "key") VALUES ('access_point', NEW.access_point_id, 'I', 'access_point_id');
				INSERT INTO prototype_lmj_video.change_log(table_name, object_int_id, "action", "key") VALUES ('access_point', OLD.access_point_id, 'D', 'access_point_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO prototype_lmj_video.change_log(table_name, object_int_id, "action", "key") VALUES ('access_point', NEW.access_point_id, 'I', 'access_point_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION access_point_change_log() OWNER TO inform;

