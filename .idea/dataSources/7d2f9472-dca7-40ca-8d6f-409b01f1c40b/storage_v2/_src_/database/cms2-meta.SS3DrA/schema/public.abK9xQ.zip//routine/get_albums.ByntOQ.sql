CREATE FUNCTION get_albums(_melody_card_id uuid) RETURNS text
	LANGUAGE plpgsql
AS
$$
declare
_card_id uuid;
_guid_empty uuid;

_sql_text text;

_row record;
_row_temp record;
_res_record record;

_album_name text;
_album_name_temp text;

_album_uuid text;

_pattern text;
_delimiter text;

_i integer;

begin


_sql_text:= 'SELECT 	distinct 	melody_card_album.card_id, 
			melody_album.melody_album_id,
			melody_album.name
	     FROM
			melody_card_album  
			LEFT JOIN melody_album  
				ON  melody_card_album.album_id=melody_album.melody_album_id 
			WHERE  melody_card_album.card_id = ''' || _melody_card_id || '''

			ORDER BY melody_card_album.card_id, melody_album.name';


_card_id:='00000000-0000-0000-0000-000000000000'; 
_guid_empty:='00000000-0000-0000-0000-000000000000'; 
_album_name:='';
_delimiter:= ';';

_i:=0;

FOR _row IN EXECUTE _sql_text LOOP
	IF (_card_id<>_row.card_id) THEN
	
		_album_name=COALESCE( _row.name,'');
		
		_album_name=trim(both ' ' from _album_name);
		
	ELSE
		_album_name_temp=COALESCE( _row.name,'');
		_album_name_temp=trim(both ' ' from _album_name_temp);

		_album_name:=_album_name || _delimiter || _album_name_temp;
	
	END IF;

	_card_id=_row.card_id;
	
END LOOP;

IF (_card_id<>_guid_empty) THEN
		return _album_name;
		
else
	return '-';
END IF;
end;
$$;

ALTER FUNCTION get_albums(UUID) OWNER TO postgres;

