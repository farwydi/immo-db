CREATE FUNCTION update_melody_number_in_album(_album_id uuid, _card_id uuid, _number smallint) RETURNS void
	LANGUAGE plpgsql
AS
$$
declare
	_row record;
	_count integer;
BEGIN
	
	
		for _row in select *
				from melody_card_album mca
				where mca.album_id = _album_id
				and mca.card_id = _card_id
		loop
			-- определяем максимальный оперделенный номер песни
				select max(number_in_album) into _count
				from melody_card_album
				where album_id = _album_id;
			IF _row.number_in_album is null then   					--0
				
				
				IF _count is null then       					--1
						UPDATE melody_card_album
						SET number_in_album= '1'
						where album_id = _album_id
						and card_id = _card_id;
				
				else								--1
					IF _number <= _count then				--2
					-- задаем номер песне
						UPDATE melody_card_album
							SET number_in_album= _number
							where album_id = _album_id
							and card_id = _card_id;
					-- сдвигаем номера песен на 1
						update melody_card_album
							set number_in_album = number_in_album + 1
							where album_id = _album_id
							and number_in_album is not null
							and card_id != _card_id
							and number_in_album >= _number;
					else							--2
						UPDATE melody_card_album
							SET number_in_album= _count+1
							where album_id = _album_id
							and card_id = _card_id;
					end IF;							--2
					end if;							--1
				ELSE								--0
					if _number > _row.number_in_album then			--3
					--	if _number<=_count then			--4
						
						-- сдвигаем на один вверх все песни между старой и новой позицией
							update melody_card_album
							set number_in_album = number_in_album - 1
							where album_id = _album_id
							and number_in_album is not null
							and card_id != _card_id
							and number_in_album > _row.number_in_album
							and number_in_album <= _number;
						-- задаем номер песне
						if _count < _number then
							UPDATE melody_card_album
								SET number_in_album= _count
								where album_id = _album_id
								and card_id = _card_id;	
						else
							UPDATE melody_card_album
								SET number_in_album= _number
								where album_id = _album_id
								and card_id = _card_id;
						end if;
					--	else						--4
						
						-- сдвигаем на один вверх все песни между старой и новой позицией
					--		update melody_card_album
					--		set number_in_album = number_in_album - 1
					--		where album_id = _album_id
					--		and number_in_album is not null
					--		and card_id != _card_id
					--		and number_in_album > _row.number_in_album;						  -- задаем номер песне
					--		UPDATE melody_card_album
					--			SET number_in_album= _count
					--			where album_id = _album_id
					--			and card_id = _card_id;	
					--	end if;						--4
					else							--3
						--if _number < _row.number_in_album then		--5
						-- задаем номер песне
							if _number > '0' then			--6
							UPDATE melody_card_album
								SET number_in_album= _number
								where album_id = _album_id
								and card_id = _card_id;		
							else					--6
								UPDATE melody_card_album
								SET number_in_album= 1
								where album_id = _album_id
								and card_id = _card_id;		
							end if;					--6
						-- сдвигаем на один вниз все песни между старой и новой позицией
							update melody_card_album
							set number_in_album = number_in_album + 1
							where album_id = _album_id
							and number_in_album is not null
							and card_id != _card_id
							and number_in_album < _row.number_in_album
							and number_in_album >= _number;
						--end if;						--5
					end if;							--3
					
			end IF;	 								--0
		end loop;
	

END;
$$;

ALTER FUNCTION update_melody_number_in_album(UUID, UUID, SMALLINT) OWNER TO postgres;

