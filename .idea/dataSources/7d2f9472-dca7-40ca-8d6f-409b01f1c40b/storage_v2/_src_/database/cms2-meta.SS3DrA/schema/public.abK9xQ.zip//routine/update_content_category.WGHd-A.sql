CREATE FUNCTION update_content_category(id integer, _name character varying) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	UPDATE content_category SET name = _name WHERE content_category_id = id;
	IF NOT FOUND THEN
		INSERT INTO content_category (content_category_id, name) VALUES (id, _name);
	END IF;
END;
$$;

ALTER FUNCTION update_content_category(INTEGER, VARCHAR) OWNER TO postgres;

