CREATE FUNCTION delete_video_genre(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM video_genre WHERE video_genre_id = id;
END;
$$;

ALTER FUNCTION delete_video_genre(INTEGER) OWNER TO postgres;

