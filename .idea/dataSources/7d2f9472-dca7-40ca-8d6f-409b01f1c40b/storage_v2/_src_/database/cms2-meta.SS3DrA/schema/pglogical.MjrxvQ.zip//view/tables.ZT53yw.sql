CREATE VIEW tables(relid, nspname, relname, set_name) AS
WITH set_relations AS (
	SELECT s.set_name,
		   r.set_reloid
	FROM pglogical.replication_set_table r,
		 pglogical.replication_set s,
		 pglogical.local_node n
	WHERE s.set_nodeid = n.node_id
	  AND s.set_id = r.set_id
),
	 user_tables AS (
		 SELECT r.oid,
				n.nspname,
				r.relname,
				r.relreplident
		 FROM pg_class r,
			  pg_namespace n
		 WHERE r.relkind = 'r'::"char"
		   AND r.relpersistence = 'p'::"char"
		   AND n.oid = r.relnamespace
		   AND n.nspname !~ '^pg_'::TEXT
		   AND n.nspname <> 'information_schema'::NAME
		   AND n.nspname <> 'pglogical'::NAME
	 )
SELECT r.oid AS relid,
	   n.nspname,
	   r.relname,
	   s.set_name
FROM pg_namespace n,
	 pg_class r,
	 set_relations s
WHERE r.relkind = 'r'::"char"
  AND n.oid = r.relnamespace
  AND r.oid = s.set_reloid::OID
UNION
SELECT t.oid      AS relid,
	   t.nspname,
	   t.relname,
	   NULL::NAME AS set_name
FROM user_tables t
WHERE NOT (t.oid IN (SELECT set_relations.set_reloid
					 FROM set_relations));

ALTER TABLE tables
	OWNER TO postgres;

