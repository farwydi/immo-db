CREATE FUNCTION delete_java_genre(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM java_genre WHERE java_genre_id = id;
END;
$$;

ALTER FUNCTION delete_java_genre(INTEGER) OWNER TO postgres;

