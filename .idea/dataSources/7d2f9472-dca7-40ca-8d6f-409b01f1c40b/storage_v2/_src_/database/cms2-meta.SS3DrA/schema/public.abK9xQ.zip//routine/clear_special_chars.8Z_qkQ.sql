CREATE FUNCTION clear_special_chars(arg character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
    RETURN translate(arg,$H$!@#$%^&*()+=\"№?{}:;|/.,''`~<>«»…’©®™–]+[$H$,''); 
END
$$;

ALTER FUNCTION clear_special_chars(VARCHAR) OWNER TO postgres;

