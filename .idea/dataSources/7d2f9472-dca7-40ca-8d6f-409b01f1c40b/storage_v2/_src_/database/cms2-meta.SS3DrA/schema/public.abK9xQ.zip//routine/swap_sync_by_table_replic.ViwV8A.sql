CREATE FUNCTION swap_sync_by_table_replic(t character varying) RETURNS boolean
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
DECLARE
   _c int;
   _sql varchar;
BEGIN
       SELECT INTO _c count(*) FROM pg_tables where schemaname = 'public' and tablename in (t || '_new', t);
       IF (_c = 2)
       THEN  
	   execute 'DROP TABLE ' || t;	
	   execute 'ALTER TABLE ' || t || '_new RENAME TO ' || t;

		FOR _sql IN SELECT 'ALTER TABLE "'||relname||'" DROP CONSTRAINT  "'||conname||'";'
					 FROM pg_constraint 
					 INNER JOIN pg_class ON conrelid=pg_class.oid 
					 INNER JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					 where nspname = 'public' and relname = t || '_new' LOOP
			EXECUTE _sql;
		END LOOP;	   
	   FOR _sql IN SELECT 'DROP INDEX "'||nspname||'"."'||pg_class.relname||'" RESTRICT;'
					FROM pg_index
					JOIN pg_class ON indexrelid=pg_class.oid
					JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace
					JOIN pg_class c on indrelid = c.oid
					WHERE nspname = 'public' and c.relname = t || '_new' LOOP
			EXECUTE _sql;
		END LOOP;				
	   
        RETURN true;
       END IF;
    RETURN false;
END;
$$;

ALTER FUNCTION swap_sync_by_table_replic(VARCHAR) OWNER TO postgres;

