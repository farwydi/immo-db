CREATE FUNCTION price_category_change_log() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
			IF (TG_OP = 'DELETE') THEN
			    INSERT INTO goodok.change_log(table_name, object_int_id, "action", "key") VALUES ('price_category', OLD.tariff_id, 'D', 'tariff_id');
			    RETURN OLD;
			ELSIF (TG_OP = 'UPDATE') THEN
			    IF (NEW.tariff_id =  OLD.tariff_id) THEN
				INSERT INTO goodok.change_log(table_name, object_int_id, "action", "key") VALUES ('price_category', NEW.tariff_id, 'U', 'tariff_id');
			    ELSE
				INSERT INTO goodok.change_log(table_name, object_int_id, "action", "key") VALUES ('price_category', NEW.tariff_id, 'I', 'tariff_id');
				INSERT INTO goodok.change_log(table_name, object_int_id, "action", "key") VALUES ('price_category', OLD.tariff_id, 'D', 'tariff_id');
			    END IF;
			ELSIF (TG_OP = 'INSERT') THEN
			    INSERT INTO goodok.change_log(table_name, object_int_id, "action", "key") VALUES ('price_category', NEW.tariff_id, 'I', 'tariff_id');
			END IF;    
			RETURN NEW;
		    END;

$$;

ALTER FUNCTION price_category_change_log() OWNER TO inform;

