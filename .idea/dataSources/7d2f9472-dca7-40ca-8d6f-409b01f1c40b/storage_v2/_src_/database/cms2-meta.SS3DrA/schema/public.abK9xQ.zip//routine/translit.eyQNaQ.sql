CREATE FUNCTION translit(p_string character varying) RETURNS character varying
	IMMUTABLE
	LANGUAGE sql
AS
$$
select 
  replace(
  replace(
  replace(
  replace(
  replace(
  replace(
  replace(
  replace(
  translate(lower($1), 
  'абвгдеёжзийклмнопрстуфхцэь', 'abvgdeejziyklmnoprstufhce'),
  'ч', 'ch'),
  'ш', 'sh'),
  'щ', 'sch'),
  'ъ', 'y'),
  'ы', 'yi'),
  'ю', 'yu'),
  'я', 'ya'),
  'ц', 'ts');
$$;

ALTER FUNCTION translit(VARCHAR) OWNER TO postgres;

