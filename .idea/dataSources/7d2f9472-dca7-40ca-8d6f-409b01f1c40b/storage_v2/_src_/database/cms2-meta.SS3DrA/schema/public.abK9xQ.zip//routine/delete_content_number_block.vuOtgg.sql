CREATE FUNCTION delete_content_number_block(id integer) RETURNS void
	LANGUAGE plpgsql
AS
$$
BEGIN
	DELETE FROM content_number_block WHERE content_number_block_id = id;
END;
$$;

ALTER FUNCTION delete_content_number_block(INTEGER) OWNER TO postgres;

