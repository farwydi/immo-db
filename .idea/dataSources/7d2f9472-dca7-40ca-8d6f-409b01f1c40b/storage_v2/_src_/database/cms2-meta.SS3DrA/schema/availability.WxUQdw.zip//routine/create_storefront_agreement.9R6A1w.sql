CREATE FUNCTION create_storefront_agreement() RETURNS void
	SECURITY DEFINER
	LANGUAGE plpgsql
AS
$$
begin
CREATE OR REPLACE VIEW availability.storefront_agreement AS 
 SELECT foo.storefront_id, foo.agreement_id, foo.is_blacklist
   FROM ( SELECT sa.agreement_id, sa.storefront_id, sa.is_blacklist
           FROM storefront_agreement sa
UNION 
         SELECT a.agreement AS agreement_id, sc.storefront_id, sc.is_blacklist
           FROM storefront_contragent sc
      JOIN agreement a ON sc.contragent_id = a.contragent) foo
  ORDER BY foo.storefront_id, foo.agreement_id;

ALTER TABLE availability.storefront_agreement
  OWNER TO postgres;
GRANT ALL ON TABLE availability.storefront_agreement TO postgres;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE availability.storefront_agreement TO inform;
end;
$$;

ALTER FUNCTION create_storefront_agreement() OWNER TO postgres;

