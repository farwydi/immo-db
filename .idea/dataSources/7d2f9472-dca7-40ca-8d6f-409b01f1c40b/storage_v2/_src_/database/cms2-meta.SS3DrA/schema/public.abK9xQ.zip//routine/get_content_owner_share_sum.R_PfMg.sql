CREATE FUNCTION get_content_owner_share_sum(_storefront_id integer, _content_id integer, _region_id integer, _is_allied_rights boolean, _date timestamp without time zone) RETURNS numeric
	LANGUAGE sql
AS
$$
select sum(content_owner_share) from agreement2content
inner join agreement on agreement.agreement=agreement2content.agreement
inner join agreement2region on agreement2region.agreement=agreement.agreement
where content=$2 and agreement2region.region=$3 and is_allied_rights=$4 and start_date<=$5 and end_date>=$5
and is_storefront_rightholder_enable($1, agreement.agreement)
$$;

ALTER FUNCTION get_content_owner_share_sum(INTEGER, INTEGER, INTEGER, BOOLEAN, TIMESTAMP) OWNER TO postgres;

