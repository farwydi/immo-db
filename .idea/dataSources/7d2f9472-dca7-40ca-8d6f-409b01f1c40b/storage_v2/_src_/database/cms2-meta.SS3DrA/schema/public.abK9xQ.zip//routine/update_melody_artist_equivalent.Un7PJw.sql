CREATE FUNCTION update_melody_artist_equivalent(id uuid, equivalents character varying[]) RETURNS void
	LANGUAGE plpgsql
AS
$$
DECLARE
	equivalent varchar;
	real_id uuid;
BEGIN
real_id=(select(get_main_from_recycle(id)));
	DELETE FROM melody_artist_equivalent WHERE melody_artist_id = real_id;
	
	FOR i IN COALESCE(array_lower(equivalents,1),0) .. COALESCE(array_upper(equivalents,1),-1) LOOP
	equivalent := equivalents[i];
	
	INSERT INTO melody_artist_equivalent (melody_artist_id, name) VALUES (real_id, equivalent);

	END LOOP;
	return;
END;
$$;

ALTER FUNCTION update_melody_artist_equivalent(UUID, CHARACTER VARYING[]) OWNER TO postgres;

