CREATE FUNCTION join_artist_list_the() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_l text;
	_main_artist uuid;	
	_res record;
begin

_l='';
	for _row in 

select *, replace(replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),'the ',''),' ','') as l from melody_artist where replace(replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),'the ',''),' ','') in (
select replace(replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),'the ',''),' ','')   from melody_artist
group by replace(replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),'the ',''),' ','')
having count(*)>1)
and 
replace(replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),'the ',''),' ','') not ilike '%�%' 
and 
replace(replace(lower(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",'')),'the ',''),' ','') <> ''
order by l,lower(replace(COALESCE(last_name,'')||COALESCE(first_name,'')||COALESCE(middle_name,'')||COALESCE("group",''),' ','')) desc
	
			loop

		if (_row.l<>_l) then
			--следующий артист, инициализируем переменные
			_l=_row.l;
			_main_artist=_row.melody_artist_id;
		else
			--клеим
			select * from join_artist(_main_artist,_row.melody_artist_id) into _res;
		end if;
		
	end loop;

end;
$$;

ALTER FUNCTION join_artist_list_the() OWNER TO postgres;

