CREATE MATERIALIZED VIEW default.profile_download_sum
            (
             `record_date` Date,
             `profile_id` UInt32,
             `ct_dwn` UInt64
                )
            ENGINE = SummingMergeTree
                PARTITION BY toYYYYMM(record_date)
                ORDER BY (record_date, profile_id)
                SETTINGS index_granularity = 8192
AS
SELECT record_date,
       profile_id,
       count(1) AS ct_dwn
FROM default.storage_stats_t
WHERE (sid NOT IN ('', NULL))
  AND (msisdn > 1)
GROUP BY record_date,
         profile_id;

