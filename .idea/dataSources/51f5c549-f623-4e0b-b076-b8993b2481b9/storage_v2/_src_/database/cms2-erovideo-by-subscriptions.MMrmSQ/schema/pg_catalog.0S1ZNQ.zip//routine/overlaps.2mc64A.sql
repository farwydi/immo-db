CREATE FUNCTION "overlaps"(timestamp without time zone, interval, timestamp without time zone, timestamp without time zone) RETURNS boolean
	IMMUTABLE
	PARALLEL SAFE
	COST 1
	LANGUAGE sql
AS
$$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$;

COMMENT ON FUNCTION "overlaps"(TIMESTAMP, INTERVAL, TIMESTAMP, TIMESTAMP) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIMESTAMP, INTERVAL, TIMESTAMP, TIMESTAMP) OWNER TO postgres;

