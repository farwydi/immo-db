CREATE VIEW pg_stat_repl
			(pid, usesysid, usename, application_name, client_addr, client_hostname, client_port, backend_start,
			 backend_xmin, state, sent_location, write_location, flush_location, replay_location, sync_priority,
			 sync_state)
AS
SELECT pg_stat_repl.pid,
	   pg_stat_repl.usesysid,
	   pg_stat_repl.usename,
	   pg_stat_repl.application_name,
	   pg_stat_repl.client_addr,
	   pg_stat_repl.client_hostname,
	   pg_stat_repl.client_port,
	   pg_stat_repl.backend_start,
	   pg_stat_repl.backend_xmin,
	   pg_stat_repl.state,
	   pg_stat_repl.sent_location,
	   pg_stat_repl.write_location,
	   pg_stat_repl.flush_location,
	   pg_stat_repl.replay_location,
	   pg_stat_repl.sync_priority,
	   pg_stat_repl.sync_state
FROM pg_stat_repl() pg_stat_repl(pid, usesysid, usename, application_name, client_addr, client_hostname, client_port,
								 backend_start, backend_xmin, state, sent_location, write_location, flush_location,
								 replay_location, sync_priority, sync_state);

ALTER TABLE pg_stat_repl
	OWNER TO postgres;

