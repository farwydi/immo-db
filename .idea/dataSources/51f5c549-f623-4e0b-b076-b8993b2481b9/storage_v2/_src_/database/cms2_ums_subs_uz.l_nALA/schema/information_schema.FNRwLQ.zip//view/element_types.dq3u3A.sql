CREATE VIEW element_types
			(object_catalog, object_schema, object_name, object_type, collection_type_identifier, data_type,
			 character_maximum_length, character_octet_length, character_set_catalog, character_set_schema,
			 character_set_name, collation_catalog, collation_schema, collation_name, numeric_precision,
			 numeric_precision_radix, numeric_scale, datetime_precision, interval_type, interval_precision,
			 domain_default, udt_catalog, udt_schema, udt_name, scope_catalog, scope_schema, scope_name,
			 maximum_cardinality, dtd_identifier)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER              AS object_catalog,
	   n.nspname::information_schema.SQL_IDENTIFIER                       AS object_schema,
	   x.objname                                                          AS object_name,
	   x.objtype::information_schema.CHARACTER_DATA                       AS object_type,
	   x.objdtdid::information_schema.SQL_IDENTIFIER                      AS collection_type_identifier,
	   CASE
		   WHEN nbt.nspname = 'pg_catalog'::NAME THEN format_type(bt.oid, NULL::INTEGER)
		   ELSE 'USER-DEFINED'::TEXT
		   END::information_schema.CHARACTER_DATA                         AS data_type,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS character_maximum_length,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS character_octet_length,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS character_set_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS character_set_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS character_set_name,
	   CASE
		   WHEN nco.nspname IS NOT NULL THEN current_database()
		   ELSE NULL::NAME
		   END::information_schema.SQL_IDENTIFIER                         AS collation_catalog,
	   nco.nspname::information_schema.SQL_IDENTIFIER                     AS collation_schema,
	   co.collname::information_schema.SQL_IDENTIFIER                     AS collation_name,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS numeric_precision,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS numeric_precision_radix,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS numeric_scale,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS datetime_precision,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS interval_type,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS interval_precision,
	   NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS domain_default,
	   current_database()::information_schema.SQL_IDENTIFIER              AS udt_catalog,
	   nbt.nspname::information_schema.SQL_IDENTIFIER                     AS udt_schema,
	   bt.typname::information_schema.SQL_IDENTIFIER                      AS udt_name,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS scope_catalog,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS scope_schema,
	   NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS scope_name,
	   NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS maximum_cardinality,
	   ('a'::TEXT || x.objdtdid::TEXT)::information_schema.SQL_IDENTIFIER AS dtd_identifier
FROM pg_namespace n,
	 pg_type at,
	 pg_namespace nbt,
	 pg_type bt,
	 (SELECT c.relnamespace,
			 c.relname::information_schema.SQL_IDENTIFIER AS relname,
			 CASE
				 WHEN c.relkind = 'c'::"char" THEN 'USER-DEFINED TYPE'::TEXT
				 ELSE 'TABLE'::TEXT
				 END                                      AS "case",
			 a.attnum,
			 a.atttypid,
			 a.attcollation
	  FROM pg_class c,
		   pg_attribute a
	  WHERE c.oid = a.attrelid
		AND (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'f'::"char", 'c'::"char"]))
		AND a.attnum > 0
		AND NOT a.attisdropped
	  UNION ALL
	  SELECT t.typnamespace,
			 t.typname::information_schema.SQL_IDENTIFIER AS typname,
			 'DOMAIN'::TEXT                               AS text,
			 1,
			 t.typbasetype,
			 t.typcollation
	  FROM pg_type t
	  WHERE t.typtype = 'd'::"char"
	  UNION ALL
	  SELECT ss.pronamespace,
			 ((ss.proname::TEXT || '_'::TEXT) || ss.oid::TEXT)::information_schema.SQL_IDENTIFIER AS sql_identifier,
			 'ROUTINE'::TEXT                                                                      AS text,
			 (ss.x).n                                                                             AS n,
			 (ss.x).x                                                                             AS x,
			 0
	  FROM (SELECT p.pronamespace,
				   p.proname,
				   p.oid,
				   information_schema._pg_expandarray(COALESCE(p.proallargtypes, p.proargtypes::OID[])) AS x
			FROM pg_proc p) ss
	  UNION ALL
	  SELECT p.pronamespace,
			 ((p.proname::TEXT || '_'::TEXT) || p.oid::TEXT)::information_schema.SQL_IDENTIFIER AS sql_identifier,
			 'ROUTINE'::TEXT                                                                    AS text,
			 0,
			 p.prorettype,
			 0
	  FROM pg_proc p) x(objschema, objname, objtype, objdtdid, objtypeid, objcollation)
		 LEFT JOIN (pg_collation co
		 JOIN pg_namespace nco ON co.collnamespace = nco.oid)
				   ON x.objcollation = co.oid AND (nco.nspname <> 'pg_catalog'::NAME OR co.collname <> 'default'::NAME)
WHERE n.oid = x.objschema
  AND at.oid = x.objtypeid
  AND at.typelem <> 0::OID
  AND at.typlen = '-1'::INTEGER
  AND at.typelem = bt.oid
  AND nbt.oid = bt.typnamespace
  AND ((n.nspname, x.objname::TEXT, x.objtype, x.objdtdid::information_schema.SQL_IDENTIFIER::TEXT) IN
	   (SELECT data_type_privileges.object_schema,
			   data_type_privileges.object_name,
			   data_type_privileges.object_type,
			   data_type_privileges.dtd_identifier
		FROM information_schema.data_type_privileges));

ALTER TABLE element_types
	OWNER TO postgres;

