CREATE FUNCTION update_album_count_track(_schema text) RETURNS integer
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;begin

 EXECUTE 'update '||_schema||'.melody_album
			set count_track=0  ';FOR _row IN  EXECUTE 'select album_id, count(*)
				from (
					SELECT distinct melody_card_album.album_id, melody_card_album.card_id as count from '||_schema||'.melody_card_album 
					inner join  '||_schema||'.content on melody_card_album.card_id=content.card_id 
					) t
				group by album_id '
  LOOP
    EXECUTE 'update '||_schema||'.melody_album
			set count_track=' ||_row.count ||' 
			where melody_album_id='''||_row.album_id || '''';end LOOP;return 1;end;
$$;

ALTER FUNCTION update_album_count_track(TEXT) OWNER TO postgres;

