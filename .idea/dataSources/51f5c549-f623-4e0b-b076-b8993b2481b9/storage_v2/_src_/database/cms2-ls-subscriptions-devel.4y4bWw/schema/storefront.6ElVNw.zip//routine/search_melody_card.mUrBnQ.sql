CREATE FUNCTION search_melody_card(_schema text, _where text, _vector_field text, _field_highlight text, _search_text text, _highlight_argument text, _limit integer, _pattern text, _delimiter text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_card_id uuid;
_guid_empty uuid;

_sql_text text;

_row record;
_row_temp record;
_res_record record;

_artist_name text;
_artist_name_temp text;

_artist_uuid text;
--_preview_fat_name text;

_i integer;

begin


_sql_text:= 'SELECT 	distinct content.card_id, content.name, 
      -- content.version,
			melody_artist.melody_artist_id,	
			melody_artist.group, melody_artist.last_name,
			melody_artist.first_name, melody_artist.middle_name, melody_card_artist.is_dominant,  content.rank, content.text' ||      
	    ' FROM
			(SELECT 
                        foo.*,
                        ts_headline('||_field_highlight||', to_tsquery('''||_search_text||'''),'''||_highlight_argument||''') as text
                        
                    FROM
                        (
                            SELECT
                                distinct on (card_id) *, 
                                card_id as card,
                                name as card_name,
                                ts_rank_cd('||_vector_field||', query) AS rank
                            FROM
                                ' || _schema || '.content as c,
                                to_tsquery('''||_search_text||''') query
                            WHERE
                                '||_vector_field||' @@ query 
                            ORDER BY card_id
                        )
                        AS
                            foo 
                    ORDER BY 
                        rank DESC, 
                        name
                    '||
			CASE WHEN _limit>0 THEN ' limit ' || _limit
				    ELSE  ''
			   END 
                     ||
                    ') content
			INNER JOIN ' || _schema || '.melody_card_artist  
				ON  content.card_id=melody_card_artist.card_id
			INNER JOIN ' || _schema || '.melody_artist  
				ON  melody_card_artist.artist_id=melody_artist.melody_artist_id ' 
/*������

			||
			'
			LEFT JOIN 
				(select source_id, max(fat_name) as fat_name from  ' || _schema || '.preview_relation 
				LEFT JOIN ' || _schema || '.preview_picture on preview_picture.preview_picture_id=preview_relation.preview_id
				where preview_type_id='||_preview_type_id ||' and preview_watermark_id='|| _preview_watermark_id ||' group by source_id ) preview 
				ON preview.source_id=content.card_id
			'	*/
			||COALESCE (_where,'')
			|| ' order by rank desc, content.name, content.card_id, melody_card_artist.is_dominant desc' || ' ' 
			; 



_card_id:='00000000-0000-0000-0000-000000000000'; 
_guid_empty:='00000000-0000-0000-0000-000000000000'; 
_artist_name:='';
_artist_uuid:='';

_i:=0;

FOR _row IN EXECUTE _sql_text LOOP
	IF (_card_id<>_row.card_id) THEN

		--����� ��������
		IF (_card_id<>_guid_empty) THEN
			--��������� ����������
			
			select _card_id::uuid, 
				_row_temp.name::text, 
				COALESCE(_artist_name,'')::text as artist_name,
				COALESCE(_artist_uuid,'')::text as artist_uuid,
				_row_temp.rank::float, 
				_row_temp.text::text
        -- _row_temp.version::character varying(100)

/*������	
	,  
		COALESCE(_preview_fat_name,'')::text as preview_fat_name '
*/
				into _res_record; 
		
			if (_res_record.artist_name='') THEN
				_res_record.artist_name:=null;
				_res_record.artist_uuid:=null;
			END IF;


			return next _res_record;

			_i:=_i+1;
			
		END IF;
		_artist_name:=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name:=replace(_artist_name,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name:=replace(_artist_name,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name:=replace(_artist_name,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name:=trim(both ' ' from _artist_name);

		_artist_uuid:=cast(_row.melody_artist_id as text);


		
	ELSE
		_artist_name_temp:=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name_temp:=replace(_artist_name_temp,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name_temp:=replace(_artist_name_temp,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name_temp:=replace(_artist_name_temp,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name_temp:=trim(both ' ' from _artist_name_temp);

		_artist_name:=_artist_name || _delimiter || _artist_name_temp;

		_artist_uuid:=_artist_uuid ||_delimiter || cast(_row.melody_artist_id as text);
	
	END IF;

	_card_id:=_row.card_id;
	_row_temp=_row;
END LOOP;

IF (_card_id<>_guid_empty ) THEN

	--��������� ��������� ��������
	select _card_id::uuid, 
		_row_temp.name::text, 
		COALESCE(_artist_name,'')::text as artist_name,
		COALESCE(_artist_uuid,'')::text as artist_uuid,
		_row_temp.rank::float, 
		_row_temp.text::text
    -- _row_temp.version::character varying(100)

/*������	
	,  
		COALESCE(_preview_fat_name,'')::text as preview_fat_name '
*/
		into _res_record; 

	if (_res_record.artist_name='') THEN
		_res_record.artist_name:=null;
		_res_record.artist_uuid:=null;
	END IF;

/*	if (_preview_fat_name='') THEN
		_res_record._preview_fat_name:=null;
	END IF;
*/
	return next _res_record; 

	
END IF;
end;
$$;

ALTER FUNCTION search_melody_card(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, INTEGER, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

