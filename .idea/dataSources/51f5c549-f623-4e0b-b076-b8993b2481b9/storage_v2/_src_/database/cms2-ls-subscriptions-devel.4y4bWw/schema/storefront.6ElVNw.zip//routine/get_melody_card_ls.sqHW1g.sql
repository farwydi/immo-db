CREATE FUNCTION get_melody_card_ls(_schema text, _select text, _inner_join text, _where text, _orderby text, _limit integer, _pattern text, _delimiter text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_card_id uuid;
_guid_empty uuid;

_sql_text text;

_row record;
_row_temp record;
_res_record record;

_artist_name text;
_artist_name_temp text;

_artist_uuid text;

_rating integer;
_rating_old integer;

_preview_fat_name text;

_i integer;

begin


_sql_text:= 'SELECT 	distinct content.card_id, content.name, content.version,  
			melody_artist.melody_artist_id,	
			melody_artist.group, melody_artist.last_name,
			melody_artist.first_name, melody_artist.middle_name, melody_card_artist.is_dominant, '
			--preview.fat_name ' 
			||_schema || '.get_preview_picture('''||_schema ||''','||_preview_type_id ||','|| _preview_watermark_id ||',melody_artist.melody_artist_id) as fat_name ' 
			|| CASE WHEN _select is null THEN ''
				    WHEN _select='' THEN ''
				    ELSE  ', ' || _select
			   END 
			||
			CASE WHEN position('rating' in _orderby)>0 THEN ', rating, rating_old' 
				ELSE ''
			END	||
	    ' FROM
			' || _schema || '.content  
			LEFT JOIN ' || _schema || '.melody_card_artist  
				ON  content.card_id=melody_card_artist.card_id
			LEFT JOIN ' || _schema || '.melody_artist  
				ON  melody_card_artist.artist_id=melody_artist.melody_artist_id ' 
			|| COALESCE(_inner_join,'') || ' ' 
			||COALESCE (_where,'')
			|| ' ' 
			|| CASE WHEN _orderby is null THEN 'ORDER BY '
				    WHEN _orderby='' THEN 'ORDER BY '
				    ELSE _orderby || ', '
			   END
			|| 'content.card_id, melody_card_artist.is_dominant desc ' || ' ' 
			; 


_card_id:='00000000-0000-0000-0000-000000000000'; 
_guid_empty:='00000000-0000-0000-0000-000000000000'; 
_artist_name:='';
_artist_uuid:='';
_rating:=0;
_rating_old:=0;
_preview_fat_name:='';

_i:=0;

FOR _row IN EXECUTE _sql_text LOOP
	IF (_card_id<>_row.card_id) THEN

		IF (_limit>0 and _i>=_limit) THEN 
			exit;
		END IF;

		--����� ��������
		IF (_card_id<>_guid_empty) THEN
			--��������� ����������
			
			EXECUTE 'select ''' || _card_id || ''':: uuid,  
				' || quote_literal(_row_temp.name) || '::text, 
				' || quote_literal(COALESCE(_artist_name,'')) || '::text as artist_name,
				' || quote_literal(COALESCE(_artist_uuid,'')) || '::text as artist_uuid,  
				' || quote_literal(COALESCE(_row_temp.fat_name,'')) ||'::text as preview_fat_name,
				' || quote_literal(COALESCE(_row_temp.version,'')) ||'::text as version'
				||
				CASE WHEN position('rating' in _orderby)>0 THEN ', cast('|| COALESCE(_rating,0) ||' as integer), cast(' || COALESCE(_rating_old,0) || ' as integer)' ELSE '' END
				into _res_record; 

			if (_res_record.artist_name='') THEN
				_res_record.artist_name:=null;
				_res_record.artist_uuid:=null;
			END IF;

			if (_preview_fat_name='') THEN
				_preview_fat_name := null;
			END IF;

			_res_record.preview_fat_name := _preview_fat_name;

			return next _res_record;

			_i := _i+1;
			
		END IF;
		_artist_name:=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name:=replace(_artist_name,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name:=replace(_artist_name,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name:=replace(_artist_name,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name:=trim(both ' ' from _artist_name);

		_preview_fat_name := COALESCE(_row.fat_name, '');

		_artist_uuid:=cast(_row.melody_artist_id as text);

		IF position('rating' in _orderby)>0 THEN 
			_rating=COALESCE(_row.rating,0);
			_rating_old=COALESCE(_row.rating_old,0);
		END IF;
		
	ELSE
		_artist_name_temp:=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name_temp:=replace(_artist_name_temp,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name_temp:=replace(_artist_name_temp,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name_temp:=replace(_artist_name_temp,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name_temp:=trim(both ' ' from _artist_name_temp);

		_artist_name:=_artist_name || _delimiter || _artist_name_temp;

		_artist_uuid:=_artist_uuid ||_delimiter || cast(_row.melody_artist_id as text);
	END IF;

	_card_id:=_row.card_id;
	_row_temp=_row;
END LOOP;

IF (_card_id<>_guid_empty and (_i<_limit or _limit=0)) THEN
	--��������� ��������� ��������
	EXECUTE 'select ''' || _card_id || ''':: uuid, 
				' || quote_literal(_row_temp.name) || '::text, 
				' || quote_literal(COALESCE(_artist_name,'')) || '::text as artist_name,
				' || quote_literal(COALESCE(_artist_uuid,'')) || '::text as artist_uuid,  
				' || quote_literal(COALESCE(_row_temp.fat_name,'')) ||'::text as preview_fat_name,
				' || quote_literal(COALESCE(_row_temp.version,'')) ||'::text as version '
				||
				CASE WHEN position('rating' in _orderby)>0 THEN ', cast('|| COALESCE(_rating,0) ||' as integer), cast(' || COALESCE(_rating_old,0) || ' as integer)' ELSE '' END
				into _res_record; 

	if (_res_record.artist_name='') THEN
		_res_record.artist_name:=null;
		_res_record.artist_uuid:=null;
	END IF;

	if (_row_temp.fat_name='') THEN
		_res_record._preview_fat_name:=null;
	END IF;

	return next _res_record; 
END IF;

end;
$$;

ALTER FUNCTION get_melody_card_ls(TEXT, TEXT, TEXT, TEXT, TEXT, INTEGER, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

