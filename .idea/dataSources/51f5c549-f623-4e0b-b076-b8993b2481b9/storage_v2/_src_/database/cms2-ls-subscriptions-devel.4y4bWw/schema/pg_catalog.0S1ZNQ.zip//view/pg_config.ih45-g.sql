CREATE VIEW pg_config(name, setting) AS
SELECT pg_config.name,
	   pg_config.setting
FROM pg_config() pg_config(name, setting);

ALTER TABLE pg_config
	OWNER TO postgres;

