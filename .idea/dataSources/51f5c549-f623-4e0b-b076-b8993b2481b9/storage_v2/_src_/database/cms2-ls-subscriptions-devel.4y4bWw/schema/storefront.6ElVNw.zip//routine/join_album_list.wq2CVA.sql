CREATE FUNCTION join_album_list() RETURNS void
	LANGUAGE plpgsql
AS
$$
declare 
	_row record;
	_name text;
	_primary_artist_id uuid;
	_main_album uuid;	
	_res record;
begin

_name='';
_primary_artist_id='00000000-0000-0000-0000-000000000000'; 
	
	for _row in 
		select melody_album.*, t.name as  name_good from melody_album inner join (
					select primary_artist_id, rtrim(ltrim(name,'"'),'"') as name, count(*) from melody_album 
					group by primary_artist_id, rtrim(ltrim(name,'"'),'"')
					having count(*)>1) t on melody_album.primary_artist_id=t.primary_artist_id  and rtrim(ltrim(melody_album.name,'"'),'"')=t.name
					
					order by melody_album.primary_artist_id, melody_album.name--,rightholder_id
		
	/*select melody_album.* from melody_album inner join (
				select primary_artist_id, name,count(*) from melody_album 
				group by primary_artist_id, name 
				having count(*)>1) t on melody_album.primary_artist_id=t.primary_artist_id and melody_album.name=t.name
				order by melody_album.primary_artist_id, melody_album.name, _temp_album_exist(melody_album_id) desc*/
			loop

		if (_row.primary_artist_id=_primary_artist_id and _row.name_good=_name) then
			--�����
			select * from join_album(_main_album,_row.melody_album_id) into _res;
		else
			--��������� ������, �������������� ����������
			_name=_row.name_good;
			_primary_artist_id=_row.primary_artist_id;
			_main_album=_row.melody_album_id;
			
		end if;
		
	end loop;

end;
$$;

ALTER FUNCTION join_album_list() OWNER TO postgres;

