CREATE FUNCTION get_melody_album_ls(_schema text, _inner_join text, _where text, _orderby text, _orderby_artist text, _limit integer, _pattern text, _delimiter text, _preview_type_id integer, _preview_watermark_id integer) RETURNS SETOF record
	LANGUAGE plpgsql
AS
$$
declare
_album_id uuid;
_guid_empty uuid;

_sql_text text;

_row record;
_row_temp record;
_res_record record;

_artist_name text;
_artist_name_temp text;

_artist_uuid text;


_i integer;

begin

_sql_text:='SELECT 
		DISTINCT melody_album.*,  melody_artist.*, ' ||
		--' preview.fat_name, ' ||
		_schema || '.get_preview_picture('''||_schema ||''','||_preview_type_id ||','|| _preview_watermark_id ||',melody_album.melody_album_id) as  fat_name, ' 
		||' mca.is_dominant 
		FROM 
			' || _schema || '.melody_card_artist
			INNER JOIN ' || _schema || '.melody_card_album on melody_card_artist.card_id=melody_card_album.card_id
			INNER JOIN ' || _schema || '.melody_card_artist mca on mca.card_id=melody_card_album.card_id
			INNER JOIN ' || _schema || '.melody_artist on melody_artist.melody_artist_id=mca.artist_id
			INNER JOIN ' || _schema || '.melody_album on melody_album.melody_album_id=melody_card_album.album_id '
			|| COALESCE(_inner_join,'') || ' '   
			/*|| '
			LEFT JOIN 
					  (
					      SELECT 
						  source_id, 
						  max(fat_name) as fat_name 
					      FROM  
						  ' || _schema || '.preview_relation 
						  LEFT JOIN 
						      ' || _schema || '.preview_picture 
						  ON 
						      preview_picture.preview_picture_id = preview_relation.preview_id
					      WHERE 
						  preview_type_id = '|| _preview_type_id ||' 
					      AND 
						  preview_watermark_id = '|| _preview_watermark_id ||' 
					      GROUP BY source_id 
					  ) preview 
					   ON 
					  preview.source_id =melody_album.melody_album_id '*/
			|| CASE WHEN _where is null THEN 'WHERE '
				    WHEN _where='' THEN 'WHERE '
				    ELSE _where || ' and '
			   END
			|| ' melody_card_artist.is_album_visible = true and count_track>0 ' 
			|| CASE WHEN _orderby is null THEN 'ORDER BY '
				    WHEN _orderby='' THEN 'ORDER BY '
				    ELSE _orderby || ', '
			   END
			|| ' melody_album.melody_album_id, mca.is_dominant'
			|| CASE WHEN _orderby_artist is null THEN ' '
				    WHEN _orderby_artist='' THEN ' '
				    ELSE  ', ' || _orderby_artist 
			   END
			;		  
	  

_album_id:='00000000-0000-0000-0000-000000000000'; 
_guid_empty:='00000000-0000-0000-0000-000000000000'; 
_artist_name:='';
_artist_uuid:='';

_i:=0;

--raise exception '%',_sql_text;

FOR _row IN EXECUTE _sql_text LOOP
	IF (_album_id<>_row.melody_album_id) THEN

		IF (_limit>0 and _i>=_limit) THEN 
			exit;
		END IF;
		
		--����� ������
		IF (_album_id<>_guid_empty) THEN
			--��������� ����������

			select 	_row_temp.melody_album_id::uuid,
				_row_temp.name::text, 
				_row_temp.released::timestamp,
				_row_temp.count_track::integer,
				_row_temp.is_collection::boolean,
				_artist_name::text,
				_artist_uuid::text,
				_row_temp.fat_name::text,
				_row_temp.version::text
			into _res_record;	
				

			return next _res_record; 

			_i:=_i+1;
			
		END IF;
		_artist_name:=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name:=replace(_artist_name,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name:=replace(_artist_name,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name:=replace(_artist_name,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name:=trim(both ' ' from _artist_name);

		_artist_uuid:=cast(_row.melody_artist_id as text);

		
	ELSE
		_artist_name_temp:=replace(_pattern,'{group}',COALESCE( _row.group,''));
		_artist_name_temp:=replace(_artist_name_temp,'{last_name}',COALESCE( _row.last_name,''));
		_artist_name_temp:=replace(_artist_name_temp,'{first_name}',COALESCE( _row.first_name,''));
		_artist_name_temp:=replace(_artist_name_temp,'{middle_name}',COALESCE( _row.middle_name,''));
		_artist_name_temp:=trim(both ' ' from _artist_name_temp);

		_artist_name:=_artist_name || _delimiter || _artist_name_temp;

		_artist_uuid:=_artist_uuid ||_delimiter || cast(_row.melody_artist_id as text);
	
	END IF;

	_album_id=_row.melody_album_id;
	_row_temp=_row;
END LOOP;

IF (_album_id<>_guid_empty and (_i<_limit or _limit=0)) THEN

	--��������� ��������� ������
	select 	_row_temp.melody_album_id::uuid,
		_row_temp.name::text, 
		_row_temp.released::timestamp,
		_row_temp.count_track::integer,
		_row_temp.is_collection::boolean,
		_artist_name::text,
		_artist_uuid::text,
		_row_temp.fat_name::text,
		_row_temp.version::text
	into _res_record;	
		

	return next _res_record;

	
END IF;
end;
$$;

ALTER FUNCTION get_melody_album_ls(TEXT, TEXT, TEXT, TEXT, TEXT, INTEGER, TEXT, TEXT, INTEGER, INTEGER) OWNER TO postgres;

