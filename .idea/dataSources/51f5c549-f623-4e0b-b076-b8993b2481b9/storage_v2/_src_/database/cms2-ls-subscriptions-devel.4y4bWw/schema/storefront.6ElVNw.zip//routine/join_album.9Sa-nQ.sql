CREATE FUNCTION join_album(main_album uuid, album uuid) RETURNS SETOF void
	LANGUAGE plpgsql
AS
$$
declare
	_res record;
	_count integer;
BEGIN
/*album*/
	SELECT 
		melody_album.melody_album_id, 
		COALESCE(melody_album.primary_artist_id, melody_album1.primary_artist_id) as primary_artist_id,
		COALESCE(melody_album.name, melody_album1.name) as name,
		COALESCE(melody_album.search_text, melody_album1.search_text) as search_text,
		COALESCE(melody_album.released, melody_album1.released) as released,
		COALESCE(melody_album.have_goodok, melody_album1.have_goodok) as have_goodok,
		COALESCE(melody_album.count_track, melody_album1.count_track) as count_track,
		COALESCE(melody_album.is_collection, melody_album1.is_collection) as is_collection,
		COALESCE(melody_album.fts, melody_album1.fts) as fts into _res
	FROM 
		melody_album,
		melody_album melody_album1
	WHERE
		melody_album.melody_album_id=main_album
	and 
		melody_album1.melody_album_id=album;

	UPDATE melody_album
	SET  
		primary_artist_id=_res.primary_artist_id, 
		search_text=_res.search_text, 
		name=_res.name, 
		released=_res.released,  
		have_goodok=_res.have_goodok, 
		count_track=_res.count_track, 
		is_collection=_res.is_collection, 
		fts=_res.fts
	 WHERE 
		melody_album_id=main_album;


	/*card*/
	for _res in select * from melody_card_album where album_id=album loop
		select count(*) into _count from melody_card_album where album_id=main_album and card_id=_res.card_id;

		if _count>0 then
			delete from melody_card_album where album_id=album and card_id=_res.card_id;
		else
			update melody_card_album SET album_id = main_album
				where album_id=album and card_id=_res.card_id;
		end if; 
		
	end loop;


	/*preview*/
	for _res in select * from preview_relation where source_id=album loop
		select count(*) into _count from preview_relation where source_id=main_album and preview_id=_res.preview_id;

		if _count>0 then
			delete from preview_relation where source_id=album and review_id=_res.preview_id;
		else
			update preview_relation SET source_id = main_album
				where source_id=album and preview_id=_res.preview_id; 
		end if;
	end loop;

	delete from melody_album where melody_album_id = album;
END;
$$;

ALTER FUNCTION join_album(UUID, UUID) OWNER TO postgres;

