CREATE FUNCTION xpath(text, xml) RETURNS xml[]
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	COST 1
	LANGUAGE sql
AS
$$
select pg_catalog.xpath($1, $2, '{}'::pg_catalog.text[])
$$;

COMMENT ON FUNCTION xpath(TEXT, XML) IS 'evaluate XPath expression';

ALTER FUNCTION xpath(TEXT, XML) OWNER TO postgres;

